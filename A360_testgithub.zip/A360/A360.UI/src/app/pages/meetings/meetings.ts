import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { DatePipe } from '@angular/common';
import { StateService } from '../../core/services/state';
import { MeetingWizardService } from '../../components/meeting-wizard/meeting-wizard.service';
import { Meeting } from '../../core/models/a360.models';

@Component({
  selector: 'app-meetings',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe],
  templateUrl: './meetings.html',
})
export class Meetings {
  protected readonly state = inject(StateService);
  private readonly wizard = inject(MeetingWizardService);

  protected readonly sorted = computed<readonly Meeting[]>(() =>
    [...this.state.meetings()].sort((a, b) =>
      String(b.meetingDate).localeCompare(String(a.meetingDate))
    )
  );

  protected startMeeting(): void {
    this.wizard.open(this.state.contracts()[0]?.id);
  }

  protected sentimentClass(s: string): string {
    return s === 'Positive' ? 'bg-emerald-50 text-emerald-800'
      : s === 'Negative' ? 'bg-red-50 text-red-800'
      : 'bg-slate-100 text-slate-500';
  }
}