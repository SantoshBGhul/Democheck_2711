import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { StateService } from '../../core/services/state';
import { ApiService } from '../../core/services/api';
import { FlashService } from '../../core/services/flash.service';
import { Contract, PerformanceManager, initialsOf } from '../../core/models/a360.models';

@Component({
  selector: 'app-admin',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  templateUrl: './admin.html',
})
export class Admin {
  protected readonly state = inject(StateService);
  private readonly api = inject(ApiService);
  private readonly flash = inject(FlashService);

  protected readonly initials = initialsOf;
  protected readonly pms = computed<readonly PerformanceManager[]>(() => this.state.pms());
  protected readonly contracts = computed<readonly Contract[]>(() =>
    [...this.state.contracts()].sort((a, b) => a.customer.localeCompare(b.customer))
  );

  // PM form
  protected pmName = signal('');
  protected pmRegion = signal('EMEA');
  protected pmEmail = signal('');

  // Account form
  protected acName = signal('');
  protected acPm = signal('');
  protected acRegion = signal('EMEA');
  protected acValue = signal(0);

  protected async addPM(): Promise<void> {
    const name = this.pmName().trim();
    if (!name) { this.flash.show('Enter a Performance Manager name'); return; }
    try {
      await firstValueFrom(this.api.createPerformanceManager({
        name, region: this.pmRegion(), email: this.pmEmail().trim() || undefined,
      }));
      this.pmName.set(''); this.pmEmail.set('');
      this.state.reload();
      this.flash.show(`"${name}" added`);
    } catch { /* interceptor handles */ }
  }

  protected async deletePM(p: PerformanceManager): Promise<void> {
    const msg = p.accountCount > 0
      ? `"${p.name}" is assigned to ${p.accountCount} account(s). Remove anyway?`
      : `Remove "${p.name}"?`;
    if (!confirm(msg)) return;
    try {
      await firstValueFrom(this.api.deletePerformanceManager(p.id));
      this.state.reload();
      this.flash.show('Performance Manager removed');
    } catch { /* handled */ }
  }

  protected async addAccount(): Promise<void> {
    const name = this.acName().trim();
    if (!name) { this.flash.show('Enter an account name'); return; }
    try {
      await firstValueFrom(this.api.createContract({
        customer: name,
        pmName: this.acPm() || (this.pms()[0]?.name ?? 'Unassigned'),
        region: this.acRegion(),
        value: Number(this.acValue()) || 0,
      }));
      this.acName.set(''); this.acValue.set(0);
      this.state.reload();
      this.flash.show(`Account "${name}" added`);
    } catch { /* handled */ }
  }

  protected async deleteAccount(c: Contract): Promise<void> {
    if (!confirm(`Remove account "${c.customer}" and all its health data?`)) return;
    try {
      await firstValueFrom(this.api.deleteContract(c.id));
      this.state.reload();
      this.flash.show('Account removed');
    } catch { /* handled */ }
  }

  protected healthDot(h: string): string {
    switch (h) {
      case 'Green': return 'bg-emerald-500';
      case 'Yellow': return 'bg-yellow-500';
      case 'Orange': return 'bg-orange-500';
      case 'Red': return 'bg-red-500';
      default: return 'bg-slate-300';
    }
  }
}