import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { StateService, Filters } from '../../core/services/state';
import { FlashService } from '../../core/services/flash.service';
import { ApiService } from '../../core/services/api';
import { KpiStrip } from '../../components/kpi-strip/kpi-strip';
import { InsightGrid } from '../../components/insight-grid/insight-grid';
import { PerformanceAnalytics } from '../../components/performance-analytics/performance-analytics';
import { A360Summary } from '../../components/a360-summary/a360-summary';
import { MeetingWizardService } from '../../components/meeting-wizard/meeting-wizard.service';
import { Contract } from '../../core/models/a360.models';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, KpiStrip, InsightGrid, PerformanceAnalytics, A360Summary],
  templateUrl: './dashboard.html',
})
export class Dashboard {
  protected readonly state = inject(StateService);
  private readonly api = inject(ApiService);
  private readonly flash = inject(FlashService);
  private readonly wizard = inject(MeetingWizardService);
  private readonly router = inject(Router);

  protected readonly portfolio = signal<readonly Contract[]>([]);

  protected readonly months = ['All', '2026-09', '2026-10', '2026-11', '2026-12'];
  protected readonly regions = ['All', 'EMEA', 'AMER', 'APJ'];
  protected readonly healths = ['All', 'Green', 'Yellow', 'Orange', 'Red', 'Blank'];
  protected readonly sentiments = ['All', 'Positive', 'Neutral', 'Negative'];

  constructor() {
    // Keep a stable sorted view of the contracts for the portfolio table
    queueMicrotask(() => this.refreshPortfolio());
    // Refresh portfolio whenever contracts signal changes
    // (Using a microtask keeps this OnPush-friendly without effect())
    this.state.contractsResource.value; // touch
    setInterval(() => this.refreshPortfolio(), 800);
  }

  protected onFilter<K extends keyof Filters>(key: K, value: string): void {
    this.state.setFilter(key, value as Filters[K]);
    this.refreshPortfolio();
  }

  protected resetFilters(): void {
    this.state.resetFilters();
    this.refreshPortfolio();
  }

  protected openMeeting(contractId?: number): void {
    this.wizard.open(contractId ?? this.state.contracts()[0]?.id);
  }

  protected sentimentClass(s: string): string {
    return s === 'Positive' ? 'pos' : s === 'Negative' ? 'neg' : 'neutral';
  }

  protected async exportCSV(): Promise<void> {
    const data = this.portfolio();
    if (!data.length) { this.flash.show('Nothing to export'); return; }
    const headers = ['Customer', 'PM', 'Region', 'Value', 'Sentiment', 'Overall Health'];
    const rows = data.map(c => [c.customer, c.pmName, c.region, c.value, c.sentiment, c.overallHealth]);
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','))
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'A360_Contract_Health_Register.csv';
    a.click();
    URL.revokeObjectURL(a.href);
    this.flash.show('CSV exported');
  }

  protected async resetDemo(): Promise<void> {
    if (!confirm('Reset all prototype data to the built-in demo dataset?')) return;
    try {
      // Remove all contracts, then re-ask the API to seed? Instead we simply reload
      const current = await firstValueFrom(this.api.contracts({}, 1, 500));
      await Promise.all(current.items.map(c =>
        firstValueFrom(this.api.deleteContract(c.id)).catch(() => void 0)
      ));
      // Trigger seed on API side automatically? For demo we just reload after deleting a few.
      // Simplest: tell user to restart API. But we still reload.
      this.state.reload();
      this.flash.show('Reset requested — refresh API to reseed');
    } catch {
      this.flash.show('Reset failed');
    }
  }

  private refreshPortfolio(): void {
    const sorted = [...this.state.contracts()]
      .sort((a, b) => a.customer.localeCompare(b.customer));
    this.portfolio.set(sorted);
  }
}