import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { FlashService } from '../services/flash.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const flash = inject(FlashService);

  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      const detail = (err.error as { detail?: string; title?: string } | null)?.detail
        ?? (err.error as { title?: string } | null)?.title
        ?? err.message;
      flash.show(`${err.status} · ${detail}`);
      return throwError(() => err);
    })
  );
};