import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  Contract, Meeting, PerformanceManager, PagedResult, DashboardSummary,
  CreateContractRequest, UpdateKpiRequest, CreateMeetingRequest,
  CreatePerformanceManagerRequest,
} from '../models/a360.models';

const BASE = 'https://localhost:7155/api/a360';

/**
 * A360 · API Service
 * Uses Angular 22's fetch() backed HttpClient.
 */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);

  // ============ Dashboard ============
  dashboardSummary(f: Record<string, string>): Observable<DashboardSummary> {
    return this.http.get<DashboardSummary>(`${BASE}/dashboard/summary`, { params: this.toParams(f) });
  }

  // ============ Contracts ============
  contracts(f: Record<string, string>, page = 1, pageSize = 500): Observable<PagedResult<Contract>> {
    const params = { ...f, page: String(page), pageSize: String(pageSize) };
    return this.http.get<PagedResult<Contract>>(`${BASE}/contracts`, { params: this.toParams(params) });
  }

  contract(id: number): Observable<Contract> {
    return this.http.get<Contract>(`${BASE}/contracts/${id}`);
  }

  createContract(body: CreateContractRequest): Observable<Contract> {
    return this.http.post<Contract>(`${BASE}/contracts`, body);
  }

  deleteContract(id: number): Observable<void> {
    return this.http.delete<void>(`${BASE}/contracts/${id}`);
  }

  updateKpi(body: UpdateKpiRequest): Observable<{ ok: boolean }> {
    return this.http.post<{ ok: boolean }>(`${BASE}/contract-health`, body);
  }

  // ============ Meetings ============
  meetings(f: Record<string, string> = {}, page = 1, pageSize = 500): Observable<PagedResult<Meeting>> {
    return this.http.get<PagedResult<Meeting>>(`${BASE}/meetings`, {
      params: this.toParams({ ...f, page: String(page), pageSize: String(pageSize) }),
    });
  }

  createMeeting(body: CreateMeetingRequest): Observable<Meeting> {
    return this.http.post<Meeting>(`${BASE}/meetings`, body);
  }

  updateActionStatus(id: number, status: string): Observable<{ ok: boolean }> {
    return this.http.patch<{ ok: boolean }>(`${BASE}/actions/${id}`, { status });
  }

  deleteAction(id: number): Observable<void> {
    return this.http.delete<void>(`${BASE}/actions/${id}`);
  }

  // ============ Performance Managers ============
  performanceManagers(): Observable<readonly PerformanceManager[]> {
    return this.http.get<readonly PerformanceManager[]>(`${BASE}/performance-managers`);
  }

  createPerformanceManager(body: CreatePerformanceManagerRequest): Observable<PerformanceManager> {
    return this.http.post<PerformanceManager>(`${BASE}/performance-managers`, body);
  }

  deletePerformanceManager(id: string): Observable<void> {
    return this.http.delete<void>(`${BASE}/performance-managers/${id}`);
  }

  private toParams(o: Record<string, string | number>): HttpParams {
    let params = new HttpParams();
    for (const [k, v] of Object.entries(o)) {
      if (v !== null && v !== undefined && v !== '') params = params.set(k, String(v));
    }
    return params;
  }
}