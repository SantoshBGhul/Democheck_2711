import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { StateService } from '../../services/state';
import { MeetingWizardService } from '../../../components/meeting-wizard/meeting-wizard.service';

interface NavItem {
  readonly path: string;
  readonly label: string;
  readonly icon: string;
}

@Component({
  selector: 'app-topbar',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, FormsModule],
  templateUrl: './topbar.html',
})
export class Topbar {
  private readonly state = inject(StateService);
  private readonly wizard = inject(MeetingWizardService);
  private readonly router = inject(Router);

  protected readonly searchTerm = signal('');

  protected readonly nav: readonly NavItem[] = [
    {
      path: '/dashboard', label: 'Dashboard',
      icon: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>'
    },
    {
      path: '/meetings', label: 'Meetings',
      icon: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'
    },
    {
      path: '/actions', label: 'Actions',
      icon: '<polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>'
    },
    {
      path: '/admin', label: 'Admin',
      icon: '<path d="M12 2 4 6v6c0 5 3.4 9.4 8 10 4.6-.6 8-5 8-10V6z"/><path d="M12 11v4"/><path d="M12 8h.01"/>'
    },
  ];

  protected onSearch(value: string): void {
    this.searchTerm.set(value);
    const s = value.trim().toLowerCase();

    if (!s) {
      this.state.setFilter('customer', 'All');
      return;
    }
    const match = this.state.contracts().find(c => c.customer.toLowerCase().includes(s));
    if (match) this.state.setFilter('customer', match.customer);
  }

  protected openWizard(): void {
    const first = this.state.contracts()[0]?.id;
    this.wizard.open(first);
  }

  protected goToActions(): void {
    void this.router.navigate(['/actions']);
  }
}