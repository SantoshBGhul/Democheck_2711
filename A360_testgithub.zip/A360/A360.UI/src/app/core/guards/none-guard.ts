import { CanActivateFn } from '@angular/router';

export const noneGuard: CanActivateFn = (route, state) => {
  return true;
};
