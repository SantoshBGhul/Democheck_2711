import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { StateService } from '../../core/services/state';

interface KpiTile {
  readonly label: string;
  readonly value: string;
  readonly sub: string;
  readonly bar: string;
}

@Component({
  selector: 'app-kpi-strip',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './kpi-strip.html',
})
export class KpiStrip {
  private readonly state = inject(StateService);

  protected readonly tiles = computed<readonly KpiTile[]>(() => {
    const s = this.state.summary();
    if (!s || s.score === undefined) return [];

    const accentBar = 'linear-gradient(180deg,#818cf8,#4f46e5)';
    return [
      { label: 'Overall Health', value: `${s.score}/100`, sub: s.state, bar: accentBar },
      { label: 'Contracts', value: String(s.total), sub: 'Current view', bar: '#eef1f8' },
      { label: 'Green', value: String(s.green), sub: 'Healthy', bar: 'linear-gradient(180deg,#34d399,#0ea472)' },
      { label: 'Yellow', value: String(s.yellow), sub: 'Watch', bar: 'linear-gradient(180deg,#fbbf24,#eab308)' },
      { label: 'Orange', value: String(s.orange), sub: 'Attention', bar: 'linear-gradient(180deg,#fb923c,#f97316)' },
      { label: 'Red', value: String(s.red), sub: 'Critical', bar: 'linear-gradient(180deg,#f87171,#ef4444)' },
      { label: 'Contract Value', value: `$${(s.contractValue?? 0).toFixed(1)}M`, sub: 'Current view', bar: accentBar },
      { label: 'Value at Risk', value: `$${(s.riskValue?? 0).toFixed(1)}M`, sub: 'Illustrative', bar: 'linear-gradient(180deg,#f87171,#ef4444)' },
    ];
  });
}