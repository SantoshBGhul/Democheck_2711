import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { StateService } from '../../core/services/state';
import { Contract, HealthStatus, statusScore, statusRank } from '../../core/models/a360.models';

interface DimTile {
  readonly icon: string;
  readonly label: string;
  readonly score: number;
  readonly state: 'GOOD' | 'ATTENTION' | 'CRITICAL';
}

interface A360View {
  readonly score: number;
  readonly state: 'HEALTHY' | 'WATCH' | 'ATTENTION' | 'CRITICAL';
  readonly dims: readonly DimTile[];
}

@Component({
  selector: 'app-a360-summary',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './a360-summary.html',
})
export class A360Summary {
  private readonly state = inject(StateService);

  protected readonly view = computed<A360View>(() => this.compute(this.state.contracts()));

  protected ringColor(score: number): string {
    if (score >= 80) return '#0ea472';
    if (score >= 45) return '#f97316';
    return '#ef4444';
  }
  protected statusColor(state: DimTile['state']): string {
    if (state === 'GOOD') return 'text-emerald-700';
    if (state === 'ATTENTION') return 'text-orange-700';
    return 'text-red-700';
  }

  private compute(contracts: readonly Contract[]): A360View {
    const d = contracts;
    const avg = (arr: number[], def = 0) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : def);
    const score = this.computeScore(d);

    const dimValue = (field: keyof Contract): number =>
      Math.round(avg(d.map(c => statusScore(c[field] as HealthStatus))));

    const stateFor = (s: number): DimTile['state'] =>
      s >= 80 ? 'GOOD' : s >= 45 ? 'ATTENTION' : 'CRITICAL';

    const customerScore = Math.round(avg(d.map(c =>
      c.sentiment === 'Positive' ? 85 : c.sentiment === 'Negative' ? 42 : 68)));

    const dims: DimTile[] = [
      { icon: '●', label: 'Customer', score: customerScore, state: stateFor(customerScore) },
      { icon: '◎', label: 'Outcomes', score: dimValue('outcomeKpi'), state: stateFor(dimValue('outcomeKpi')) },
      { icon: '⚙', label: 'Delivery', score: dimValue('deliveryHealth'), state: stateFor(dimValue('deliveryHealth')) },
      { icon: '▤', label: 'Financial', score: dimValue('financialHealth'), state: stateFor(dimValue('financialHealth')) },
      { icon: '◈', label: 'Risk', score: dimValue('riskHealth'), state: stateFor(dimValue('riskHealth')) },
    ];

    return {
      score,
      state: score >= 80 ? 'HEALTHY' : score >= 65 ? 'WATCH' : score >= 45 ? 'ATTENTION' : 'CRITICAL',
      dims,
    };
  }

  private computeScore(d: readonly Contract[]): number {
    if (!d.length) return 0;
    let sum = 0, cnt = 0;
    for (const c of d) {
      const vals: HealthStatus[] = [
        c.outcomeKpi, c.topCustomerPriority, c.next90DayRisk, c.pfmAction, c.managementSupport,
        c.marginChecked, c.billingForecastUpdated, c.pastDues, c.sespBgpCostsChecked,
        c.renewalOnTime, c.tracker2026, c.tracker2027,
        c.idpCompleted, c.hpdResultsUpdated, c.siopCompleted,
        c.sfdcTasksClosed, c.reportingStandard, c.customerMeetingsPlanned,
        c.digitalPrimeDashboard, c.contractSetupCorrect, c.a360OpsDashboard,
        c.npsShared, c.mosCompleted, c.deliveryHealth, c.financialHealth, c.riskHealth, c.renewalHealth,
      ].filter(v => v && v !== 'Blank');

      if (!vals.length) continue;
      sum += vals.reduce((s, v) => s + statusScore(v), 0) / vals.length;
      cnt++;
    }
    return cnt ? Math.round(sum / cnt) : 0;
  }
}