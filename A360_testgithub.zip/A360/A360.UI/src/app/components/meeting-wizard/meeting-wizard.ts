import {
  ChangeDetectionStrategy, Component, computed, effect, inject, signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { MeetingWizardService } from './meeting-wizard.service';
import { StateService } from '../../core/services/state';
import { ApiService } from '../../core/services/api';
import { FlashService } from '../../core/services/flash.service';
import {
  ALL_KPIS, HEALTH_STATUSES, KPI_GROUPS,
  Contract, HealthStatus, KpiDefinition, KpiGroup, GroupCommentKey,
} from '../../core/models/a360.models';

type KpiSelections = Record<string, string>;
type GroupComments = Record<GroupCommentKey, string>;

const EMPTY_COMMENTS: GroupComments = {
  customer: '', financial: '', growth: '', people: '', internal: '',
};

@Component({
  selector: 'app-meeting-wizard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  templateUrl: './meeting-wizard.html',
})
export class MeetingWizard {
  private readonly wizardSvc = inject(MeetingWizardService);
  private readonly state = inject(StateService);
  private readonly api = inject(ApiService);
  private readonly flash = inject(FlashService);

  protected readonly wizard = this.wizardSvc;
  protected readonly kpiGroups = KPI_GROUPS;
  protected readonly statuses = HEALTH_STATUSES;

  // Step 1: two groups shown at once
  protected readonly step2Groups: readonly KpiGroup[] = [KPI_GROUPS[0], KPI_GROUPS[1]];
  // Step 3: three groups shown at once
  protected readonly step3Groups: readonly KpiGroup[] = [KPI_GROUPS[2], KPI_GROUPS[3], KPI_GROUPS[4]];

  protected readonly step = signal(1);

  // ============ Form state ============
  protected readonly selectedContractId = signal<number | undefined>(undefined);
  protected readonly pmName = signal('');
  protected readonly meetingDate = signal(new Date().toISOString().slice(0, 10));
  protected readonly meetingType = signal('Monthly 1:1');
  protected readonly sentiment = signal('');
  protected readonly valueDelivered = signal('');
  protected readonly concern = signal('');
  protected readonly customerAction = signal('');
  protected readonly next90Risk = signal('');

  protected readonly kpiSelections = signal<KpiSelections>({});
  protected readonly groupComments = signal<GroupComments>({ ...EMPTY_COMMENTS });

  protected readonly pfmAction = signal('');
  protected readonly mgmtSupport = signal('');
  protected readonly owner = signal('');
  protected readonly due = signal('');
  protected readonly action = signal('');

  protected readonly activeContract = computed<Contract | undefined>(() =>
    this.state.contracts().find(c => c.id === this.selectedContractId())
  );

  protected readonly selectionPreview = computed(() => {
    const vals = Object.values(this.kpiSelections());
    return {
      total: vals.length,
      green:  vals.filter(v => v === 'Green').length,
      yellow: vals.filter(v => v === 'Yellow').length,
      orange: vals.filter(v => v === 'Orange').length,
      red:    vals.filter(v => v === 'Red').length,
    };
  });

  protected readonly reviewValue = computed(() =>
    this.valueDelivered().trim() || 'Not entered');
  protected readonly reviewConcern = computed(() =>
    this.concern().trim() || 'Not entered');
  protected readonly reviewCustomerAction = computed(() =>
    this.customerAction().trim() || 'Not entered');
  protected readonly review90Risk = computed(() =>
    this.next90Risk() || 'Not assessed');

  constructor() {
    effect(() => {
      if (!this.wizardSvc.isOpen()) return;
      const id = this.wizardSvc.contractId() ?? this.state.contracts()[0]?.id;
      if (id) this.loadContract(id);
    });
  }

  // ============ Loading ============
  protected loadContract(id: number): void {
    const c = this.state.contracts().find(x => x.id === id);
    if (!c) return;

    this.selectedContractId.set(id);
    this.pmName.set(c.pmName);
    this.sentiment.set(c.sentiment === 'Blank' ? '' : c.sentiment);
    this.valueDelivered.set(c.valueDelivered || '');
    this.concern.set(c.concern || '');
    this.customerAction.set(c.customerAction || '');
    this.next90Risk.set(c.next90DayRisk === 'Blank' ? '' : c.next90DayRisk);
    this.pfmAction.set(c.pfmActionText || '');
    this.mgmtSupport.set(c.managementSupportText || '');

    this.groupComments.set({
      customer:  c.commentCustomer || '',
      financial: c.commentFinancial || '',
      growth:    c.commentGrowth || '',
      people:    c.commentPeople || '',
      internal:  c.commentInternal || '',
    });

    const selections: KpiSelections = {};
    for (const k of ALL_KPIS) {
      const v = c[k.key] as HealthStatus;
      if (v && v !== 'Blank') selections[k.key as string] = v;
    }
    this.kpiSelections.set(selections);
    this.step.set(1);
  }

  protected onCustomerChange(id: number): void { this.loadContract(id); }

  // ============ KPI handling ============
  protected getKpi(key: KpiDefinition['key']): string {
    return this.kpiSelections()[key as string] ?? '';
  }

  protected setKpi(key: KpiDefinition['key'], value: HealthStatus): void {
    this.kpiSelections.update(s => ({ ...s, [key as string]: value }));
  }

  protected clearKpi(key: KpiDefinition['key']): void {
    this.kpiSelections.update(s => {
      const { [key as string]: _, ...rest } = s;
      return rest;
    });
  }

  protected setGroup(groupId: string, status: HealthStatus): void {
    const defs = KPI_GROUPS.find(g => g.id === groupId)?.defs ?? [];
    this.kpiSelections.update(s => {
      const next = { ...s };
      for (const d of defs) next[d.key as string] = status;
      return next;
    });
  }

  protected clearGroup(groupId: string): void {
    const defs = KPI_GROUPS.find(g => g.id === groupId)?.defs ?? [];
    this.kpiSelections.update(s => {
      const next = { ...s };
      for (const d of defs) delete next[d.key as string];
      return next;
    });
  }

  // ============ Group comments ============
  protected getGroupComment(key: GroupCommentKey): string {
    return this.groupComments()[key] ?? '';
  }

  protected setGroupComment(key: GroupCommentKey, value: string): void {
    this.groupComments.update(c => ({ ...c, [key]: value }));
  }

  // ============ Sentiment / Risk ============
  protected setSentiment(v: string): void { this.sentiment.set(v); }
  protected setRisk90(v: string): void { this.next90Risk.set(v); }

  // ============ Steps ============
  protected next(): void {
    if (this.step() === 1 && !this.selectedContractId()) {
      this.flash.show('Select a customer');
      return;
    }
    this.step.update(s => Math.min(4, s + 1));
  }
  protected prev(): void { this.step.update(s => Math.max(1, s - 1)); }
  protected close(): void { this.wizardSvc.close(); }

  // ============ Styling helpers ============
  protected sentimentActiveCls(v: string): string {
    if (this.sentiment() !== v) return 'bg-slate-50 text-slate-500 border-slate-200';
    switch (v) {
      case 'Positive': return 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-2 ring-offset-1';
      case 'Negative': return 'bg-red-50 text-red-800 border-red-300 ring-2 ring-offset-1';
      case 'Neutral':  return 'bg-slate-100 text-slate-700 border-slate-300 ring-2 ring-offset-1';
      default:         return 'bg-slate-100 text-slate-500 border-slate-300';
    }
  }

  protected riskCls(v: string): string {
    if (this.next90Risk() !== v) return 'bg-slate-50 text-slate-500 border-slate-200';
    switch (v) {
      case 'Green':  return 'bg-emerald-50 text-emerald-800 border-emerald-300';
      case 'Yellow': return 'bg-yellow-50 text-yellow-800 border-yellow-300';
      case 'Orange': return 'bg-orange-50 text-orange-800 border-orange-300';
      case 'Red':    return 'bg-red-50 text-red-800 border-red-300';
      default:       return 'bg-slate-200 text-slate-700 border-slate-300';
    }
  }

  protected kpiCls(st: HealthStatus, current: string): string {
    const active = st === current;
    if (!active) return 'bg-slate-50 text-slate-500 border-slate-200';
    switch (st) {
      case 'Green':  return 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-2 ring-offset-1';
      case 'Yellow': return 'bg-yellow-50 text-yellow-800 border-yellow-300 ring-2 ring-offset-1';
      case 'Orange': return 'bg-orange-50 text-orange-800 border-orange-300 ring-2 ring-offset-1';
      case 'Red':    return 'bg-red-50 text-red-800 border-red-300 ring-2 ring-offset-1';
    }
    return 'bg-slate-50 text-slate-500 border-slate-200';
  }

  // ============ Save ============
  protected async save(): Promise<void> {
    const cid = this.selectedContractId();
    if (!cid) { this.flash.show('Select a contract'); return; }

    const body = {
      contractId: cid,
      pmName: this.pmName(),
      meetingDate: this.meetingDate(),
      meetingType: this.meetingType(),
      sentiment: this.sentiment() || 'Blank',
      valueDelivered: this.valueDelivered(),
      concern: this.concern(),
      customerAction: this.customerAction(),
      pfmAction: this.pfmAction(),
      managementSupport: this.mgmtSupport(),
      next90DayRisk: this.next90Risk() || 'Blank',
      owner: this.owner(),
      due: this.due() || null,
      action: this.action(),
      healthSnapshot: this.kpiSelections(),
      groupComments: this.groupComments() as unknown as Record<string, string>,
    };

    try {
      await firstValueFrom(this.api.createMeeting(body));
      this.flash.show('Meeting saved — dashboard and contract health updated');
      this.wizardSvc.close();
      this.state.reload();
    } catch { /* global interceptor shows error */ }
  }
}