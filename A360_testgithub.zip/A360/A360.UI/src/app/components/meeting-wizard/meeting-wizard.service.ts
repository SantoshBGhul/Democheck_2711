import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class MeetingWizardService {
  readonly isOpen = signal(false);
  readonly contractId = signal<number | undefined>(undefined);

  open(id?: number): void {
    this.contractId.set(id);
    this.isOpen.set(true);
  }

  close(): void {
    this.isOpen.set(false);
  }
}