import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { FlashService } from '../../core/services/flash.service';

@Component({
  selector: 'app-flash-toast',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './flash-toast.html',
})
export class FlashToast {
  protected readonly flash = inject(FlashService);
}