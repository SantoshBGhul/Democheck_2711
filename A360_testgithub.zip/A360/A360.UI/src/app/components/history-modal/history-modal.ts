import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-history-modal',
  styles: ``,
  templateUrl: './history-modal.html',
})
export class HistoryModal {}
