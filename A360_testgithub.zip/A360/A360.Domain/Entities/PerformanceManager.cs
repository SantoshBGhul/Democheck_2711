﻿namespace A360.Domain.Entities;

public sealed class PerformanceManager
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = string.Empty;
    public string Region { get; set; } = "EMEA";
    public string? Email { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public ICollection<Contract> Contracts { get; set; } = [];
}