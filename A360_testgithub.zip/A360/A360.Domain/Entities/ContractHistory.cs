﻿using A360.Domain.Enums;

namespace A360.Domain.Entities;

public sealed class ContractHistory
{
    public int Id { get; set; }
    public int ContractId { get; set; }
    public Contract? Contract { get; set; }
    public string Month { get; set; } = string.Empty;
    public HealthStatus Overall { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
