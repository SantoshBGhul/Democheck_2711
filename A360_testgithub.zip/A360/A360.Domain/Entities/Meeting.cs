﻿using A360.Domain.Enums;

namespace A360.Domain.Entities;

public sealed class Meeting
{
    public int Id { get; set; }
    public int ContractId { get; set; }
    public Contract? Contract { get; set; }
    public string Customer { get; set; } = string.Empty;
    public string PmName { get; set; } = string.Empty;
    public DateTime MeetingDate { get; set; }
    public string MeetingType { get; set; } = "Monthly 1:1";
    public Sentiment Sentiment { get; set; }
    public string? ValueDelivered { get; set; }
    public string? Concern { get; set; }
    public string? CustomerAction { get; set; }
    public string? PfmAction { get; set; }
    public string? ManagementSupport { get; set; }
    public HealthStatus Next90DayRisk { get; set; }

    public string? Action { get; set; }
    public string? Owner { get; set; }
    public DateTime? Due { get; set; }
    public ActionStatus ActionStatus { get; set; } = ActionStatus.Open;
    public string Source { get; set; } = "Meeting workspace";

    public string? HealthSnapshotJson { get; set; }
    public string? GroupCommentsJson { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
