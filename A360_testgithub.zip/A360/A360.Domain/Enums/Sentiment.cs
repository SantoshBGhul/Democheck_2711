﻿namespace A360.Domain.Enums;

public enum Sentiment : byte
{
    Blank = 0,
    Positive = 1,
    Neutral = 2,
    Negative = 3
}
