﻿namespace A360.Domain.Enums;

public enum ActionStatus : byte
{
    Open = 0,
    InProgress = 1,
    Completed = 2
}