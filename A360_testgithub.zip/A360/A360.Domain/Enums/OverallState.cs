﻿namespace A360.Domain.Enums;

public enum OverallState : byte
{
    Blank = 0, Healthy = 1, Watch = 2, Attention = 3, Critical = 4
}