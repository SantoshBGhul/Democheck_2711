﻿namespace A360.Domain.Enums;

public enum HealthStatus : byte
{
    Blank = 0,
    Green = 1,
    Yellow = 2,
    Orange = 3,
    Red = 4
}