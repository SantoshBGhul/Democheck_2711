using A360.API.Endpoints;
using A360.API.Middleware;
using A360.Application.Interfaces;
using A360.Application.Services;
using A360.Domain.Interfaces;
using A360.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// SQL Server 2025 via EF Core 10
builder.Services.AddDbContext<A360DbContext>(opt =>
    opt.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sql => sql.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null)));

// N-Tier DI
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<IContractService, ContractService>();
builder.Services.AddScoped<IMeetingService, MeetingService>();
builder.Services.AddScoped<IPerformanceManagerService, PerformanceManagerService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();

// Cross-cutting
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "A360 Contract Health API", Version = "v1" });
});

builder.Services.AddCors(o => o.AddPolicy("Angular", p =>
    p.WithOrigins("http://localhost:4200")
     .AllowAnyHeader()
     .AllowAnyMethod()
     .AllowCredentials()));

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();
app.UseCors("Angular");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// =======================  API ROUTES  =======================
var api = app.MapGroup("/api/a360");

api.MapDashboardEndpoints();
api.MapContractEndpoints();
api.MapContractHealthEndpoints();
api.MapMeetingEndpoints();
api.MapActionEndpoints();
api.MapPerformanceManagerEndpoints();

// =======================  SEED  =======================
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<A360DbContext>();
    await DbSeeder.SeedAsync(db);
}

app.Run();