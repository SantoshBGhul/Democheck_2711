﻿using A360.Application.DTOs;
using A360.Application.Interfaces;

namespace A360.API.Endpoints;

public static class ContractEndpoints
{
    public static RouteGroupBuilder MapContractEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/contracts").WithTags("Contracts");

        group.MapGet("/", async (IContractService svc,
            int page = 1, int pageSize = 50,
            string? pm = null, string? customer = null, string? region = null,
            string? month = null, string? health = null, string? sentiment = null,
            CancellationToken ct = default) =>
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, 200);
            var result = await svc.GetPagedAsync(page, pageSize, pm, customer, region, month, health, sentiment, ct);
            return Results.Ok(result);
        })
        .WithName("ListContracts")
        .Produces<Application.DTOs.PagedResultDto<ContractListDto>>();

        group.MapGet("/filtered", async (IContractService svc,
            string? pm, string? customer, string? region, string? month,
            string? health, string? sentiment, CancellationToken ct) =>
        {
            var result = await svc.GetFilteredAsync(pm, customer, region, month, health, sentiment, ct);
            return Results.Ok(result);
        });

        group.MapGet("/{id:int}", async (int id, IContractService svc, CancellationToken ct) =>
        {
            var dto = await svc.GetByIdAsync(id, ct);
            return dto is null ? Results.NotFound() : Results.Ok(dto);
        })
        .Produces<ContractListDto>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound);

        group.MapPost("/", async (CreateContractDto dto, IContractService svc, CancellationToken ct) =>
        {
            var created = await svc.CreateAsync(dto, ct);
            return Results.Created($"/api/a360/contracts/{created.Id}", created);
        })
        .Produces<ContractListDto>(StatusCodes.Status201Created)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status409Conflict);

        group.MapDelete("/{id:int}", async (int id, IContractService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            return ok ? Results.NoContent() : Results.NotFound();
        });

        return group;
    }

    public static RouteGroupBuilder MapContractHealthEndpoints(this RouteGroupBuilder api)
    {
        api.MapPost("/contract-health", async (UpdateKpiDto dto, IContractService svc, CancellationToken ct) =>
        {
            await svc.UpdateKpiAsync(dto, ct);
            return Results.Ok(new { ok = true });
        })
        .WithTags("Contract Health")
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status404NotFound);

        return api;
    }
}