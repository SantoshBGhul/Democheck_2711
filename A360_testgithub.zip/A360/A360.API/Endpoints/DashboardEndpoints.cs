﻿using A360.Application.Interfaces;

namespace A360.API.Endpoints;

public static class DashboardEndpoints
{
    public static RouteGroupBuilder MapDashboardEndpoints(this RouteGroupBuilder api)
    {
        api.MapGet("/dashboard/summary", async (IDashboardService svc,
            string? pm, string? customer, string? region, string? month,
            string? health, string? sentiment, CancellationToken ct) =>
        {
            var result = await svc.GetSummaryAsync(pm, customer, region, month, health, sentiment, ct);
            return Results.Ok(result);
        })
        .WithTags("Dashboard")
        .Produces<Application.DTOs.DashboardSummaryDto>();

        return api;
    }
}