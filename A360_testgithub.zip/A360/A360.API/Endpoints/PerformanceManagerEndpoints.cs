﻿using A360.Application.DTOs;
using A360.Application.Interfaces;

namespace A360.API.Endpoints;

public static class PerformanceManagerEndpoints
{
    public static RouteGroupBuilder MapPerformanceManagerEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/performance-managers").WithTags("Performance Managers");

        group.MapGet("/", async (IPerformanceManagerService svc, CancellationToken ct) =>
            Results.Ok(await svc.GetAllAsync(ct)));

        group.MapPost("/", async (CreatePerformanceManagerDto dto,
            IPerformanceManagerService svc, CancellationToken ct) =>
        {
            var created = await svc.CreateAsync(dto, ct);
            return Results.Created($"/api/a360/performance-managers/{created.Id}", created);
        })
        .Produces<PerformanceManagerDto>(StatusCodes.Status201Created)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status409Conflict);

        group.MapDelete("/{id:guid}", async (Guid id,
            IPerformanceManagerService svc, CancellationToken ct) =>
        {
            var ok = await svc.DeleteAsync(id, ct);
            return ok ? Results.NoContent() : Results.NotFound();
        });

        return group;
    }
}