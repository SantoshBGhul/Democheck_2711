﻿namespace A360.Application.DTOs;

public sealed record ContractListDto(
    int Id, string Customer, string PmName, string Region,
    decimal Value, decimal RiskValue,
    string Sentiment, DateTime LastMeetingDate,
    string OverallHealth,
    string ValueDelivered, string Concern, string CustomerAction,
    string PfmActionText, string ManagementSupportText,
    string OutcomeKpi, string TopCustomerPriority, string Next90DayRisk,
    string PfmAction, string ManagementSupport,
    string MarginChecked, string BillingForecastUpdated, string PastDues, string SespBgpCostsChecked,
    string RenewalOnTime, string Tracker2026, string Tracker2027,
    string IdpCompleted, string HpdResultsUpdated, string SiopCompleted,
    string SfdcTasksClosed, string ReportingStandard, string CustomerMeetingsPlanned,
    string DigitalPrimeDashboard, string ContractSetupCorrect, string A360OpsDashboard,
    string NpsShared, string MosCompleted,
    string DeliveryHealth, string FinancialHealth, string RiskHealth, string RenewalHealth,
    string CommentCustomer, string CommentFinancial, string CommentGrowth,
    string CommentPeople, string CommentInternal,
    IReadOnlyList<ContractHistoryDto> History);

public sealed record ContractHistoryDto(string Month, string Overall);

public sealed record CreateContractDto(string Customer, string PmName, string Region, decimal Value);

public sealed record UpdateKpiDto(int ContractId, string Key, string Value);

public sealed record MeetingListDto(
    int Id, int ContractId, string Customer, string PmName, DateTime MeetingDate,
    string MeetingType, string Sentiment, string Action, string Owner,
    DateTime? Due, string ActionStatus, string Source, DateTime UpdatedAt);

public sealed record CreateMeetingDto(
    int ContractId, string PmName, DateTime MeetingDate, string MeetingType,
    string Sentiment, string? ValueDelivered, string? Concern,
    string? CustomerAction, string? PfmAction, string? ManagementSupport,
    string Next90DayRisk, string? Owner, DateTime? Due, string? Action,
    Dictionary<string, string>? HealthSnapshot,
    Dictionary<string, string>? GroupComments);

public sealed record PerformanceManagerDto(Guid Id, string Name, string Region, string? Email, int AccountCount);

public sealed record CreatePerformanceManagerDto(string Name, string Region, string? Email);

public sealed record UpdateActionStatusDto(string Status);

public sealed record DashboardSummaryDto(
    int Score, string State, int Total, int Green, int Yellow, int Orange, int Red,
    decimal ContractValue, decimal RiskValue, int PositivePct);

public sealed record ApiError(string Code, string Message, string? Field = null);