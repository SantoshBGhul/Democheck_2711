﻿namespace A360.Application.Common;

public sealed class DomainException(string code, string message) : Exception(message)
{
    public string Code { get; } = code;
}

public sealed class NotFoundException(string message) : Exception(message);
public sealed class ValidationAppException(string message) : Exception(message);
public sealed class ConflictException(string message) : Exception(message);