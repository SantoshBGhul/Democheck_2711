﻿namespace A360.Application.Common;

public sealed record KpiDefinition(string Key, string Label, string Group);

public static class KpiCatalog
{
    public static readonly IReadOnlyList<KpiDefinition> Customer =
    [
        new("outcomeKpi", "Outcome KPI achievement", "Customer"),
        new("topCustomerPriority", "Top customer priority", "Customer"),
        new("next90DayRisk", "Next 90-day risk", "Customer"),
        new("pfmAction", "PFM action", "Customer"),
        new("managementSupport", "Management support required", "Customer")
    ];

    public static readonly IReadOnlyList<KpiDefinition> Financial =
    [
        new("marginChecked", "Margin checked in profitability file", "Financial"),
        new("billingForecastUpdated", "Billing Forecast updated", "Financial"),
        new("pastDues", "Past Due's", "Financial"),
        new("sespBgpCostsChecked", "SESP & BGP costs checked", "Financial")
    ];

    public static readonly IReadOnlyList<KpiDefinition> Growth =
    [
        new("renewalOnTime", "Renewal OnTime", "Growth"),
        new("tracker2026", "Tracker 2026 updated", "Growth"),
        new("tracker2027", "Tracker 2027 updated", "Growth")
    ];

    public static readonly IReadOnlyList<KpiDefinition> People =
    [
        new("idpCompleted", "IDP completed", "People"),
        new("hpdResultsUpdated", "HPD results updated", "People"),
        new("siopCompleted", "SIOP completed", "People")
    ];

    public static readonly IReadOnlyList<KpiDefinition> Internal =
    [
        new("sfdcTasksClosed", "SFDC Tasks Closed", "Internal"),
        new("reportingStandard", "Reporting according to our standard", "Internal"),
        new("customerMeetingsPlanned", "Customer meetings planned", "Internal"),
        new("digitalPrimeDashboard", "Digital Prime Dashboard in use?", "Internal"),
        new("contractSetupCorrect", "Contract setup in SFDC correct?", "Internal"),
        new("a360OpsDashboard", "A360 OPS Dashboard status", "Internal"),
        new("npsShared", "NPS Shared", "Internal"),
        new("mosCompleted", "MOS completed", "Internal")
    ];

    public static readonly IReadOnlyList<KpiDefinition> All =
        [.. Customer, .. Financial, .. Growth, .. People, .. Internal];
}
