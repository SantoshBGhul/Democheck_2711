﻿using A360.Domain.Entities;
using A360.Domain.Enums;

namespace A360.Application.Common;

public static class HealthMapper
{
    public static HealthStatus Parse(string? v)
        => Enum.TryParse<HealthStatus>(v, true, out var r) ? r : HealthStatus.Blank;

    public static Sentiment ParseSentiment(string? v)
        => Enum.TryParse<Sentiment>(v, true, out var r) ? r : Sentiment.Blank;

    public static int StatusScore(HealthStatus s) => s switch
    {
        HealthStatus.Green => 100,
        HealthStatus.Yellow => 80,
        HealthStatus.Orange => 60,
        HealthStatus.Red => 20,
        _ => 0
    };

    public static int StatusRank(HealthStatus s) => (int)s;

    /// <summary>Applies a KPI string key + value to a contract entity. Throws on unknown key.</summary>
    public static void ApplyKpi(Contract c, string key, string value)
    {
        var v = Parse(value);
        switch (key)
        {
            case "outcomeKpi": c.OutcomeKpi = v; break;
            case "topCustomerPriority": c.TopCustomerPriority = v; break;
            case "next90DayRisk": c.Next90DayRisk = v; break;
            case "pfmAction": c.PfmAction = v; break;
            case "managementSupport": c.ManagementSupport = v; break;
            case "marginChecked": c.MarginChecked = v; break;
            case "billingForecastUpdated": c.BillingForecastUpdated = v; break;
            case "pastDues": c.PastDues = v; break;
            case "sespBgpCostsChecked": c.SespBgpCostsChecked = v; break;
            case "renewalOnTime": c.RenewalOnTime = v; break;
            case "tracker2026": c.Tracker2026 = v; break;
            case "tracker2027": c.Tracker2027 = v; break;
            case "idpCompleted": c.IdpCompleted = v; break;
            case "hpdResultsUpdated": c.HpdResultsUpdated = v; break;
            case "siopCompleted": c.SiopCompleted = v; break;
            case "sfdcTasksClosed": c.SfdcTasksClosed = v; break;
            case "reportingStandard": c.ReportingStandard = v; break;
            case "customerMeetingsPlanned": c.CustomerMeetingsPlanned = v; break;
            case "digitalPrimeDashboard": c.DigitalPrimeDashboard = v; break;
            case "contractSetupCorrect": c.ContractSetupCorrect = v; break;
            case "a360OpsDashboard": c.A360OpsDashboard = v; break;
            case "npsShared": c.NpsShared = v; break;
            case "mosCompleted": c.MosCompleted = v; break;
            default: throw new ArgumentException($"Unknown KPI key '{key}'.");
        }
    }

    public static string ToString(HealthStatus s) => s == HealthStatus.Blank ? "Blank" : s.ToString();
    public static string ToString(Sentiment s) => s == Sentiment.Blank ? "Blank" : s.ToString();
}