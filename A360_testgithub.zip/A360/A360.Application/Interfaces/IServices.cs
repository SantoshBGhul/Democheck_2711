﻿using A360.Application.DTOs;
using A360.Domain.Interfaces;

namespace A360.Application.Interfaces;

public interface IContractService
{
    Task<PagedResult<ContractListDto>> GetPagedAsync(int page, int pageSize,
        string? pm, string? customer, string? region, string? month,
        string? health, string? sentiment, CancellationToken ct = default);

    Task<IReadOnlyList<ContractListDto>> GetFilteredAsync(
        string? pm, string? customer, string? region, string? month,
        string? health, string? sentiment, CancellationToken ct = default);

    Task<ContractListDto?> GetByIdAsync(int id, CancellationToken ct = default);
    Task<ContractListDto> CreateAsync(CreateContractDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(int id, CancellationToken ct = default);
    Task UpdateKpiAsync(UpdateKpiDto dto, CancellationToken ct = default);
}

public interface IMeetingService
{
    Task<PagedResult<MeetingListDto>> GetPagedAsync(int page, int pageSize,
        string? customer, CancellationToken ct = default);
    Task<MeetingListDto> CreateAsync(CreateMeetingDto dto, CancellationToken ct = default);
    Task UpdateActionStatusAsync(int id, UpdateActionStatusDto dto, CancellationToken ct = default);
    Task DeleteActionAsync(int id, CancellationToken ct = default);
}

public interface IPerformanceManagerService
{
    Task<IReadOnlyList<PerformanceManagerDto>> GetAllAsync(CancellationToken ct = default);
    Task<PerformanceManagerDto> CreateAsync(CreatePerformanceManagerDto dto, CancellationToken ct = default);
    Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);
}

public interface IDashboardService
{
    Task<DashboardSummaryDto> GetSummaryAsync(string? pm, string? customer, string? region,
        string? month, string? health, string? sentiment, CancellationToken ct = default);
}
