﻿using A360.Application.Common;
using A360.Application.DTOs;
using A360.Application.Interfaces;
using A360.Domain.Entities;
using A360.Domain.Interfaces;

namespace A360.Application.Services;

public sealed class PerformanceManagerService(
    IRepository<PerformanceManager> pms,
    IRepository<Contract> contracts) : IPerformanceManagerService
{
    public async Task<IReadOnlyList<PerformanceManagerDto>> GetAllAsync(CancellationToken ct = default)
    {
        var all = await pms.ListAsync(ct: ct);
        var list = await contracts.ListAsync(ct: ct);

        return all.OrderBy(p => p.Name)
            .Select(p => new PerformanceManagerDto(
                p.Id, p.Name, p.Region, p.Email,
                list.Count(c => c.PmName == p.Name)))
            .ToList();
    }

    public async Task<PerformanceManagerDto> CreateAsync(CreatePerformanceManagerDto dto, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(dto.Name))
            throw new ValidationAppException("Name is required.");

        var name = dto.Name.Trim();
        var existing = await pms.ListAsync(p => p.Name.ToLower() == name.ToLower(), ct);
        if (existing.Count > 0)
            throw new ConflictException($"Performance Manager '{name}' already exists.");

        var entity = new PerformanceManager
        {
            Name = name,
            Region = dto.Region,
            Email = dto.Email
        };
        await pms.AddAsync(entity, ct);
        await pms.SaveChangesAsync(ct);
        return new PerformanceManagerDto(entity.Id, entity.Name, entity.Region, entity.Email, 0);
    }

    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var pm = await pms.GetByIdAsync(id, ct);
        if (pm is null) return false;
        pms.Remove(pm);
        await pms.SaveChangesAsync(ct);
        return true;
    }
}