﻿using A360.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace A360.Infrastructure.Data;

public sealed class A360DbContext(DbContextOptions<A360DbContext> options) : DbContext(options)
{
    public DbSet<PerformanceManager> PerformanceManagers => Set<PerformanceManager>();
    public DbSet<Contract> Contracts => Set<Contract>();
    public DbSet<Meeting> Meetings => Set<Meeting>();
    public DbSet<ContractHistory> ContractHistories => Set<ContractHistory>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<PerformanceManager>(e =>
        {
            e.ToTable("PerformanceManagers");
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
            e.Property(x => x.Region).HasMaxLength(20).IsRequired();
            e.Property(x => x.Email).HasMaxLength(320);
            e.HasIndex(x => x.Name).IsUnique();
        });

        b.Entity<Contract>(e =>
        {
            e.ToTable("Contracts");
            e.HasKey(x => x.Id);
            e.Property(x => x.Customer).HasMaxLength(200).IsRequired();
            e.Property(x => x.PmName).HasMaxLength(200).IsRequired();
            e.Property(x => x.Region).HasMaxLength(20).IsRequired();
            e.Property(x => x.Value).HasPrecision(18, 2);
            e.Property(x => x.RiskValue).HasPrecision(18, 2);
            e.HasIndex(x => x.Customer).IsUnique();
            e.HasOne(x => x.PerformanceManager).WithMany(p => p.Contracts)
                .HasForeignKey(x => x.PerformanceManagerId).OnDelete(DeleteBehavior.SetNull);
        });

        b.Entity<Meeting>(e =>
        {
            e.ToTable("Meetings");
            e.HasKey(x => x.Id);
            e.Property(x => x.Customer).HasMaxLength(200);
            e.Property(x => x.PmName).HasMaxLength(200);
            e.HasOne(x => x.Contract).WithMany(c => c.Meetings)
                .HasForeignKey(x => x.ContractId).OnDelete(DeleteBehavior.Cascade);
            e.HasIndex(x => x.MeetingDate);
        });

        b.Entity<ContractHistory>(e =>
        {
            e.ToTable("ContractHistories");
            e.HasKey(x => x.Id);
            e.Property(x => x.Month).HasMaxLength(20);
            e.HasOne(x => x.Contract).WithMany(c => c.History)
                .HasForeignKey(x => x.ContractId).OnDelete(DeleteBehavior.Cascade);
        });
    }
}