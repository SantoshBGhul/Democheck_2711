﻿using A360.Domain.Entities;
using A360.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace A360.Infrastructure.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(A360DbContext db, CancellationToken ct = default)
    {
        await db.Database.MigrateAsync(ct);
        if (await db.Contracts.AnyAsync(ct)) return;

        var pms = new[]
        {
            new PerformanceManager { Name = "Marcel Tiemann", Region = "EMEA", Email = "marcel.tiemann@honeywell.com" },
            new PerformanceManager { Name = "Anju Chhabra",   Region = "EMEA", Email = "anju.chhabra@honeywell.com" },
            new PerformanceManager { Name = "Tanvi Bachal",   Region = "AMER", Email = "tanvi.bachal@honeywell.com" },
            new PerformanceManager { Name = "Sebastien",      Region = "EMEA", Email = "sebastien@honeywell.com" },
            new PerformanceManager { Name = "Sudha",          Region = "APJ",  Email = "sudha@honeywell.com" },
            new PerformanceManager { Name = "Ridhwaan",       Region = "EMEA", Email = "ridhwaan@honeywell.com" }
        };
        db.PerformanceManagers.AddRange(pms);

        var contracts = new[]
        {
            Make("TAP","Marcel Tiemann","EMEA",12.5m,.10m,Sentiment.Positive,"2026-09-22", HealthStatus.Green, HealthStatus.Green, HealthStatus.Green, HealthStatus.Orange),
            Make("TANAP","Marcel Tiemann","EMEA",8.1m,.60m,Sentiment.Neutral,"2026-09-22", HealthStatus.Orange, HealthStatus.Orange, HealthStatus.Orange, HealthStatus.Green),
            Make("QSGTL (Shell)","Marcel Tiemann","EMEA",15.2m,1.80m,Sentiment.Negative,"2026-09-22", HealthStatus.Green, HealthStatus.Red, HealthStatus.Green, HealthStatus.Orange),
            Make("KIPC","Marcel Tiemann","EMEA",9.8m,0m,Sentiment.Positive,"2026-09-22", HealthStatus.Green, HealthStatus.Green, HealthStatus.Green, HealthStatus.Green),
            Make("QAFCO","Marcel Tiemann","EMEA",7.6m,.30m,Sentiment.Positive,"2026-09-22", HealthStatus.Green, HealthStatus.Yellow, HealthStatus.Green, HealthStatus.Green),
            Make("ADNOC Sour Gas","Marcel Tiemann","EMEA",11.4m,0m,Sentiment.Positive,"2026-09-22", HealthStatus.Green, HealthStatus.Green, HealthStatus.Green, HealthStatus.Green),
            Make("Motor Oil Hellas","Marcel Tiemann","EMEA",6.1m,.70m,Sentiment.Neutral,"2026-09-22", HealthStatus.Green, HealthStatus.Orange, HealthStatus.Orange, HealthStatus.Orange),
            Make("Grupa Azoty","Marcel Tiemann","EMEA",5.9m,.10m,Sentiment.Positive,"2026-09-22", HealthStatus.Orange, HealthStatus.Yellow, HealthStatus.Green, HealthStatus.Green),
            Make("Rafineria Gdanska","Marcel Tiemann","EMEA",4.8m,.40m,Sentiment.Positive,"2026-09-22", HealthStatus.Green, HealthStatus.Yellow, HealthStatus.Orange, HealthStatus.Orange),
            Make("VAR Energy","Marcel Tiemann","EMEA",4.3m,1.20m,Sentiment.Negative,"2026-09-22", HealthStatus.Orange, HealthStatus.Red, HealthStatus.Orange, HealthStatus.Red),
            Make("Nordic Energy","Anju Chhabra","EMEA",10.7m,.10m,Sentiment.Positive,"2026-09-23", HealthStatus.Green, HealthStatus.Green, HealthStatus.Green, HealthStatus.Green),
            Make("Gulf Process Co.","Anju Chhabra","AMER",13.2m,.80m,Sentiment.Neutral,"2026-09-24", HealthStatus.Orange, HealthStatus.Orange, HealthStatus.Green, HealthStatus.Green),
            Make("Atlantic Chemicals","Tanvi Bachal","AMER",18.4m,.20m,Sentiment.Positive,"2026-09-25", HealthStatus.Green, HealthStatus.Green, HealthStatus.Green, HealthStatus.Orange),
            Make("Pacific Refining","Tanvi Bachal","APJ",7.9m,1.50m,Sentiment.Negative,"2026-09-26", HealthStatus.Orange, HealthStatus.Red, HealthStatus.Orange, HealthStatus.Red),
            Make("Euro Process","Sebastien","EMEA",6.8m,.20m,Sentiment.Positive,"2026-09-26", HealthStatus.Green, HealthStatus.Green, HealthStatus.Orange, HealthStatus.Green),
            Make("Blue River Gas","Sebastien","APJ",9.6m,.70m,Sentiment.Neutral,"2026-09-27", HealthStatus.Orange, HealthStatus.Orange, HealthStatus.Orange, HealthStatus.Orange),
            Make("Eastern Utilities","Sudha","APJ",14.3m,0m,Sentiment.Positive,"2026-09-27", HealthStatus.Green, HealthStatus.Green, HealthStatus.Green, HealthStatus.Green),
            Make("Central Process","Sudha","AMER",5.5m,1.10m,Sentiment.Negative,"2026-09-28", HealthStatus.Red, HealthStatus.Red, HealthStatus.Orange, HealthStatus.Orange)
        };
        db.Contracts.AddRange(contracts);
        await db.SaveChangesAsync(ct);

        // Seed history
        string[] months = ["Apr-26", "May-26", "Jun-26", "Jul-26", "Aug-26", "Sep-26"];
        var rnd = new Random(42);
        foreach (var c in contracts)
        {
            for (int i = 0; i < months.Length; i++)
            {
                db.ContractHistories.Add(new ContractHistory
                {
                    ContractId = c.Id,
                    Month = months[i],
                    Overall = i == months.Length - 1
                        ? c.OverallHealth()
                        : (HealthStatus)rnd.Next(1, 5)
                });
            }
        }

        // Seed meetings
        var c1 = contracts[0].Id; var c2 = contracts[1].Id; var c3 = contracts[2].Id; var c14 = contracts[13].Id;
        db.Meetings.AddRange(
            new Meeting { ContractId = c1, Customer = "TAP", PmName = "Marcel Tiemann", MeetingDate = new DateTime(2026, 9, 22), Sentiment = Sentiment.Positive, Action = "Confirm preventive maintenance schedule", Owner = "Ridhwaan", Due = new DateTime(2026, 10, 5), ActionStatus = ActionStatus.Open },
            new Meeting { ContractId = c3, Customer = "QSGTL (Shell)", PmName = "Marcel Tiemann", MeetingDate = new DateTime(2026, 9, 22), Sentiment = Sentiment.Negative, Action = "Review customer concerns and agree corrective actions", Owner = "Marcel Tiemann", Due = new DateTime(2026, 10, 2), ActionStatus = ActionStatus.InProgress },
            new Meeting { ContractId = c2, Customer = "TANAP", PmName = "Marcel Tiemann", MeetingDate = new DateTime(2026, 9, 22), Sentiment = Sentiment.Neutral, Action = "Prepare renewal readiness summary", Owner = "Anju Chhabra", Due = new DateTime(2026, 10, 10), ActionStatus = ActionStatus.Open },
            new Meeting { ContractId = c14, Customer = "Pacific Refining", PmName = "Tanvi Bachal", MeetingDate = new DateTime(2026, 9, 26), Sentiment = Sentiment.Negative, Action = "Create service recovery plan", Owner = "Tanvi Bachal", Due = new DateTime(2026, 10, 1), ActionStatus = ActionStatus.Open }
        );

        await db.SaveChangesAsync(ct);
    }

    private static Contract Make(string customer, string pm, string region, decimal value, decimal risk,
        Sentiment sentiment, string lastMeeting,
        HealthStatus outcome, HealthStatus riskStatus, HealthStatus delivery, HealthStatus financial) => new()
        {
            Customer = customer,
            PmName = pm,
            Region = region,
            Value = value,
            RiskValue = risk,
            Sentiment = sentiment,
            LastMeetingDate = DateTime.Parse(lastMeeting),
            OutcomeKpi = outcome,
            TopCustomerPriority = HealthStatus.Green,
            Next90DayRisk = riskStatus,
            PfmAction = outcome,
            ManagementSupport = outcome,
            MarginChecked = HealthStatus.Green,
            BillingForecastUpdated = HealthStatus.Green,
            PastDues = riskStatus,
            SespBgpCostsChecked = HealthStatus.Green,
            RenewalOnTime = HealthStatus.Green,
            Tracker2026 = HealthStatus.Green,
            Tracker2027 = HealthStatus.Green,
            IdpCompleted = HealthStatus.Green,
            HpdResultsUpdated = HealthStatus.Green,
            SiopCompleted = HealthStatus.Green,
            SfdcTasksClosed = HealthStatus.Green,
            ReportingStandard = HealthStatus.Green,
            CustomerMeetingsPlanned = HealthStatus.Green,
            DigitalPrimeDashboard = HealthStatus.Green,
            ContractSetupCorrect = HealthStatus.Green,
            A360OpsDashboard = HealthStatus.Green,
            NpsShared = HealthStatus.Green,
            MosCompleted = HealthStatus.Green,
            DeliveryHealth = delivery,
            FinancialHealth = financial,
            RiskHealth = riskStatus,
            RenewalHealth = HealthStatus.Green
        };
}
