﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace A360.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PerformanceManagers",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Region = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(320)", maxLength: 320, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PerformanceManagers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Contracts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Customer = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    PmName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    PerformanceManagerId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Region = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Value = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    RiskValue = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Sentiment = table.Column<byte>(type: "tinyint", nullable: false),
                    LastMeetingDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    OutcomeKpi = table.Column<byte>(type: "tinyint", nullable: false),
                    TopCustomerPriority = table.Column<byte>(type: "tinyint", nullable: false),
                    Next90DayRisk = table.Column<byte>(type: "tinyint", nullable: false),
                    PfmAction = table.Column<byte>(type: "tinyint", nullable: false),
                    ManagementSupport = table.Column<byte>(type: "tinyint", nullable: false),
                    MarginChecked = table.Column<byte>(type: "tinyint", nullable: false),
                    BillingForecastUpdated = table.Column<byte>(type: "tinyint", nullable: false),
                    PastDues = table.Column<byte>(type: "tinyint", nullable: false),
                    SespBgpCostsChecked = table.Column<byte>(type: "tinyint", nullable: false),
                    RenewalOnTime = table.Column<byte>(type: "tinyint", nullable: false),
                    Tracker2026 = table.Column<byte>(type: "tinyint", nullable: false),
                    Tracker2027 = table.Column<byte>(type: "tinyint", nullable: false),
                    IdpCompleted = table.Column<byte>(type: "tinyint", nullable: false),
                    HpdResultsUpdated = table.Column<byte>(type: "tinyint", nullable: false),
                    SiopCompleted = table.Column<byte>(type: "tinyint", nullable: false),
                    SfdcTasksClosed = table.Column<byte>(type: "tinyint", nullable: false),
                    ReportingStandard = table.Column<byte>(type: "tinyint", nullable: false),
                    CustomerMeetingsPlanned = table.Column<byte>(type: "tinyint", nullable: false),
                    DigitalPrimeDashboard = table.Column<byte>(type: "tinyint", nullable: false),
                    ContractSetupCorrect = table.Column<byte>(type: "tinyint", nullable: false),
                    A360OpsDashboard = table.Column<byte>(type: "tinyint", nullable: false),
                    NpsShared = table.Column<byte>(type: "tinyint", nullable: false),
                    MosCompleted = table.Column<byte>(type: "tinyint", nullable: false),
                    DeliveryHealth = table.Column<byte>(type: "tinyint", nullable: false),
                    FinancialHealth = table.Column<byte>(type: "tinyint", nullable: false),
                    RiskHealth = table.Column<byte>(type: "tinyint", nullable: false),
                    RenewalHealth = table.Column<byte>(type: "tinyint", nullable: false),
                    ValueDelivered = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Concern = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomerAction = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PfmActionText = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ManagementSupportText = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CommentCustomer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CommentFinancial = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CommentGrowth = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CommentPeople = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CommentInternal = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contracts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Contracts_PerformanceManagers_PerformanceManagerId",
                        column: x => x.PerformanceManagerId,
                        principalTable: "PerformanceManagers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "ContractHistories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ContractId = table.Column<int>(type: "int", nullable: false),
                    Month = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Overall = table.Column<byte>(type: "tinyint", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ContractHistories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ContractHistories_Contracts_ContractId",
                        column: x => x.ContractId,
                        principalTable: "Contracts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Meetings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ContractId = table.Column<int>(type: "int", nullable: false),
                    Customer = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    PmName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    MeetingDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MeetingType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Sentiment = table.Column<byte>(type: "tinyint", nullable: false),
                    ValueDelivered = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Concern = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomerAction = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PfmAction = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ManagementSupport = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Next90DayRisk = table.Column<byte>(type: "tinyint", nullable: false),
                    Action = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Owner = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Due = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ActionStatus = table.Column<byte>(type: "tinyint", nullable: false),
                    Source = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HealthSnapshotJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GroupCommentsJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Meetings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Meetings_Contracts_ContractId",
                        column: x => x.ContractId,
                        principalTable: "Contracts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ContractHistories_ContractId",
                table: "ContractHistories",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_Contracts_Customer",
                table: "Contracts",
                column: "Customer",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Contracts_PerformanceManagerId",
                table: "Contracts",
                column: "PerformanceManagerId");

            migrationBuilder.CreateIndex(
                name: "IX_Meetings_ContractId",
                table: "Meetings",
                column: "ContractId");

            migrationBuilder.CreateIndex(
                name: "IX_Meetings_MeetingDate",
                table: "Meetings",
                column: "MeetingDate");

            migrationBuilder.CreateIndex(
                name: "IX_PerformanceManagers_Name",
                table: "PerformanceManagers",
                column: "Name",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ContractHistories");

            migrationBuilder.DropTable(
                name: "Meetings");

            migrationBuilder.DropTable(
                name: "Contracts");

            migrationBuilder.DropTable(
                name: "PerformanceManagers");
        }
    }
}
