import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { StateService } from '../../core/services/state';
import { ApiService } from '../../core/services/api';
import { FlashService } from '../../core/services/flash.service';
import { Meeting } from '../../core/models/a360.models';

@Component({
  selector: 'app-actions',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe],
  templateUrl: './actions.html',
})
export class Actions {
  protected readonly state = inject(StateService);
  private readonly api = inject(ApiService);
  private readonly flash = inject(FlashService);

  // Pagination State
  protected readonly pageSize = 10;
  protected readonly currentPage = signal(1);

  // Only get meetings that have an action
  protected readonly allActions = computed<readonly Meeting[]>(() =>
    this.state.meetings().filter(m => m.action)
  );

  protected readonly totalPages = computed(() =>
    Math.max(1, Math.ceil(this.allActions().length / this.pageSize))
  );

  protected readonly paginatedActions = computed<readonly Meeting[]>(() => {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.allActions().slice(start, start + this.pageSize);
  });

  protected nextPage(): void {
    if (this.currentPage() < this.totalPages()) this.currentPage.update(p => p + 1);
  }
  protected prevPage(): void {
    if (this.currentPage() > 1) this.currentPage.update(p => p - 1);
  }

  protected async updateStatus(id: number, status: string): Promise<void> {
    try {
      await firstValueFrom(this.api.updateActionStatus(id, status));
      this.flash.show('Action status updated');
      this.state.reload();
    } catch { /* interceptor handles */ }
  }

  protected async remove(id: number): Promise<void> {
    if (!confirm('Remove this action?')) return;
    try {
      await firstValueFrom(this.api.deleteAction(id));
      this.flash.show('Action removed');
      this.state.reload();
    } catch { /* handled */ }
  }
  
  protected readonly Math = Math;
}