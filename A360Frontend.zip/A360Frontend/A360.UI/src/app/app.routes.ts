import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'Meetings', pathMatch: 'full' },
  {
    path: 'meetings',
    loadComponent: () => import('./pages/meetings/meetings').then(m => m.Meetings),
    title: 'A360 · Meetings',
  },
 
  { path: '**', redirectTo: 'dashboard' },
];