namespace A360.ContractHealth.Web.Models;

public class ActionItem
{
    public long Id { get; set; }
    public long? MeetingId { get; set; }
    public int ContractId { get; set; }
    public string Action { get; set; } = string.Empty;
    public string? Owner { get; set; }
    public DateTime? DueDate { get; set; }
    public string Status { get; set; } = "Open";
    public string Source { get; set; } = "Meeting";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
    public Contract Contract { get; set; } = null!;
    public Meeting? Meeting { get; set; }
}
