namespace A360.ContractHealth.Web.Models;

public class ContractHealth
{
    public long Id { get; set; }
    public int ContractId { get; set; }
    public DateTime AssessmentMonth { get; set; }
    public long? MeetingId { get; set; }
    public string? OutcomeKpi { get; set; }
    public string? TopCustomerPriority { get; set; }
    public string? Next90DayRisk { get; set; }
    public string? PFMAction { get; set; }
    public string? ManagementSupport { get; set; }
    public string? MarginChecked { get; set; }
    public string? BillingForecastUpdated { get; set; }
    public string? PastDues { get; set; }
    public string? SespBgpCostsChecked { get; set; }
    public string? RenewalOnTime { get; set; }
    public string? Tracker2026 { get; set; }
    public string? Tracker2027 { get; set; }
    public string? IdpCompleted { get; set; }
    public string? HpdResultsUpdated { get; set; }
    public string? SiopCompleted { get; set; }
    public string? SfdcTasksClosed { get; set; }
    public string? ReportingStandard { get; set; }
    public string? CustomerMeetingsPlanned { get; set; }
    public string? DigitalPrimeDashboard { get; set; }
    public string? ContractSetupCorrect { get; set; }
    public string? A360OpsDashboard { get; set; }
    public string? NpsShared { get; set; }
    public string? MosCompleted { get; set; }
    public string? Delivery { get; set; }
    public string? Financial { get; set; }
    public string? Risk { get; set; }
    public string? Renewal { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
    public Contract Contract { get; set; } = null!;
    public Meeting? Meeting { get; set; }
}
