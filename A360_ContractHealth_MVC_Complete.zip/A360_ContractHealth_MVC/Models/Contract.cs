namespace A360.ContractHealth.Web.Models;

public class Contract
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
    public int PerformanceManagerId { get; set; }
    public string Region { get; set; } = "EMEA";
    public decimal ContractValueM { get; set; }
    public string? CustomerSentiment { get; set; }
    public decimal? CustomerRating { get; set; }
    public DateTime? LastMeetingDate { get; set; }
    public decimal ValueAtRiskM { get; set; }
    public string? ValueDelivered { get; set; }
    public string? Concern { get; set; }
    public string? CustomerAction { get; set; }
    public string? PFMActionText { get; set; }
    public string? ManagementSupportText { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
    public Customer Customer { get; set; } = null!;
    public PerformanceManager PerformanceManager { get; set; } = null!;
    public ICollection<ContractHealth> HealthAssessments { get; set; } = new List<ContractHealth>();
    public ICollection<Meeting> Meetings { get; set; } = new List<Meeting>();
    public ICollection<ActionItem> ActionItems { get; set; } = new List<ActionItem>();
}
