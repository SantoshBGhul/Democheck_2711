namespace A360.ContractHealth.Web.Models;

public class KpiDefinition
{
    public int Id { get; set; }
    public string GroupKey { get; set; } = string.Empty;
    public string Key { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public int DisplayOrder { get; set; }
    public bool IsActive { get; set; } = true;
}
