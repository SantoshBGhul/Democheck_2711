namespace A360.ContractHealth.Web.Models;

public class Customer
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Region { get; set; } = "EMEA";
    public bool IsActive { get; set; } = true;
    public ICollection<Contract> Contracts { get; set; } = new List<Contract>();
}
