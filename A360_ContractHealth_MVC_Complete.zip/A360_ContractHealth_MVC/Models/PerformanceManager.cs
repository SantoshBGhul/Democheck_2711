namespace A360.ContractHealth.Web.Models;

public class PerformanceManager
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Email { get; set; }
    public bool IsActive { get; set; } = true;
    public ICollection<Contract> Contracts { get; set; } = new List<Contract>();
    public ICollection<Meeting> Meetings { get; set; } = new List<Meeting>();
}
