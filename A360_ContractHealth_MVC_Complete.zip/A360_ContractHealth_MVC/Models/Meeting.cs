namespace A360.ContractHealth.Web.Models;

public class Meeting
{
    public long Id { get; set; }
    public int ContractId { get; set; }
    public int PerformanceManagerId { get; set; }
    public DateTime MeetingDate { get; set; }
    public string MeetingType { get; set; } = "Monthly 1:1";
    public decimal CustomerRating { get; set; }
    public string? Sentiment { get; set; }
    public string? Summary { get; set; }
    public string? ValueDelivered { get; set; }
    public string? Concern { get; set; }
    public string? CustomerAction { get; set; }
    public string? PFMAction { get; set; }
    public string? ManagementSupport { get; set; }
    public string? Next90DayRisk { get; set; }
    public string? Owner { get; set; }
    public DateTime? DueDate { get; set; }
    public string? ActionText { get; set; }
    public string ActionStatus { get; set; } = "Open";
    public string Source { get; set; } = "Meeting workspace";
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
    public Contract Contract { get; set; } = null!;
    public PerformanceManager PerformanceManager { get; set; } = null!;
    public ICollection<ContractHealth> HealthAssessments { get; set; } = new List<ContractHealth>();
    public ICollection<ActionItem> ActionItems { get; set; } = new List<ActionItem>();
}
