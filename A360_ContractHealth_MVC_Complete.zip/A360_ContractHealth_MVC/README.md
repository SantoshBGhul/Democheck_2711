# A360 Contract Health – Complete ASP.NET Core MVC + SQL Server Solution

This solution converts the supplied **A360 Contract Health Dashboard Complete v5** HTML UI into a runnable ASP.NET Core MVC application with SQL Server persistence. Angular is not used.

## Stack
- .NET 8 / ASP.NET Core MVC
- Razor View + the supplied HTML/CSS/JavaScript UI
- Entity Framework Core 8 + SQL Server
- REST API under `/api/a360` used by the same UI
- Demo data automatically seeded on first run

## Fastest run
1. Install Visual Studio 2022 (17.8+) with **ASP.NET and web development** and **.NET 8 SDK**.
2. Make sure LocalDB is installed (normally included with Visual Studio).
3. Open `A360.ContractHealth.sln`.
4. Build the solution.
5. Run the project.
6. The app creates database `A360ContractHealth` in `(localdb)\MSSQLLocalDB`, creates all tables, and inserts demo data automatically.
7. Open the URL shown by Visual Studio.

## SQL Server / SSMS option
The file `Database/A360_ContractHealth.sql` contains the complete schema + demo data. Run it in SSMS if you want to create the database manually. Then change the connection string in `appsettings.json` to your SQL Server instance, for example:

`Server=localhost;Database=A360ContractHealth;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True`

For SQL authentication use `User Id=...;Password=...` as appropriate for your environment. Do not commit production credentials.

## Database tables
1. `Customers` – customer master.
2. `PerformanceManagers` – PM master.
3. `Contracts` – contract-level master and customer voice values.
4. `ContractHealth` – monthly KPI/status snapshot and historical health.
5. `Meetings` – monthly 1:1 / escalation meeting records.
6. `ActionItems` – actions carried from meetings.
7. `KpiDefinitions` – KPI labels/groups used by the dashboard.

## Main API methods
- `GET /api/a360/health`
- `GET /api/a360/bootstrap`
- `POST /api/a360/contract-health`
- `POST /api/a360/meetings`
- `POST /api/a360/contracts`
- `POST /api/a360/actions`
- `POST /api/a360/actions/remove`
- `POST /api/a360/reset-demo`

Swagger is available in Development at `/swagger`.

## How persistence works
The browser loads the current contracts/meetings from SQL Server through `/api/a360/bootstrap`. KPI dropdown changes are posted to SQL Server. Saving a meeting writes the meeting, monthly health snapshot, and optional action item. Adding a contract writes to `Contracts`. The browser localStorage is retained only as a fallback cache so the UI remains usable if the API is temporarily unavailable.

## Important business rule note
The UI supports **Blank, Green, Yellow, Orange and Red** because those states are present in the supplied prototype. The overall-health display uses the existing prototype's worst-status approach. Exact production thresholds/weights should be confirmed by the business before production use.

## Existing compile-error issue
The previous `CS0266` issue came from returning `IQueryable<T>` where EF Core's `Include()` chain returns an `IIncludableQueryable<T,TProperty>`. This solution avoids that pattern by materializing the query with `ToListAsync()` before mapping to DTOs, so the service methods return concrete DTOs/lists rather than EF include-chain types.

## Production next steps
- Add authentication/authorization (Entra ID/Windows Authentication or your standard Honeywell mechanism).
- Add audit columns/user identity to KPI updates.
- Add concurrency control for monthly updates.
- Replace demo performance values with Salesforce/Ops/Renewal source integrations where required.
- Confirm exact health/status definitions and scoring with the business.
