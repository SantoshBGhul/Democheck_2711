/* ==========================================================
   A360 Contract Health – single-file functional prototype
   Data model is intentionally simple so it can be mapped to
   a .NET 7/8 Web API + SQL Server without rewriting the UI.
   ========================================================== */

const MONTHS = { "2026-09":"Sep-26","2026-10":"Oct-26","2026-11":"Nov-26","2026-12":"Dec-26" };

const KPI_GROUPS = {
  customer: [
    {key:"outcomeKpi", label:"Outcome KPI achievement"},
    {key:"topCustomerPriority", label:"Top customer priority"},
    {key:"next90DayRisk", label:"Next 90-day risk"},
    {key:"pfmAction", label:"PFM action"},
    {key:"managementSupport", label:"Management support required"}
  ],
  financial: [
    {key:"marginChecked", label:"Margin checked in profitability file"},
    {key:"billingForecastUpdated", label:"Billing Forecast updated"},
    {key:"pastDues", label:"Past Due's"},
    {key:"sespBgpCostsChecked", label:"SESP & BGP costs checked"}
  ],
  growth: [
    {key:"renewalOnTime", label:"Renewal OnTime"},
    {key:"tracker2026", label:"Tracker 2026 updated"},
    {key:"tracker2027", label:"Tracker 2027 updated"}
  ],
  people: [
    {key:"idpCompleted", label:"IDP completed"},
    {key:"hpdResultsUpdated", label:"HPD results updated"},
    {key:"siopCompleted", label:"SIOP completed"}
  ],
  internal: [
    {key:"sfdcTasksClosed", label:"SFDC Tasks Closed"},
    {key:"reportingStandard", label:"Reporting according to our standard"},
    {key:"customerMeetingsPlanned", label:"Customer meetings planned"},
    {key:"digitalPrimeDashboard", label:"Digital Prime Dashboard in use?"},
    {key:"contractSetupCorrect", label:"Contract setup in SFDC correct?"},
    {key:"a360OpsDashboard", label:"A360 OPS Dashboard status"},
    {key:"npsShared", label:"NPS Shared"},
    {key:"mosCompleted", label:"MOS completed"}
  ]
};

const ALL_KPIS = [...KPI_GROUPS.customer,...KPI_GROUPS.financial,...KPI_GROUPS.growth,...KPI_GROUPS.people,...KPI_GROUPS.internal];

const SNAPSHOT_ACTIONS = [
 "Make sure WO are created under the correct entitlement",
 "close overdue SFDC tasks",
 "Business development activities are not really progressing",
 "P1 spares from Rossing and CBG need to be returned",
 "CBG - third party service is created for TAX issues. Need to be removed.",
 "NPS survey CBG",
 "Invite PSC engineer to your monthly customer meetings",
 "Ridhwaan will invite the PSC engineers to the monthly meetings",
 "Promote digital prime dashboard",
 "CBG: Digital Prime Home",
 "SAPPEF: Digital Prime Home",
 "Offboard Rossing from A360 and PSC",
 "When service delivery completed we will offboard",
 "Write your MOS for the business Development activities",
 "Ridhwaan to make sure remote connection is always available for PSC to get the full benefits from PSC for the customer.",
 "Ridhwaan to reach out to Karthick and Rahul to speak about this.",
 "Start contract renewal activities for the renewal 1st November 2026",
 "CBG: who is the HCI Success Manager. Please ask R.layaprakash@honeywell.com",
 "Requested service for CBG not booked in SFDC. Still 0 hours used. Please check."
];

const DEMO_CONTRACTS = [
 {id:1,customer:"TAP",pm:"Marcel Tiemann",region:"EMEA",value:12.5,sentiment:"Positive",rating:8.5,last:"2026-09-22",riskValue:.10,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Orange",financial:"Green",risk:"Green",renewal:"Green"}},
 {id:2,customer:"TANAP",pm:"Marcel Tiemann",region:"EMEA",value:8.1,sentiment:"Neutral",rating:6.8,last:"2026-09-22",riskValue:.60,health:{outcomeKpi:"Orange",next90DayRisk:"Orange",pfmAction:"Yellow",managementSupport:"Yellow",delivery:"Green",financial:"Orange",risk:"Orange",renewal:"Green"}},
 {id:3,customer:"QSGTL (Shell)",pm:"Marcel Tiemann",region:"EMEA",value:15.2,sentiment:"Negative",rating:4.8,last:"2026-09-22",riskValue:1.80,health:{outcomeKpi:"Green",next90DayRisk:"Red",pfmAction:"Orange",managementSupport:"Red",delivery:"Green",financial:"Green",risk:"Red",renewal:"Orange"}},
 {id:4,customer:"KIPC",pm:"Marcel Tiemann",region:"EMEA",value:9.8,sentiment:"Positive",rating:8.1,last:"2026-09-22",riskValue:0,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Green",risk:"Green",renewal:"Green"}},
 {id:5,customer:"QAFCO",pm:"Marcel Tiemann",region:"EMEA",value:7.6,sentiment:"Positive",rating:8.8,last:"2026-09-22",riskValue:.30,health:{outcomeKpi:"Green",next90DayRisk:"Yellow",pfmAction:"Yellow",managementSupport:"Green",delivery:"Orange",financial:"Green",risk:"Orange",renewal:"Green"}},
 {id:6,customer:"ADNOC Sour Gas",pm:"Marcel Tiemann",region:"EMEA",value:11.4,sentiment:"Positive",rating:9.0,last:"2026-09-22",riskValue:0,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Green",risk:"Green",renewal:"Green"}},
 {id:7,customer:"Motor Oil Hellas",pm:"Marcel Tiemann",region:"EMEA",value:6.1,sentiment:"Neutral",rating:7.0,last:"2026-09-22",riskValue:.70,health:{outcomeKpi:"Green",next90DayRisk:"Orange",pfmAction:"Orange",managementSupport:"Yellow",delivery:"Orange",financial:"Orange",risk:"Orange",renewal:"Orange"}},
 {id:8,customer:"Grupa Azoty",pm:"Marcel Tiemann",region:"EMEA",value:5.9,sentiment:"Positive",rating:8.0,last:"2026-09-22",riskValue:.10,health:{outcomeKpi:"Orange",next90DayRisk:"Yellow",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Green",risk:"Green",renewal:"Green"}},
 {id:9,customer:"Rafineria Gdanska",pm:"Marcel Tiemann",region:"EMEA",value:4.8,sentiment:"Positive",rating:8.4,last:"2026-09-22",riskValue:.40,health:{outcomeKpi:"Green",next90DayRisk:"Yellow",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Orange",risk:"Green",renewal:"Orange"}},
 {id:10,customer:"VAR Energy",pm:"Marcel Tiemann",region:"EMEA",value:4.3,sentiment:"Negative",rating:5.2,last:"2026-09-22",riskValue:1.20,health:{outcomeKpi:"Orange",next90DayRisk:"Red",pfmAction:"Orange",managementSupport:"Red",delivery:"Orange",financial:"Orange",risk:"Red",renewal:"Red"}},
 {id:11,customer:"Nordic Energy",pm:"Anju Chhabra",region:"EMEA",value:10.7,sentiment:"Positive",rating:8.7,last:"2026-09-23",riskValue:.10,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Green",risk:"Green",renewal:"Green"}},
 {id:12,customer:"Gulf Process Co.",pm:"Anju Chhabra",region:"AMER",value:13.2,sentiment:"Neutral",rating:7.1,last:"2026-09-24",riskValue:.80,health:{outcomeKpi:"Orange",next90DayRisk:"Orange",pfmAction:"Yellow",managementSupport:"Green",delivery:"Orange",financial:"Green",risk:"Orange",renewal:"Green"}},
 {id:13,customer:"Atlantic Chemicals",pm:"Tanvi Bachal",region:"AMER",value:18.4,sentiment:"Positive",rating:8.9,last:"2026-09-25",riskValue:.20,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Green",risk:"Green",renewal:"Orange"}},
 {id:14,customer:"Pacific Refining",pm:"Tanvi Bachal",region:"APJ",value:7.9,sentiment:"Negative",rating:5.9,last:"2026-09-26",riskValue:1.50,health:{outcomeKpi:"Orange",next90DayRisk:"Red",pfmAction:"Red",managementSupport:"Orange",delivery:"Red",financial:"Orange",risk:"Red",renewal:"Red"}},
 {id:15,customer:"Euro Process",pm:"Sebastien",region:"EMEA",value:6.8,sentiment:"Positive",rating:8.2,last:"2026-09-26",riskValue:.20,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Orange",risk:"Green",renewal:"Green"}},
 {id:16,customer:"Blue River Gas",pm:"Sebastien",region:"APJ",value:9.6,sentiment:"Neutral",rating:6.9,last:"2026-09-27",riskValue:.70,health:{outcomeKpi:"Orange",next90DayRisk:"Orange",pfmAction:"Yellow",managementSupport:"Yellow",delivery:"Green",financial:"Orange",risk:"Orange",renewal:"Orange"}},
 {id:17,customer:"Eastern Utilities",pm:"Sudha",region:"APJ",value:14.3,sentiment:"Positive",rating:9.1,last:"2026-09-27",riskValue:0,health:{outcomeKpi:"Green",next90DayRisk:"Green",pfmAction:"Green",managementSupport:"Green",delivery:"Green",financial:"Green",risk:"Green",renewal:"Green"}},
 {id:18,customer:"Central Process",pm:"Sudha",region:"AMER",value:5.5,sentiment:"Negative",rating:5.5,last:"2026-09-28",riskValue:1.10,health:{outcomeKpi:"Red",next90DayRisk:"Red",pfmAction:"Orange",managementSupport:"Orange",delivery:"Orange",financial:"Orange",risk:"Red",renewal:"Orange"}}
];


function seedPerformanceMetrics(c){
  const i = Number(c.id)||1;
  const states = Object.values(c.health||{}).filter(Boolean);
  const score = Math.max(35, Math.min(96, Math.round(scoreHealth([c]))));
  const red = states.filter(v=>v==='Red').length;
  const orange = states.filter(v=>v==='Orange').length;
  const yellow = states.filter(v=>v==='Yellow').length;
  c.performance = c.performance || {};
  c.performance.enableServices = c.performance.enableServices || {
    avgScore: Math.max(45, Math.min(98, score+4)),
    coverage: Math.max(40, Math.min(99, 82 + ((i*3)%14) - orange*3 - red*5)),
    serviceHealth: Math.max(38, Math.min(98, 76 + ((i*5)%12) - orange*4 - red*8)),
    udcVersion:'v2.8.3', esUdcVersion:'v2.8.3'
  };
  c.performance.contract = c.performance.contract || {
    avgKpi: score,
    missingMonth: (i%7===0)?'1 month':((i%5===0)?'—':'0'),
    openProposalRequests: (i*2 + orange)%3,
    overdueDays: red ? red*45 + i*3 : (orange ? 10 + i : i%8),
    csat: c.sentiment==='Positive' ? Math.min(98, 86 + (i%9)) : c.sentiment==='Neutral' ? 72 + (i%7) : 48 + (i%9),
    nps: c.sentiment==='Positive' ? 48 + (i%18) : c.sentiment==='Neutral' ? 8 + (i%12) : -24 + (i%10)
  };
  c.performance.financial = c.performance.financial || {
    assurance: Math.round((4-orange*12-red*25)*((i%5)+1)/2),
    requestedServices: (i%4===0)?'—':(8+i),
    preventiveMaintenance: Math.max(0, 95 + (i*9)%55 - red*18),
    cyber: Math.round(-40 - red*55 - (i%6)*18),
    training: (i%3===0)?'—':(12+(i%10)),
    bgpPlus: (i%5===0)?0:(i%7)*3,
    pipelineOpportunity: Math.round((c.value||5) * (0.3 + (i%4)*0.1)*10)/10,
    bookedMargin: Math.max(18, Math.min(72, 56 - orange*5 - red*9 + (i%7))),
    grossMargin: Math.max(22, Math.min(78, 60 - orange*4 - red*8 + (i%8)))
  };
  c.performance.groups = c.performance.groups || {};
  c.performance.groups.customer = c.performance.groups.customer || {
    sentimentScore: c.sentiment==='Positive'?85:c.sentiment==='Neutral'?68:42,
    outcomeScore: score,
    priorityScore: Math.max(35, 90-orange*7-red*12-yellow*3),
    concernLevel: red?4:orange?3:yellow?2:1
  };
  c.performance.groups.financial = c.performance.groups.financial || {
    marginScore: c.performance.financial.grossMargin,
    billingForecast: Math.max(45, Math.min(98, score+8-orange*5-red*12)),
    pastDue: red?4:orange?2:(i%3),
    costCheck: Math.max(40, 94-orange*6-red*10)
  };
  c.performance.groups.growth = c.performance.groups.growth || {
    renewalScore: c.health?.renewal==='Red'?30:c.health?.renewal==='Orange'?58:c.health?.renewal==='Yellow'?76:92,
    tracker2026: i%6===0?'Attention':'Updated',
    tracker2027: i%5===0?'Attention':'Updated',
    pipeline: c.performance.financial.pipelineOpportunity
  };
  c.performance.groups.people = c.performance.groups.people || {
    idp: Math.max(50, 95 - red*8 - orange*4 - (i%5)*2),
    hpd: Math.max(50, 92 - red*8 - orange*4),
    siop: Math.max(48, 88 - red*7 - yellow*3)
  };
  c.performance.groups.internal = c.performance.groups.internal || {
    sfdcTasks: Math.max(35, 96 - red*12 - orange*6),
    reporting: Math.max(40, 94 - yellow*3 - orange*5 - red*10),
    meetingsPlanned: Math.max(45, 90 - red*10 - orange*4),
    digitalPrime: i%4===0?'Attention':'In Use',
    sfdcSetup: c.health?.contractSetupCorrect || (i%6===0?'Orange':'Green'),
    opsDashboard: i%5===0?'Orange':'Green',
    npsShared: i%3===0?'Pending':'Shared',
    mos: i%4===0?'Pending':'Completed'
  };
  return c;
}

DEMO_CONTRACTS.forEach(seedPerformanceMetrics);

const HISTORY_MONTHS = ["Apr-26","May-26","Jun-26","Jul-26","Aug-26","Sep-26"];
function seedHistoricalHealth(c){
  if(Array.isArray(c.history) && c.history.length===HISTORY_MONTHS.length) return;
  const current = overallHealth(c);
  const ranks = ["Green","Yellow","Orange","Red"];
  const base = Math.max(0, statusRank(current)-1);
  c.history = HISTORY_MONTHS.map((month,idx)=>{
    const wave = ((Number(c.id||1)*3 + idx*2) % 5) - 2;
    let r = Math.max(0, Math.min(3, base + wave));
    if(idx === HISTORY_MONTHS.length-1 && current && current !== "Blank") r = ranks.indexOf(current);
    const overall = ranks[r] || "Green";
    const ratingBase = Number(c.rating||7);
    const rating = Math.max(4.1, Math.min(9.7, ratingBase + ((idx%3)-1)*0.45 - (r===3?0.6:r===2?0.25:0)));
    return {month, overall, rating:Number(rating.toFixed(1))};
  });
}
function ensureContractEnhancements(c){
  seedHistoricalHealth(c);
  if(!c.performance) seedPerformanceMetrics(c);
  c.history.forEach((h,i)=>{
    if(!h.month) h.month=HISTORY_MONTHS[i]||"";
  });
  return c;
}


const DEMO_MEETINGS = [
 {id:101,customer:"TAP",date:"2026-09-22",pm:"Marcel Tiemann",rating:8.5,sentiment:"Positive",type:"Monthly 1:1",summary:"Customer is satisfied with delivery overall. Preventive maintenance follow-up requested.",owner:"Ridhwaan",due:"2026-10-05",action:"Confirm preventive maintenance schedule",actionStatus:"Open",source:"Prototype demo"},
 {id:102,customer:"QSGTL (Shell)",date:"2026-09-22",pm:"Marcel Tiemann",rating:4.8,sentiment:"Negative",type:"Monthly 1:1",summary:"Customer expressed dissatisfaction despite several operational indicators being green. Validate customer sentiment and service gaps.",owner:"Marcel Tiemann",due:"2026-10-02",action:"Review customer concerns and agree corrective actions",actionStatus:"In Progress",source:"Meeting scenario"},
 {id:103,customer:"TANAP",date:"2026-09-22",pm:"Marcel Tiemann",rating:6.8,sentiment:"Neutral",type:"Monthly 1:1",summary:"Discussed overdue actions and renewal readiness.",owner:"Anju Chhabra",due:"2026-10-10",action:"Prepare renewal readiness summary",actionStatus:"Open",source:"Prototype demo"},
 {id:104,customer:"Pacific Refining",date:"2026-09-26",pm:"Tanvi Bachal",rating:5.9,sentiment:"Negative",type:"Escalation Review",summary:"Delivery and risk require management attention. Customer requested clearer recovery milestones.",owner:"Tanvi Bachal",due:"2026-10-01",action:"Create service recovery plan",actionStatus:"Open",source:"Prototype demo"},
 {id:105,customer:"CBG",date:"2026-09-22",pm:"Ridhwaan",rating:6.5,sentiment:"Neutral",type:"Monthly 1:1",summary:"Snapshot action list loaded as prototype follow-up backlog.",owner:"Ridhwaan",due:"2026-10-05",action:"Review the snapshot action backlog in the meeting workspace",actionStatus:"Open",source:"Excel snapshot"}
];

const STORAGE = {
  contracts:"a360_complete_contracts_v5",
  meetings:"a360_complete_meetings_v5",
  settings:"a360_complete_settings_v5"
};

let contracts = load(STORAGE.contracts, null);
let meetings = load(STORAGE.meetings, null);
let settings = load(STORAGE.settings, {
  apiBase:"/api/a360", apiHealth:"/contract-health", apiMeeting:"/meetings", apiAction:"/actions", apiToken:""
});
if(!Array.isArray(contracts) || contracts.length<1) contracts = deepClone(DEMO_CONTRACTS);
if(!Array.isArray(meetings)) meetings = deepClone(DEMO_MEETINGS);
contracts=contracts.map(c=>{c.health=c.health||{};return c;});
contracts.forEach(ensureContractEnhancements);

function load(key, fallback){ try{const raw=localStorage.getItem(key); return raw?JSON.parse(raw):fallback}catch(e){return fallback} }
function deepClone(x){ return JSON.parse(JSON.stringify(x)); }
function persist(){ try{ localStorage.setItem(STORAGE.contracts,JSON.stringify(contracts)); localStorage.setItem(STORAGE.meetings,JSON.stringify(meetings)); localStorage.setItem(STORAGE.settings,JSON.stringify(settings)); }catch(e){ /* file:// or locked storage: keep in-memory state */ } }

function flash(msg){ const el=document.getElementById("flash"); el.textContent=msg; el.classList.add("show"); clearTimeout(window.__flash); window.__flash=setTimeout(()=>el.classList.remove("show"),2200); }
function esc(v){ return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m])); }

function statusRank(v){ return ({Red:4,Orange:3,Yellow:2,Green:1,"":0})[v]||0; }
function overallHealth(c){
  const vals = ALL_KPIS.map(k=>c.health?.[k.key]).filter(Boolean);
  /* Keep the five core health dimensions from the older prototype as well. */
  const extra = ["delivery","financial","risk","renewal"].map(k=>c.health?.[k]).filter(Boolean);
  vals.push(...extra);
  if(!vals.length) return "Blank";
  const worst = Math.max(...vals.map(statusRank));
  return ({4:"Red",3:"Orange",2:"Yellow",1:"Green"})[worst]||"Blank";
}
function scoreHealth(data){
  if(!data.length) return 0;
  let score=0, total=0;
  data.forEach(c=>{
    const vals=ALL_KPIS.map(k=>c.health?.[k.key]).concat(["delivery","financial","risk","renewal"].map(k=>c.health?.[k])).filter(Boolean);
    if(!vals.length) return;
    const avg=vals.reduce((s,v)=>s+({Green:100,Yellow:80,Orange:60,Red:20}[v]||0),0)/vals.length;
    score+=avg; total++;
  });
  return total?Math.round(score/total):0;
}
function statusClass(v){ return "status-" + (v?String(v).toLowerCase():"blank"); }
function statusSelect(value, contractId, key){
  const v=value||"";
  return `<select class="status-select ${statusClass(v)}" onchange="updateKpi(${contractId},'${key}',this.value)">
    <option value="" ${v===""?"selected":""}>Blank</option>
    <option ${v==="Green"?"selected":""}>Green</option>
    <option ${v==="Yellow"?"selected":""}>Yellow</option>
    <option ${v==="Orange"?"selected":""}>Orange</option>
    <option ${v==="Red"?"selected":""}>Red</option>
  </select>`;
}
function sentimentPill(s){
  if(!s) return '<span class="pill">Blank</span>';
  const cl=s==="Positive"?"pos":s==="Negative"?"neg":"neutral";
  return `<span class="pill ${cl}">${esc(s)}</span>`;
}

function currentFilters(){
  return {
    pm:document.getElementById("fPM").value,
    customer:document.getElementById("fCustomer").value,
    region:document.getElementById("fRegion").value,
    month:document.getElementById("fMonth").value,
    health:document.getElementById("fHealth").value,
    sentiment:document.getElementById("fSentiment").value
  };
}
function filteredContracts(){
  const f=currentFilters();
  return contracts.filter(c=>{
    const okPm=f.pm==="All"||c.pm===f.pm;
    const okCustomer=f.customer==="All"||c.customer===f.customer;
    const okRegion=f.region==="All"||c.region===f.region;
    const okMonth=f.month==="All"||c.last.startsWith(f.month);
    const h=overallHealth(c);
    const okHealth=f.health==="All"||h===f.health;
    const okSent=f.sentiment==="All"||c.sentiment===f.sentiment;
    return okPm&&okCustomer&&okRegion&&okMonth&&okHealth&&okSent;
  });
}
function populateFilters(){
  const p=document.getElementById("fPM"), n=document.getElementById("fCustomer");
  const oldP=p.value||"All", oldN=n.value||"All";
  const pms=[...new Set(contracts.map(c=>c.pm).filter(Boolean))].sort();
  const names=[...new Set(contracts.map(c=>c.customer).filter(Boolean))].sort();
  p.innerHTML='<option>All</option>'+pms.map(x=>`<option>${esc(x)}</option>`).join("");
  n.innerHTML='<option>All</option>'+names.map(x=>`<option>${esc(x)}</option>`).join("");
  p.value=pms.includes(oldP)?oldP:"All";
  n.value=names.includes(oldN)?oldN:"All";
}
function kpiGroupsCells(c, forTable=false){
  return ALL_KPIS.map(k=>`<td>${statusSelect(c.health?.[k.key]||"",c.id,k.key)}</td>`).join("");
}

function historyCell(v){
  const cls = v ? "hist-"+String(v).toLowerCase() : "hist-blank";
  return `<span class="hist-cell ${cls}" title="${esc(v||"Not assessed")}">${v ? v[0] : "—"}</span>`;
}
function renderHistoryStrip(c){
  ensureContractEnhancements(c);
  return `<div class="history-strip">${c.history.map(h=>historyCell(h.overall)).join("")}</div>`;
}
function renderHomeHistoryOverview(data){
  const arr=(data||[]).slice(0,10);
  const holder=document.getElementById("homeHistoryOverview");
  if(!holder)return;
  holder.innerHTML = `<div class="history-overview">
    <div class="history-row head"><div>Customer</div><div>Performance Manager</div><div>Current</div><div>Apr → Sep 2026</div></div>
    ${arr.map(c=>`<div class="history-row">
      <div><b class="name">${esc(c.customer)}</b><div class="small">${esc(c.region)}</div></div>
      <div class="small">${esc(c.pm)}</div>
      <div class="history-current">${esc(overallHealth(c))}</div>
      <div class="history-cells">${c.history.map(h=>historyCell(h.overall)).join("")}<span class="history-rating">${Number(c.rating||0).toFixed(1)}/10</span></div>
    </div>`).join("")}
  </div>`;
}

function dashboardRow(c){
  return `<tr>
    <td><span class="name">${esc(c.customer)}</span></td>
    <td>${esc(c.pm)}</td><td>${esc(c.region)}</td><td>$${Number(c.value||0).toFixed(1)}M</td>
    <td>${sentimentPill(c.sentiment)}</td><td><b>${Number(c.rating||0).toFixed(1)}</b></td>
    <td>${statusSelect(c.health?.outcomeKpi||"",c.id,"outcomeKpi")}</td>
    <td>${statusSelect(c.health?.delivery||"",c.id,"delivery")}</td>
    <td>${statusSelect(c.health?.financial||"",c.id,"financial")}</td>
    <td>${statusSelect(c.health?.risk||"",c.id,"risk")}</td>
    <td>${statusSelect(c.health?.renewal||"",c.id,"renewal")}</td>
    <td><span class="health-chip"><span class="dot ${overallHealth(c)==="Green"?"g":overallHealth(c)==="Yellow"?"y":overallHealth(c)==="Orange"?"o":overallHealth(c)==="Red"?"r":"b"}"></span>${overallHealth(c)}</span></td>
    <td>${esc(c.last||"—")}</td><td><div class="row-actions"><button class="btn" onclick="openHistory(${c.id})">History</button><button class="btn" onclick="openMeeting(${c.id})">Meeting</button></div></td>
  </tr>`;
}
function renderPortfolioHeader(){
  const base = ["Customer","PM","Region","Contract Value","Customer Sentiment","Rating"];
  let row1 = [...base, ...ALL_KPIS.map(k=>k.label),"Overall","Risk Value","6M History","Last Meeting",""];
  document.getElementById("portfolioHead").innerHTML = `<tr>${row1.map(h=>`<th>${esc(h)}</th>`).join("")}</tr>`;
}
function portfolioRow(c){
  return `<tr>
    <td><span class="name">${esc(c.customer)}</span></td><td>${esc(c.pm)}</td><td>${esc(c.region)}</td>
    <td>$${Number(c.value||0).toFixed(1)}M</td><td>${sentimentPill(c.sentiment)}</td><td>${Number(c.rating||0).toFixed(1)}</td>
    ${kpiGroupsCells(c)}
    <td>${overallHealth(c)}</td><td>$${Number(c.riskValue||0).toFixed(1)}M</td><td class="history-cell">${renderHistoryStrip(c)}</td><td>${esc(c.last||"—")}</td>
    <td><div class="row-actions"><button class="btn" onclick="openHistory(${c.id})">History</button><button class="btn" onclick="openMeeting(${c.id})">Meeting</button></div></td>
  </tr>`;
}


function renderAdvancedInsights(data){
  const d=data.length?data:contracts;
  const n=d.length||1;
  const avg=(vals,def=0)=>vals.length?vals.reduce((a,b)=>a+Number(b||0),0)/vals.length:def;
  const customerScore=Math.round(avg(d.map(c=>c.performance?.groups?.customer?.outcomeScore||statusScore(c.health?.outcomeKpi))));
  const positivePct=Math.round(d.filter(c=>c.sentiment==="Positive").length/n*100);
  const avgRating=avg(d.map(c=>Number(c.rating||0)).filter(v=>v>0),0);
  const concerns=d.filter(c=>(c.concern||"").trim()).length;
  const outcomeScore=Math.round(avg(d.map(c=>statusScore(c.health?.outcomeKpi)).filter(v=>v>0),0));
  const state = customerScore>=80?"Healthy":customerScore>=65?"Watch":customerScore>=45?"Attention":"Critical";
  const customerScoreEl=document.getElementById("advCustomerScore"); if(customerScoreEl)customerScoreEl.textContent=customerScore;
  const stateEl=document.getElementById("advCustomerState"); if(stateEl){stateEl.textContent=state;stateEl.className="mini-state "+state.toLowerCase();}
  const pp=document.getElementById("advPositivePct"); if(pp)pp.textContent=positivePct+"%";
  const rb=document.getElementById("advSentimentBar"); if(rb)rb.style.width=positivePct+"%";
  const ar=document.getElementById("advRating"); if(ar)ar.textContent=avgRating.toFixed(1)+"/10";
  const ac=document.getElementById("advConcerns"); if(ac)ac.textContent=concerns;
  const os=document.getElementById("advOutcomeScore"); if(os)os.textContent=outcomeScore+"/100";
  const cn=document.getElementById("advCustomerNote"); if(cn)cn.textContent=negativeCustomerInsight(d);

  const value=d.reduce((s,c)=>s+Number(c.value||0),0);
  const risk=d.reduce((s,c)=>s+Number(c.riskValue||0),0);
  const riskPct=value?risk/value*100:0;
  const gm=avg(d.map(c=>c.performance?.financial?.grossMargin||0),0);
  const pipeline=d.reduce((s,c)=>s+Number(c.performance?.financial?.pipelineOpportunity||0),0);
  const pastDue=d.reduce((s,c)=>s+Number(c.performance?.groups?.financial?.pastDue||0),0);
  const booked=avg(d.map(c=>c.performance?.financial?.bookedMargin||0),0);
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set("advContractValue","$"+value.toFixed(1)+"M");set("advRiskValue","$"+risk.toFixed(1)+"M");set("advRiskPct",riskPct.toFixed(1)+"%");set("advGrossMargin",Math.round(gm)+"%");set("advPipeline","$"+pipeline.toFixed(1)+"M");set("advPastDue",pastDue);set("advBookedMargin",Math.round(booked)+"%");
  const riskBar=document.getElementById("advRiskBar");if(riskBar)riskBar.style.width=Math.min(100,riskPct*2.5)+"%";

  const renewalVals=d.map(c=>statusScore(c.health?.renewal)).filter(v=>v>0);
  const renewalScore=Math.round(avg(renewalVals,0));
  const renewalWatch=d.filter(c=>["Yellow","Orange"].includes(c.health?.renewal)).length;
  const renewalRed=d.filter(c=>c.health?.renewal==="Red").length;
  const readyPct=Math.round(d.filter(c=>c.health?.renewal==="Green").length/n*100);
  const trackerReady=Math.round(d.filter(c=>c.performance?.groups?.growth?.tracker2026==="Updated"&&c.performance?.groups?.growth?.tracker2027==="Updated").length/n*100);
  set("advRenewalScore",renewalScore+"/100");set("advRenewalWatch",renewalWatch);set("advRenewalRed",renewalRed);set("advGrowthPipeline","$"+pipeline.toFixed(1)+"M");set("advTrackerReady",trackerReady+"%");set("advRenewalReady",readyPct+"%");
  const rr=document.getElementById("advRenewalRing");if(rr){rr.style.background=`conic-gradient(var(--green) 0 ${readyPct}%,#e4ebef ${readyPct}% 100%)`;const s=rr.querySelector("span");if(s)s.textContent=readyPct+"%";}
  const rp=document.getElementById("advRenewalProgress");if(rp)rp.style.width=readyPct+"%";

  const meetingCount=meetings.length;
  const actions=meetings.filter(m=>m.action);
  const open=actions.filter(m=>m.actionStatus==="Open").length;
  const inprog=actions.filter(m=>m.actionStatus==="In Progress").length;
  const done=actions.filter(m=>m.actionStatus==="Completed").length;
  const today=new Date().toISOString().slice(0,10);
  const dueSoon=actions.filter(m=>m.due && m.actionStatus!=="Completed" && daysBetween(today,m.due)<=14 && daysBetween(today,m.due)>=0).length;
  const closure=actions.length?Math.round(done/actions.length*100):0;
  set("advMeetingCount",meetingCount);set("advOpenActions",open);set("advInProgress",inprog);set("advCompletedActions",done);set("advDueSoon",dueSoon);set("advClosureRate",closure+"%");
  set("advLatestMeeting",meetings.length?`${meetings.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)))[0].customer} · ${meetings.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)))[0].date}`:"No meeting yet");
  const cp=document.getElementById("advClosureProgress");if(cp)cp.style.width=closure+"%";
}
function daysBetween(a,b){ const aa=new Date(a+"T00:00:00"), bb=new Date(b+"T00:00:00"); return Math.round((bb-aa)/86400000); }
function negativeCustomerInsight(data){
  const negative=data.filter(c=>c.sentiment==="Negative").length;
  const risk=data.filter(c=>["Red","Orange"].includes(overallHealth(c))).length;
  if(negative>0 && risk>0) return `${negative} account(s) have negative customer sentiment while ${risk} account(s) are Orange/Red — review both signals in the meeting.`;
  if(negative>0) return `${negative} account(s) show negative customer sentiment — use the meeting form to validate the service gaps and commitments.`;
  return "Customer sentiment and KPI health are aligned in the current view.";
}

function renderAll(){
  contracts.forEach(ensureContractEnhancements);
  populateFilters();
  const data=filteredContracts();
  const total=data.length||1;
  let green=0,yellow=0,orange=0,red=0,blank=0,val=0,risk=0,ratings=0,pos=0,concern=0;
  data.forEach(c=>{
    const h=overallHealth(c);
    if(h==="Green")green++; else if(h==="Yellow")yellow++; else if(h==="Orange")orange++; else if(h==="Red")red++; else blank++;
    val+=Number(c.value||0);risk+=Number(c.riskValue||0);ratings+=Number(c.rating||0);
    if(c.sentiment==="Positive")pos++;
    if((c.concern||"").trim())concern++;
  });
  const score=scoreHealth(data), avg=ratings/total, posPct=Math.round(pos/total*100);
  const state=score>=80?"Healthy":score>=65?"Watch":score>=45?"Attention":"Critical";
  document.getElementById("mScore").textContent=score+"/100";
  document.getElementById("mState").textContent=state;
  document.getElementById("mTotal").textContent=data.length;
  document.getElementById("mGreen").textContent=green;document.getElementById("mYellow").textContent=yellow;document.getElementById("mOrange").textContent=orange;document.getElementById("mRed").textContent=red;
  document.getElementById("mValue").textContent="$"+val.toFixed(1)+"M";document.getElementById("mRisk").textContent="$"+risk.toFixed(1)+"M";document.getElementById("mRating").textContent=avg.toFixed(1)+"/10";
  document.getElementById("sGreen").textContent=green;document.getElementById("sYellow").textContent=yellow;document.getElementById("sOrange").textContent=orange;document.getElementById("sRed").textContent=red;document.getElementById("sBlank").textContent=blank;
  document.getElementById("ringText").textContent=score;
  const stateClass = score>=80 ? "healthy" : score>=65 ? "watch" : score>=45 ? "attention" : "critical";
  const summaryBadge=document.getElementById("summaryStateBadge"); if(summaryBadge){summaryBadge.textContent=state; summaryBadge.className="summary-badge "+stateClass;}
  const scoreLabel=document.getElementById("summaryScoreLabel"); if(scoreLabel)scoreLabel.textContent=`Overall portfolio health · ${score}/100`;
  const sc=document.getElementById("summaryContractCount"); if(sc)sc.textContent=data.length;
  const sr=document.getElementById("summaryRiskValue"); if(sr)sr.textContent="$"+risk.toFixed(1)+"M";
  const srat=document.getElementById("summaryRating"); if(srat)srat.textContent=avg.toFixed(1);
  const dist=document.getElementById("healthDistribution");
  if(dist){
    const totalD=Math.max(1, data.length);
    dist.innerHTML=[['Green',green,'dist-g'],['Yellow',yellow,'dist-y'],['Orange',orange,'dist-o'],['Red',red,'dist-r']].map(([label,nm,cls])=>`<div class="dist"><div class="dist-line"><span><i class="dot ${label==='Green'?'g':label==='Yellow'?'y':label==='Orange'?'o':'r'}"></i><small>${label}</small></span><b>${nm}</b></div><div class="dist-track"><span class="${cls}" style="width:${Math.round(nm/totalD*100)}%"></span></div></div>`).join('');
  }
  const col=red?"var(--red)":orange?"var(--orange)":yellow?"var(--yellow)":"var(--green)";
  document.getElementById("ring").style.background=`conic-gradient(${col} ${score}%,#e8eef3 ${score}% 100%)`;
  // Advanced dashboard insight cards are rendered separately from the legacy metric blocks.
  document.getElementById("dashboardRows").innerHTML=data.map(dashboardRow).join("")||`<tr><td colspan="15" class="empty">No contracts match the selected filters.</td></tr>`;
  const portfolio=document.getElementById("portfolioRows"); if(portfolio) portfolio.innerHTML=data.map(portfolioRow).join("")||`<tr><td colspan="40" class="empty">No contracts match the selected filters.</td></tr>`;
  renderRiskMini(data);
  renderMeetingHistory();
  renderActions();
  renderSelectedSnapshot(data[0]||contracts[0]);
  renderHomePerformanceAnalytics(data);
  renderHomeHistoryOverview(data);
  renderAdvancedInsights(data);
  persist();
}
function renderRiskMini(data){
  const risks=data.filter(c=>["Red","Orange"].includes(overallHealth(c))).sort((a,b)=>statusRank(overallHealth(b))-statusRank(overallHealth(a))).slice(0,6);
  document.getElementById("riskMini").innerHTML=risks.length?risks.map(c=>`<div class="risk-row">
    <div><b>${esc(c.customer)}</b><div class="small">${esc(c.pm)}</div></div>
    <div>${c.sentiment==="Negative"?sentimentPill("Negative"):sentimentPill(c.sentiment||"")}</div>
    <div>${overallHealth(c)}</div><div>$${Number(c.riskValue||0).toFixed(1)}M</div><div>${c.last||"—"}</div>
    <button class="btn" onclick="openMeeting(${c.id})">Open</button>
  </div>`).join(""):`<div class="empty">No Orange / Red contracts in the current view.</div>`;
}
function renderMeetingHistory(){
  const arr=meetings.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  const holder=document.getElementById("meetingHistoryRows");
  if(holder){
    holder.innerHTML=arr.length?arr.map(m=>{
      const hs=Object.values(m.healthSnapshot||{}).filter(Boolean).length;
      return `<tr><td>${esc(m.date||"—")}</td><td><b class="name">${esc(m.customer)}</b></td><td>${esc(m.pm)}</td><td>${Number(m.rating||0).toFixed(1)}</td><td>${sentimentPill(m.sentiment||"")}</td><td>${hs}</td><td>${statusValue(m.healthSnapshot?.next90DayRisk)}</td><td>${esc(m.action||"—")}</td><td>${esc(m.actionStatus||"—")}</td></tr>`;
    }).join(""):`<tr><td colspan="9" class="empty">No meeting records yet.</td></tr>`;
  }
}
function renderActions(){
  const arr=meetings.filter(m=>m.action);
  document.getElementById("actionRows").innerHTML=arr.length?arr.map(m=>{
    const idx=meetings.indexOf(m);
    return `<tr><td><b>${esc(m.action)}</b></td><td>${esc(m.customer)}</td><td>${esc(m.owner||"Unassigned")}</td><td>${esc(m.due||"—")}</td>
    <td><select onchange="setActionStatus(${idx},this.value)"><option ${m.actionStatus==="Open"?"selected":""}>Open</option><option ${m.actionStatus==="In Progress"?"selected":""}>In Progress</option><option ${m.actionStatus==="Completed"?"selected":""}>Completed</option></select></td>
    <td>${esc(m.source||"Meeting")}</td><td>${esc(m.updatedAt||m.date||"—")}</td><td><button class="btn" onclick="removeAction(${idx})">Remove</button></td></tr>`;
  }).join(""):`<tr><td colspan="8" class="empty">No action items.</td></tr>`;
}
function renderSelectedSnapshot(c){
  const el=document.getElementById("selectedSnapshot");
  if(!c){el.innerHTML='<div class="empty">No contract selected.</div>';return}
  const groups=[["Customer & Outcomes",KPI_GROUPS.customer],["Financial",KPI_GROUPS.financial],["Growth",KPI_GROUPS.growth],["People",KPI_GROUPS.people],["Internal Activities",KPI_GROUPS.internal]];
  el.innerHTML=`<div class="panel"><b style="font-size:15px">${esc(c.customer)}</b><div class="small">${esc(c.pm)} · ${esc(c.region)} · $${Number(c.value||0).toFixed(1)}M</div><div style="margin:8px 0">${sentimentPill(c.sentiment||"")} <span class="health-chip" style="margin-left:6px"><span class="dot ${overallHealth(c)==="Green"?"g":overallHealth(c)==="Yellow"?"y":overallHealth(c)==="Orange"?"o":overallHealth(c)==="Red"?"r":"b"}"></span>${overallHealth(c)}</span> <span class="small">Rating ${Number(c.rating||0).toFixed(1)}/10</span></div>
  ${groups.map(([g,arr])=>`<div class="section-divider"></div><b>${g}</b><div class="four" style="margin-top:6px">${arr.map(k=>`<div class="panel"><div class="small">${esc(k.label)}</div><div>${statusValue(c.health?.[k.key])}</div></div>`).join("")}</div>`).join("")}
  <div class="section-divider"></div><b>Core dimensions</b><div class="four" style="margin-top:6px">${["delivery","financial","risk","renewal"].map(k=>`<div class="panel"><div class="small">${k}</div><div>${statusValue(c.health?.[k])}</div></div>`).join("")}</div>
  <div class="section-divider"></div><div class="small">Last meeting: ${esc(c.last||"—")} · Value at risk: $${Number(c.riskValue||0).toFixed(1)}M</div></div>`;
}
function statusValue(v){return v?`<span class="health-chip"><span class="dot ${v==="Green"?"g":v==="Yellow"?"y":v==="Orange"?"o":v==="Red"?"r":"b"}"></span>${v}</span>`:"<span class='small'>Blank / not assessed</span>";}


function renderHomePerformanceAnalytics(data){
  const d = data.length ? data : contracts;
  const perf = d.map(c=>c.performance||{});
  const avg = (vals, fallback=0)=> vals.length ? vals.reduce((a,b)=>a+Number(b||0),0)/vals.length : fallback;
  const enable = perf.map(p=>p.enableServices||{});
  const contractPerf = perf.map(p=>p.contract||{});
  const financial = perf.map(p=>p.financial||{});
  document.getElementById('homeServiceScore').textContent=Math.round(avg(enable.map(x=>x.avgScore),72));
  document.getElementById('homeCoverage').textContent=Math.round(avg(enable.map(x=>x.coverage),78));
  document.getElementById('homeServiceHealth').textContent=Math.round(avg(enable.map(x=>x.serviceHealth),66));
  document.getElementById('homeUdc').textContent='v2.8.3';
  document.getElementById('homeEsUdc').textContent='v2.8.3';
  document.getElementById('homeAvgKpi').textContent=Math.round(avg(contractPerf.map(x=>x.avgKpi),72))+'%';
  const missing=contractPerf.filter(x=>x.missingMonth && x.missingMonth!=='—' && x.missingMonth!=='0').length;
  document.getElementById('homeKpiMissing').textContent=missing?missing+' account(s)':'—';
  document.getElementById('homeProposal').textContent=Math.round(avg(contractPerf.map(x=>x.openProposalRequests),1));
  document.getElementById('homeOverdue').textContent=Math.round(Math.max(...contractPerf.map(x=>Number(x.overdueDays||0)),0));
  const csat=avg(contractPerf.map(x=>x.csat)); const nps=avg(contractPerf.map(x=>x.nps));
  document.getElementById('homeCsat').textContent=Math.round(csat)+'/100';
  document.getElementById('homeNps').textContent=Math.round(nps);
  document.getElementById('homeAssurance').textContent=Math.round(avg(financial.map(x=>x.assurance),-136));
  document.getElementById('homeRequested').textContent=Math.round(avg(financial.map(x=>x.requestedServices).filter(v=>v!=='—'),0))||'—';
  document.getElementById('homePm').textContent=Math.round(avg(financial.map(x=>x.preventiveMaintenance),127));
  document.getElementById('homeCyber').textContent=Math.round(avg(financial.map(x=>x.cyber),-416));
  document.getElementById('homeTraining').textContent=Math.round(avg(financial.map(x=>x.training).filter(v=>v!=='—'),0))||'—';
  document.getElementById('homeBgp').textContent=Math.round(avg(financial.map(x=>x.bgpPlus),0));
  document.getElementById('homePipeline').textContent='$'+avg(financial.map(x=>x.pipelineOpportunity),0).toFixed(1)+'M';
  document.getElementById('homeBookedMargin').textContent=Math.round(avg(financial.map(x=>x.bookedMargin),46))+'%';
  document.getElementById('homeGrossMargin').textContent=Math.round(avg(financial.map(x=>x.grossMargin),54))+'%';

  // Gauge fills from actual aggregate values.
  const serviceScore=Math.round(avg(enable.map(x=>x.avgScore),72));
  const coverage=Math.round(avg(enable.map(x=>x.coverage),78));
  const serviceHealth=Math.round(avg(enable.map(x=>x.serviceHealth),66));
  document.getElementById('homeServiceGauge').style.background=`conic-gradient(var(--green) 0 ${serviceScore}%,#dfe8ee ${serviceScore}% 100%)`;
  document.getElementById('homeCoverageGauge').style.background=`conic-gradient(var(--green) 0 ${coverage}%,#dfe8ee ${coverage}% 100%)`;
  document.getElementById('homeHealthGauge').style.background=`conic-gradient(#7459c7 0 ${serviceHealth}%,#dfe8ee ${serviceHealth}% 100%)`;

  const score=scoreHealth(d), state=score>=80?'HEALTHY':score>=65?'WATCH':score>=45?'ATTENTION':'CRITICAL';
  document.getElementById('homeA360Score').textContent=score;
  document.getElementById('homeA360State').textContent=state;
  const col=score>=80?'var(--green)':score>=65?'var(--orange)':score>=45?'var(--orange)':'var(--red)';
  document.getElementById('homeA360Ring').style.background=`conic-gradient(${col} 0 ${score}%,#e7edf2 ${score}% 100%)`;

  const dim = (field)=>Math.round(avg(d.map(c=>statusScore(c.health?.[field])),0));
  setHomeDim('homeDimCustomerStatus','homeDimCustomerScore',d.map(c=>c.sentiment==='Positive'?'GOOD':c.sentiment==='Negative'?'CRITICAL':'ATTENTION'),Math.max(0,Math.round(avg(d.map(c=>c.performance?.groups?.customer?.sentimentScore||0)))));
  setHomeDim('homeDimOutcomeStatus','homeDimOutcomeScore',d.map(c=>c.health?.outcomeKpi||'Blank'),dim('outcomeKpi'));
  setHomeDim('homeDimDeliveryStatus','homeDimDeliveryScore',d.map(c=>c.health?.delivery||'Blank'),dim('delivery'));
  setHomeDim('homeDimFinancialStatus','homeDimFinancialScore',d.map(c=>c.health?.financial||'Blank'),dim('financial'));
  setHomeDim('homeDimRiskStatus','homeDimRiskScore',d.map(c=>c.health?.risk||'Blank'),dim('risk'));
  const trend = d.map(c=>Number(c.rating||0)).filter(Boolean);
  document.getElementById('homeDimTrendStatus').textContent=trend.length && avg(trend)<6.5?'DETERIORATING':trend.length && avg(trend)>8?'IMPROVING':'STABLE';

  renderHomeGroupAnalytics(d);
}
function statusScore(v){ return ({Green:100,Yellow:80,Orange:60,Red:20,Blank:0})[v||'Blank']||0; }
function setHomeDim(statusId,scoreId,values,score){
  const counts={Green:0,Yellow:0,Orange:0,Red:0,Blank:0,GOOD:0,ATTENTION:0,CRITICAL:0};
  (values||[]).forEach(v=>counts[v]=(counts[v]||0)+1);
  let state='ATTENTION';
  if(values && values.some(v=>v==='Red'||v==='CRITICAL')) state='CRITICAL';
  else if(values && values.some(v=>v==='Orange'||v==='Negative'||v==='Orange')) state='ATTENTION';
  else if(values && values.every(v=>v==='Green'||v==='Positive')) state='GOOD';
  document.getElementById(statusId).textContent=state;
  document.getElementById(scoreId).textContent=Math.max(0,Math.round(score||0))+'/100';
}
function statusBadge(status){
  const s=status||'Blank'; const cls=s.toLowerCase();
  return `<span class="ga-status ${cls}">${esc(s)}</span>`;
}
function aggregateStatus(defs,data){
  const vals=[]; data.forEach(c=>defs.forEach(k=>{if(c.health?.[k.key]) vals.push(c.health[k.key]);}));
  if(!vals.length) return 'Blank';
  const worst=Math.max(...vals.map(statusRank)); return ({4:'Red',3:'Orange',2:'Yellow',1:'Green'})[worst]||'Blank';
}
function renderHomeGroupAnalytics(data){ return; }

function renderHomeBars(){ return;
  const pms=[...new Set(contracts.map(c=>c.pm))].sort();
  const regions=[...new Set(contracts.map(c=>c.region))].sort();
  renderBars('homePmBars',pms,x=>contracts.filter(c=>c.pm===x).length,x=>scoreHealth(contracts.filter(c=>c.pm===x)));
  renderBars('homeRegionBars',regions,x=>contracts.filter(c=>c.region===x).length,x=>scoreHealth(contracts.filter(c=>c.region===x)));
}
function renderHomeKpiCoverage(){ return;
  const total=Math.max(1,contracts.length);
  const holder=document.getElementById('homeKpiBars');
  holder.innerHTML=ALL_KPIS.map(k=>({label:k.label,n:contracts.filter(c=>c.health?.[k.key]).length})).sort((a,b)=>b.n-a.n).slice(0,18).map(o=>`<div class="bar-row"><div class="lbl" title="${esc(o.label)}">${esc(o.label)}</div><div class="bar"><span style="width:${Math.round(o.n/total*100)}%"></span></div><b>${Math.round(o.n/total*100)}%</b></div>`).join('');
}
function renderHomeSentiment(){ return;
  const sCount={Positive:0,Neutral:0,Negative:0,Blank:0};contracts.forEach(c=>sCount[c.sentiment||'Blank']++);
  document.getElementById('homeSentimentCards').innerHTML=Object.entries(sCount).map(([k,n])=>`<div class="panel"><div class="small">${k}</div><div class="metric">${n}</div><div class="small">${Math.round(n/Math.max(1,contracts.length)*100)}%</div></div>`).join('');
}
function renderHomeTrend(){ return;
  const byDate={};meetings.forEach(m=>{byDate[m.date]=(byDate[m.date]||[]).concat([Number(m.rating||0)]);});
  const dates=Object.keys(byDate).sort().slice(-8);const vals=dates.map(d=>byDate[d].reduce((a,b)=>a+b,0)/byDate[d].length);const w=650,h=190,p=28;let points='';
  vals.forEach((v,i)=>{const x=p+i*((w-2*p)/Math.max(1,vals.length-1));const y=h-p-(v/10)*(h-2*p);points+=`${x},${y} `;});
  const labels=dates.map((d,i)=>{const x=p+i*((w-2*p)/Math.max(1,dates.length-1));return `<text x="${x}" y="${h-8}" font-size="9" text-anchor="middle" fill="#718096">${d.slice(5)}</text>`}).join('');
  const circles=vals.map((v,i)=>{const x=p+i*((w-2*p)/Math.max(1,vals.length-1));const y=h-p-(v/10)*(h-2*p);return `<circle cx="${x}" cy="${y}" r="4" fill="#1266a8"/><text x="${x}" y="${y-8}" font-size="9" text-anchor="middle" fill="#334155">${v.toFixed(1)}</text>`}).join('');
  document.getElementById('homeTrendChart').innerHTML=`<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><line x1="${p}" y1="${h-p}" x2="${w-p}" y2="${h-p}" stroke="#d7e0e7"/><line x1="${p}" y1="${p}" x2="${p}" y2="${h-p}" stroke="#d7e0e7"/><polyline points="${points}" fill="none" stroke="#1266a8" stroke-width="3"/><line x1="${p}" y1="${p+(h-2*p)*.2}" x2="${w-p}" y2="${p+(h-2*p)*.2}" stroke="#edf1f4"/><line x1="${p}" y1="${p+(h-2*p)*.5}" x2="${w-p}" y2="${p+(h-2*p)*.5}" stroke="#edf1f4"/><line x1="${p}" y1="${p+(h-2*p)*.8}" x2="${w-p}" y2="${p+(h-2*p)*.8}" stroke="#edf1f4"/>${circles}${labels}</svg>`;
}
function renderHomeMatrix(){ return;
  const pms=[...new Set(contracts.map(c=>c.pm))].sort(), regions=['EMEA','AMER','APJ'];
  let s='<div class="head">Performance Manager</div>'+regions.map(r=>`<div class="head">${r}</div>`).join('')+'<div class="head">Total</div>';
  pms.forEach(pm=>{s+=`<div><b>${esc(pm)}</b></div>`;let total=0;regions.forEach(r=>{const d=contracts.filter(c=>c.pm===pm&&c.region===r);total+=d.length;s+=`<div>${d.length?scoreHealth(d)+'/100 · '+d.length:'—'}</div>`});s+=`<div><b>${total}</b></div>`;});
  document.getElementById('homeMatrix').innerHTML=s;
}
function renderBars(elId, labels, counts, scoreFn){
  const max=Math.max(1,...labels.map(counts));
  const holder=document.getElementById(elId); if(!holder)return;
  holder.innerHTML=labels.map(x=>`<div class="bar-row"><div class="lbl">${esc(x)}</div><div class="bar"><span style="width:${Math.round(counts(x)/max*100)}%"></span></div><b>${scoreFn(x)}</b></div>`).join('');
}
async function apiRequest(path, body, method="POST"){
  const base=(settings.apiBase||"/api/a360").replace(/\/$/,"");
  const token=settings.apiToken||"";
  const headers={"Content-Type":"application/json"};
  if(token) headers.Authorization=token.startsWith("Bearer ")?token:"Bearer "+token;
  try{
    const res=await fetch(base+path,{method,headers,body:method==="GET"?undefined:JSON.stringify(body)});
    const data=await res.text();
    if(!res.ok) throw new Error("HTTP "+res.status+" "+data.slice(0,240));
    setSync("SQL Server synced","ok"); return {ok:true,data:data?JSON.parse(data):null};
  }catch(e){ setSync("API error — local cache retained","err"); return {ok:false,error:e.message};}
}
function setSync(msg, cls=""){const el=document.getElementById("syncStatus");el.textContent=msg;el.className="sync "+cls;}

async function updateKpi(id,key,value){
  const c=contracts.find(x=>x.id===id); if(!c)return;
  const previous=c.health?.[key]||"";
  c.health=c.health||{};c.health[key]=value;c.last=new Date().toISOString().slice(0,10);
  persist();renderAll();
  const result=await apiRequest(settings.apiHealth,{contractId:c.id,customer:c.customer,performanceManager:c.pm,meetingDate:c.last,kpi:key,status:value,overallHealth:overallHealth(c)});
  if(result.ok){
    const boot=await apiRequest("/bootstrap",null,"GET");
    if(boot.ok && boot.data){contracts=boot.data.contracts||contracts;meetings=boot.data.meetings||meetings;renderAll();}
  }
  flash(`${key} · ${previous||"Blank"} → ${value||"Blank"} saved`);
}

let meetingStep=1;
function openMeeting(contractId){
  fillMeetingCustomerList();
  const selected=contracts.find(c=>c.id===contractId) || contracts.find(c=>c.customer===document.getElementById("fCustomer").value) || contracts[0];
  if(!selected){flash("Add a contract first");return}
  document.getElementById("mmCustomer").value=selected.id;
  populateMeetingForm(selected);
  meetingStep=1;
  showMeetingStep(1);
  document.getElementById("meetingModal").classList.add("show");
}
function fillMeetingCustomerList(){
  const sel=document.getElementById("mmCustomer");
  sel.innerHTML=contracts.map(c=>`<option value="${c.id}">${esc(c.customer)}</option>`).join("");
}
function populateMeetingForm(c){
  document.getElementById("mmPM").value=c.pm||"";
  document.getElementById("mmDate").value=new Date().toISOString().slice(0,10);
  document.getElementById("mmType").value="Monthly 1:1";
  document.getElementById("mmRating").value=c.rating||"";
  document.getElementById("mmSentiment").value=c.sentiment||"";
  setSentiment(c.sentiment||"");
  document.getElementById("mmValueDelivered").value=c.valueDelivered||"";
  document.getElementById("mmConcern").value=c.concern||"";
  document.getElementById("mmCustomerAction").value=c.customerAction||"";
  document.getElementById("mmPfmAction").value=c.pfmActionText||"";
  document.getElementById("mmMgmtSupport").value=c.managementSupportText||"";
  document.getElementById("mm90Risk").value=c.health?.next90DayRisk||"";
  renderRisk90Choices(c.health?.next90DayRisk||"");
  document.getElementById("mmOwner").value="";
  document.getElementById("mmDue").value="";
  document.getElementById("mmAction").value="";
  buildKpiForm("groupCustomer",KPI_GROUPS.customer,c);
  buildKpiForm("groupFinancial",KPI_GROUPS.financial,c);
  buildKpiForm("groupGrowth",KPI_GROUPS.growth,c);
  buildKpiForm("groupPeople",KPI_GROUPS.people,c);
  buildKpiForm("groupInternal",KPI_GROUPS.internal,c);
}
function meetingStatusButtons(value,key,groupKey){
  const v=value||"";
  const statuses=["","Green","Yellow","Orange","Red"];
  return `<div class="status-choices" data-kpi="${esc(key)}">${statuses.map(st=>{
    const cls=st?st.toLowerCase():"blank";
    const text=st||"Not assessed";
    return `<button type="button" class="status-choice ${cls} ${v===st?"active":""}" onclick="setMeetingKpi('${key}','${st}','${groupKey}')">${text}</button>`;
  }).join("")}</div>`;
}
function buildKpiForm(containerId,defs,c){
  const groupKey=containerId.replace(/^group/,'').toLowerCase();
  document.getElementById(containerId).innerHTML=defs.map((k,i)=>{
    const v=c.health?.[k.key]||"";
    const checked=!!v;
    const subpoint=(`Excel tracker parameter · ${k.key}`);
    return `<div class="kpi-field ${checked?"opted":""}" id="kpiCard_${k.key}">
      <div class="kpi-top">
        <div class="kpi-index">${i+1}</div>
        <div class="kpi-copy"><div class="kpi-point">${esc(k.label)}</div><div class="kpi-subpoint">${esc(subpoint)}</div></div>
        <label class="kpi-opt"><input type="checkbox" id="opt_${k.key}" ${checked?"checked":""} onchange="toggleMeetingKpi('${k.key}',this.checked)"> Use</label>
      </div>
      ${meetingStatusButtons(v,k.key,groupKey)}
    </div>`;
  }).join("");
}
function toggleMeetingKpi(key,checked){
  const card=document.getElementById("kpiCard_"+key);
  if(card) card.classList.toggle("opted",checked);
  if(!checked) setMeetingKpi(key,"","");
}
function setMeetingKpi(key,value,groupKey){
  const cb=document.getElementById("opt_"+key);
  if(cb && value!=="") cb.checked=true;
  const card=document.getElementById("kpiCard_"+key);
  if(card){card.classList.toggle("opted",!!value || !!cb?.checked);}
  const choices=card?.querySelectorAll(".status-choice")||[];
  choices.forEach(b=>{
    const text=b.textContent.trim();
    const isActive=(value==="" && text==="Not assessed") || text===value;
    b.classList.toggle("active",isActive);
  });
  if(card) card.dataset.value=value;
}
function setSentiment(value){
  const v=value||"";
  document.getElementById("mmSentiment").value=v;
  const holder=document.getElementById("mmSentimentChoices"); if(!holder)return;
  const items=[["","Not assessed","blank"],["Positive","Positive","pos"],["Neutral","Neutral","neu"],["Negative","Negative","neg"]];
  holder.innerHTML=items.map(([val,txt,cls])=>`<button type="button" class="sentiment-choice ${cls} ${v===val?"active":""}" onclick="setSentiment('${val}')">${txt}</button>`).join("");
}
function setRisk90(value){
  document.getElementById("mm90Risk").value=value||"";
  renderRisk90Choices(value||"");
}
function renderRisk90Choices(value){
  const holder=document.getElementById("mm90RiskChoices"); if(!holder)return;
  const statuses=["","Green","Yellow","Orange","Red"];
  holder.innerHTML=statuses.map(st=>{const cls=st?st.toLowerCase():"blank";const txt=st||"Not assessed";return `<button type="button" class="status-choice ${cls} ${value===st?"active":""}" onclick="setRisk90('${st}')">${txt}</button>`}).join("");
}
function setGroupStatus(groupKey,status){
  const defs=KPI_GROUPS[groupKey]||[];
  defs.forEach(k=>setMeetingKpi(k.key,status,groupKey));
}
function clearGroup(groupKey){
  const defs=KPI_GROUPS[groupKey]||[];
  defs.forEach(k=>{const cb=document.getElementById("opt_"+k.key);if(cb)cb.checked=false;setMeetingKpi(k.key,"",groupKey);});
}
function openMeetingCustomerChange(){
  const c=contracts.find(x=>x.id===Number(document.getElementById("mmCustomer").value)); if(c)populateMeetingForm(c);
}

function validateMeetingStep(step){
  if(step===1){
    const id=Number(document.getElementById("mmCustomer").value);
    const rating=Number(document.getElementById("mmRating").value);
    if(!id){flash("Select a customer / contract");return false}
    if(!rating || rating<1 || rating>10){flash("Enter a customer rating from 1 to 10");return false}
  }
  return true;
}
function showMeetingStep(step){
  meetingStep=Math.max(1,Math.min(4,step));
  document.querySelectorAll(".wizard-step").forEach(x=>x.classList.toggle("active",Number(x.dataset.step)===meetingStep));
  document.querySelectorAll(".wizard-step-node").forEach(x=>{
    const s=Number(x.dataset.stepNode); x.classList.toggle("active",s===meetingStep); x.classList.toggle("done",s<meetingStep);
  });
  const prog=document.getElementById("wizardProgressBar"); if(prog)prog.style.width=((meetingStep-1)/3*100)+"%";
  const state=document.getElementById("wizardStateText");if(state)state.textContent=`Step ${meetingStep} of 4`;
  const back=document.getElementById("wizardBackBtn"), next=document.getElementById("wizardNextBtn"), save=document.getElementById("wizardSaveBtn");
  if(back)back.style.display=meetingStep>1?"inline-block":"none";
  if(next)next.style.display=meetingStep<4?"inline-block":"none";
  if(save)save.style.display=meetingStep===4?"inline-block":"none";
  if(meetingStep===4)renderMeetingReview();
}
function nextMeetingStep(){
  if(!validateMeetingStep(meetingStep))return;
  showMeetingStep(meetingStep+1);
}
function prevMeetingStep(){ showMeetingStep(meetingStep-1); }
function renderMeetingReview(){
  const id=Number(document.getElementById("mmCustomer")?.value);
  const c=contracts.find(x=>x.id===id); if(!c)return;
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v};
  set("reviewCustomer",c.customer||"—");set("reviewPM",c.pm||"—");
  set("reviewRating",(document.getElementById("mmRating")?.value||"—")+"/10");
  set("reviewSentiment",document.getElementById("mmSentiment")?.value||"Not assessed");
  set("reviewValue",document.getElementById("mmValueDelivered")?.value.trim()||"Not entered");
  set("reviewConcern",document.getElementById("mmConcern")?.value.trim()||"Not entered");
  set("reviewCustomerAction",document.getElementById("mmCustomerAction")?.value.trim()||"Not entered");
  set("review90Risk",document.getElementById("mm90Risk")?.value||"Not assessed");
  let total=0;const counts={Green:0,Yellow:0,Orange:0,Red:0};
  ALL_KPIS.forEach(k=>{
    const cb=document.getElementById("opt_"+k.key); const card=document.getElementById("kpiCard_"+k.key);
    const active=card?.querySelector(".status-choice.active");
    const v=(cb?.checked && active?.textContent.trim()!=="Not assessed") ? active?.textContent.trim() : "";
    if(v){total++;counts[v]++;}
  });
  set("reviewHealthCount",total);
  const holder=document.getElementById("reviewHealthSummary");
  if(holder)holder.innerHTML=Object.entries(counts).filter(([,n])=>n>0).map(([k,n])=>`<span class="r${k[0].toLowerCase()}">${k}: ${n}</span>`).join("")||`<span style="background:#eef2f5;color:#6d7b87">No KPI selected yet</span>`;
}

async function saveMeeting(){
  const id=Number(document.getElementById("mmCustomer").value), c=contracts.find(x=>x.id===id);
  if(!c){flash("Select a contract");return}
  const rating=Number(document.getElementById("mmRating").value);
  if(!rating || rating<1 || rating>10){flash("Enter a customer rating from 1 to 10");return}
  const date=document.getElementById("mmDate").value || new Date().toISOString().slice(0,10);
  c.rating=rating;c.sentiment=document.getElementById("mmSentiment").value;c.last=date;
  c.valueDelivered=document.getElementById("mmValueDelivered").value.trim();
  c.concern=document.getElementById("mmConcern").value.trim();
  c.customerAction=document.getElementById("mmCustomerAction").value.trim();
  c.pfmActionText=document.getElementById("mmPfmAction").value.trim();
  c.managementSupportText=document.getElementById("mmMgmtSupport").value.trim();
  c.health=c.health||{};
  ALL_KPIS.forEach(k=>{
    const opt=document.getElementById("opt_"+k.key);
    const card=document.getElementById("kpiCard_"+k.key);
    const active=card?.querySelector(".status-choice.active");
    const value=(opt && opt.checked) ? (active && active.textContent.trim()!=="Not assessed" ? active.textContent.trim() : "") : "";
    c.health[k.key]=value;
  });
  c.health.next90DayRisk=document.getElementById("mm90Risk").value;
  /* Keep the core dimensions in sync with the meeting form where applicable. */
  const meeting={
    id:Date.now(),contractId:c.id,customer:c.customer,pm:c.pm,date,type:document.getElementById("mmType").value,
    rating,sentiment:c.sentiment,summary:"",
    valueDelivered:c.valueDelivered,concern:c.concern,customerAction:c.customerAction,pfmAction:c.pfmActionText,managementSupport:c.managementSupportText,
    healthSnapshot:deepClone(c.health),owner:document.getElementById("mmOwner").value.trim(),due:document.getElementById("mmDue").value,
    action:document.getElementById("mmAction").value.trim(),actionStatus:"Open",source:"Meeting workspace",updatedAt:new Date().toISOString()
  };
  if(meeting.action) meetings.push(meeting); else meetings.push(meeting);
  persist(); closeModal(); renderAll(); showPage("dashboard"); flash("Meeting saved. Dashboard and contract health updated.");
  await apiRequest(settings.apiMeeting,meeting);
  if(meeting.action) await apiRequest(settings.apiAction,{meetingId:meeting.id,contractId:c.id,customer:c.customer,owner:meeting.owner,due:meeting.due,action:meeting.action,status:meeting.actionStatus});
}
function openHistory(contractId){
  const c=contracts.find(x=>x.id===contractId); if(!c)return;
  ensureContractEnhancements(c);
  const hm=document.getElementById("historyModal"); if(!hm)return;
  document.getElementById("historyTitle").textContent=`${c.customer} · Health History`;
  document.getElementById("historyDetailHead").innerHTML=`<div class="mini"><small>Performance Manager</small><b>${esc(c.pm)}</b></div><div class="mini"><small>Current Health</small><b>${esc(overallHealth(c))}</b></div><div class="mini"><small>Current Rating</small><b>${Number(c.rating||0).toFixed(1)}/10</b></div>`;
  document.getElementById("historyDetailList").innerHTML=c.history.map(h=>`<div class="history-detail-row"><small>${esc(h.month)}</small><div>${historyCell(h.overall)} <b style="margin-left:5px">${esc(h.overall)}</b></div><b>${Number(h.rating||0).toFixed(1)}/10</b></div>`).join('');
  hm.classList.add("show");
}

function closeModal(){document.querySelectorAll(".modal").forEach(x=>x.classList.remove("show"))}

function openContract(){document.getElementById("cCustomer").value="";document.getElementById("cPM").value="";document.getElementById("cValue").value="";document.getElementById("contractModal").classList.add("show")}
function saveContract(){
  const customer=document.getElementById("cCustomer").value.trim(); if(!customer){flash("Enter customer name");return}
  const c={
    id:Date.now(),customer,pm:document.getElementById("cPM").value.trim()||"Unassigned",region:document.getElementById("cRegion").value,
    value:Number(document.getElementById("cValue").value||0),sentiment:"",rating:0,last:new Date().toISOString().slice(0,10),riskValue:0,health:{}
  };
  ensureContractEnhancements(c); contracts.push(c);persist();closeModal();renderAll();flash("Contract added");
  apiRequest("/contracts",c).then(async r=>{ if(r.ok){ const b=await apiRequest("/bootstrap",null,"GET"); if(b.ok&&b.data){contracts=b.data.contracts||contracts;meetings=b.data.meetings||meetings;renderAll();} } });
}
function setActionStatus(index,status){
  const m=meetings[index]; if(!m)return;m.actionStatus=status;m.updatedAt=new Date().toISOString();persist();renderAll();flash("Action status updated");
  apiRequest(settings.apiAction,{meetingId:m.id,contractId:m.contractId,customer:m.customer,owner:m.owner,due:m.due,action:m.action,status});
}
async function removeAction(index){const m=meetings[index];if(!m)return;m.action="";m.actionStatus="Completed";m.updatedAt=new Date().toISOString();persist();renderAll();await apiRequest("/actions/remove",{meetingId:m.id});flash("Action removed from tracker")}
function resetFilters(){
  ["fPM","fCustomer","fRegion","fMonth","fHealth","fSentiment"].forEach(id=>{const el=document.getElementById(id);el.value=id==="fPM"||id==="fCustomer"||id==="fRegion"||id==="fMonth"||id==="fHealth"||id==="fSentiment"?"All":""});
  renderAll();
}
async function resetDemo(){
  if(!confirm("Reset all database data to the built-in demo dataset?"))return;
  const result=await apiRequest("/reset-demo",{},"POST");
  if(result.ok){const b=await apiRequest("/bootstrap",null,"GET");if(b.ok&&b.data){contracts=b.data.contracts||[];meetings=b.data.meetings||[];persist();resetFilters();renderAll();flash("Database demo data restored");return;}}
  contracts=deepClone(DEMO_CONTRACTS);meetings=deepClone(DEMO_MEETINGS);persist();resetFilters();flash("Local demo data restored");
}
function exportCSV(){
  const data=filteredContracts();
  const headers=["Customer","Performance Manager","Region","Contract Value","Customer Sentiment","Rating",...ALL_KPIS.map(k=>k.label),"Delivery","Financial","Risk","Renewal","Overall Health","Risk Value","Last Meeting"];
  const rows=data.map(c=>[
    c.customer,c.pm,c.region,c.value,c.sentiment,c.rating,...ALL_KPIS.map(k=>c.health?.[k.key]||""),
    c.health?.delivery||"",c.health?.financial||"",c.health?.risk||"",c.health?.renewal||"",overallHealth(c),c.riskValue||0,c.last||""
  ]);
  const csv=[headers,...rows].map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\n");
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="A360_Contract_Health_Register.csv";a.click();URL.revokeObjectURL(a.href);
}
function exportJSON(){
  const data={version:1,exportedAt:new Date().toISOString(),contracts,meetings,settings:{...settings,apiToken:""}};
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="A360_Contract_Health_Data.json";a.click();URL.revokeObjectURL(a.href);
}
function importJSON(evt){
  const file=evt.target.files?.[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=()=>{try{const d=JSON.parse(reader.result);if(Array.isArray(d.contracts))contracts=d.contracts;if(Array.isArray(d.meetings))meetings=d.meetings;if(d.settings)settings={...settings,...d.settings};persist();applySettings();renderAll();flash("JSON imported");}catch(e){flash("Import failed: invalid JSON")}};
  reader.readAsText(file);
  evt.target.value="";
}
function clearLocalData(){
  if(!confirm("Clear contracts, meetings and local settings from this browser?"))return;
  localStorage.removeItem(STORAGE.contracts);localStorage.removeItem(STORAGE.meetings);localStorage.removeItem(STORAGE.settings);
  contracts=deepClone(DEMO_CONTRACTS);meetings=[];settings={apiBase:"/api/a360",apiHealth:"/contract-health",apiMeeting:"/meetings",apiAction:"/actions",apiToken:""};persist();applySettings();renderAll();flash("Local data cleared and demo contracts restored");
}
function applySettings(){
  document.getElementById("apiBase").value=settings.apiBase||"";
  document.getElementById("apiHealth").value=settings.apiHealth||"";
  document.getElementById("apiMeeting").value=settings.apiMeeting||"";
  document.getElementById("apiAction").value=settings.apiAction||"";
  document.getElementById("apiToken").value=settings.apiToken||"";
}
function saveSettings(){
  settings.apiBase=document.getElementById("apiBase").value.trim();
  settings.apiHealth=document.getElementById("apiHealth").value.trim()||"/contract-health";
  settings.apiMeeting=document.getElementById("apiMeeting").value.trim()||"/meetings";
  settings.apiAction=document.getElementById("apiAction").value.trim()||"/actions";
  settings.apiToken=document.getElementById("apiToken").value.trim();
  persist();setSync(settings.apiBase?"API URL saved":"Local browser storage active",settings.apiBase?"ok":"");flash("Settings saved");
}
async function testApi(){
  if(!settings.apiBase){flash("Enter API Base URL first");return}
  setSync("Testing API…","");
  const result=await apiRequest("/health",null,"GET");
  if(result.ok)flash("API connection successful");else if(result.skipped)flash("No API configured");
}
function showPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  document.getElementById(page).classList.add("active");
  document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
  if(page==="contracts")renderPortfolioHeader();
  if(page==="settings")applySettings();
}
document.querySelectorAll("[data-page]").forEach(btn=>btn.addEventListener("click",()=>showPage(btn.dataset.page)));
document.getElementById("mmCustomer").addEventListener("change",openMeetingCustomerChange);
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)closeModal()}));

/* Initialize: SQL Server is the primary source; browser storage is fallback cache. */
async function initializeA360(){
  renderPortfolioHeader();
  applySettings();
  try{
    const result=await apiRequest("/bootstrap",null,"GET");
    if(result.ok && result.data){
      contracts=Array.isArray(result.data.contracts)?result.data.contracts:contracts;
      meetings=Array.isArray(result.data.meetings)?result.data.meetings:meetings;
      contracts=contracts.map(c=>{c.health=c.health||{};return c;});
      contracts.forEach(ensureContractEnhancements);
      persist();
      setSync("SQL Server connected","ok");
    }
  }catch(e){ setSync("Using local demo cache","err"); }
  renderPortfolioHeader();
  renderAll();
}
initializeA360();
