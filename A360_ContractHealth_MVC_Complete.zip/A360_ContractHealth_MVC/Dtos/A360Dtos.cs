namespace A360.ContractHealth.Web.Dtos;

public sealed class BootstrapResponse
{
    public List<ContractDto> Contracts { get; set; } = new();
    public List<MeetingDto> Meetings { get; set; } = new();
}

public sealed class ContractDto
{
    public int Id { get; set; }
    public string Customer { get; set; } = "";
    public string Pm { get; set; } = "";
    public string Region { get; set; } = "";
    public decimal Value { get; set; }
    public string Sentiment { get; set; } = "";
    public decimal Rating { get; set; }
    public string? Last { get; set; }
    public decimal RiskValue { get; set; }
    public Dictionary<string,string?> Health { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public List<HistoryDto> History { get; set; } = new();
    public string? ValueDelivered { get; set; }
    public string? Concern { get; set; }
    public string? CustomerAction { get; set; }
    public string? PFMActionText { get; set; }
    public string? ManagementSupportText { get; set; }
}

public sealed class HistoryDto
{
    public string Month { get; set; } = "";
    public string Overall { get; set; } = "Blank";
    public decimal Rating { get; set; }
}

public sealed class MeetingDto
{
    public long Id { get; set; }
    public int ContractId { get; set; }
    public string Customer { get; set; } = "";
    public string Pm { get; set; } = "";
    public string Date { get; set; } = "";
    public decimal Rating { get; set; }
    public string Sentiment { get; set; } = "";
    public string Type { get; set; } = "Monthly 1:1";
    public string Summary { get; set; } = "";
    public string? Owner { get; set; }
    public string? Due { get; set; }
    public string? Action { get; set; }
    public string ActionStatus { get; set; } = "Open";
    public string Source { get; set; } = "Meeting workspace";
    public Dictionary<string,string?> HealthSnapshot { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class ContractHealthUpdateRequest
{
    public int ContractId { get; set; }
    public string? Customer { get; set; }
    public string? PerformanceManager { get; set; }
    public string MeetingDate { get; set; } = "";
    public string Kpi { get; set; } = "";
    public string? Status { get; set; }
    public string? OverallHealth { get; set; }
}

public sealed class MeetingRequest
{
    public long? Id { get; set; }
    public int ContractId { get; set; }
    public string Customer { get; set; } = "";
    public string Pm { get; set; } = "";
    public string Date { get; set; } = "";
    public string Type { get; set; } = "Monthly 1:1";
    public decimal Rating { get; set; }
    public string? Sentiment { get; set; }
    public string? Summary { get; set; }
    public string? ValueDelivered { get; set; }
    public string? Concern { get; set; }
    public string? CustomerAction { get; set; }
    public string? PfmAction { get; set; }
    public string? ManagementSupport { get; set; }
    public string? Next90DayRisk { get; set; }
    public Dictionary<string,string?>? HealthSnapshot { get; set; }
    public string? Owner { get; set; }
    public string? Due { get; set; }
    public string? Action { get; set; }
    public string ActionStatus { get; set; } = "Open";
    public string Source { get; set; } = "Meeting workspace";
}

public sealed class ActionRequest
{
    public long? MeetingId { get; set; }
    public int ContractId { get; set; }
    public string? Customer { get; set; }
    public string? Owner { get; set; }
    public string? Due { get; set; }
    public string? Action { get; set; }
    public string Status { get; set; } = "Open";
}

public sealed class ContractCreateRequest
{
    public int? Id { get; set; }
    public string Customer { get; set; } = "";
    public string Pm { get; set; } = "Unassigned";
    public string Region { get; set; } = "EMEA";
    public decimal Value { get; set; }
}
