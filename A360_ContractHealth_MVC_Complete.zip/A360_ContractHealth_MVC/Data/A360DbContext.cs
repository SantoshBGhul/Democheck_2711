using A360.ContractHealth.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace A360.ContractHealth.Web.Data;

public class A360DbContext : DbContext
{
    public A360DbContext(DbContextOptions<A360DbContext> options) : base(options) { }

    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<PerformanceManager> PerformanceManagers => Set<PerformanceManager>();
    public DbSet<Contract> Contracts => Set<Contract>();
    public DbSet<ContractHealth> ContractHealth => Set<ContractHealth>();
    public DbSet<Meeting> Meetings => Set<Meeting>();
    public DbSet<ActionItem> ActionItems => Set<ActionItem>();
    public DbSet<KpiDefinition> KpiDefinitions => Set<KpiDefinition>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Customer>(e => { e.ToTable("Customers"); e.HasKey(x => x.Id); e.Property(x=>x.Name).HasMaxLength(200).IsRequired(); e.Property(x=>x.Region).HasMaxLength(20).IsRequired(); });
        modelBuilder.Entity<PerformanceManager>(e => { e.ToTable("PerformanceManagers"); e.HasKey(x=>x.Id); e.Property(x=>x.Name).HasMaxLength(150).IsRequired(); e.Property(x=>x.Email).HasMaxLength(250); });
        modelBuilder.Entity<Contract>(e => {
            e.ToTable("Contracts"); e.HasKey(x=>x.Id);
            e.Property(x=>x.ContractValueM).HasColumnType("decimal(18,2)"); e.Property(x=>x.CustomerRating).HasColumnType("decimal(4,1)"); e.Property(x=>x.ValueAtRiskM).HasColumnType("decimal(18,2)");
            e.Property(x=>x.CustomerSentiment).HasMaxLength(30); e.Property(x=>x.Region).HasMaxLength(20).IsRequired();
            e.HasOne(x=>x.Customer).WithMany(x=>x.Contracts).HasForeignKey(x=>x.CustomerId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x=>x.PerformanceManager).WithMany(x=>x.Contracts).HasForeignKey(x=>x.PerformanceManagerId).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<ContractHealth>(e => {
            e.ToTable("ContractHealth"); e.HasKey(x=>x.Id); e.HasIndex(x=>new {x.ContractId,x.AssessmentMonth}).IsUnique(); e.HasIndex(x=>x.MeetingId);
            e.Property(x=>x.AssessmentMonth).HasColumnType("date");
            foreach(var p in typeof(ContractHealth).GetProperties().Where(p=>p.PropertyType==typeof(string))) e.Property<string>(p.Name).HasMaxLength(30);
            e.HasOne(x=>x.Contract).WithMany(x=>x.HealthAssessments).HasForeignKey(x=>x.ContractId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x=>x.Meeting).WithMany(x=>x.HealthAssessments).HasForeignKey(x=>x.MeetingId).OnDelete(DeleteBehavior.SetNull);
        });
        modelBuilder.Entity<Meeting>(e => {
            e.ToTable("Meetings"); e.HasKey(x=>x.Id); e.Property(x=>x.MeetingType).HasMaxLength(50).IsRequired(); e.Property(x=>x.CustomerRating).HasColumnType("decimal(4,1)");
            e.Property(x=>x.Sentiment).HasMaxLength(30); e.Property(x=>x.ActionStatus).HasMaxLength(30); e.Property(x=>x.Source).HasMaxLength(100);
            e.HasOne(x=>x.Contract).WithMany(x=>x.Meetings).HasForeignKey(x=>x.ContractId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x=>x.PerformanceManager).WithMany(x=>x.Meetings).HasForeignKey(x=>x.PerformanceManagerId).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<ActionItem>(e => {
            e.ToTable("ActionItems"); e.HasKey(x=>x.Id); e.Property(x=>x.Action).HasMaxLength(1000).IsRequired(); e.Property(x=>x.Status).HasMaxLength(30); e.Property(x=>x.Source).HasMaxLength(100);
            e.HasOne(x=>x.Contract).WithMany(x=>x.ActionItems).HasForeignKey(x=>x.ContractId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x=>x.Meeting).WithMany(x=>x.ActionItems).HasForeignKey(x=>x.MeetingId).OnDelete(DeleteBehavior.SetNull);
        });
        modelBuilder.Entity<KpiDefinition>(e => { e.ToTable("KpiDefinitions"); e.HasKey(x=>x.Id); e.HasIndex(x=>x.Key).IsUnique(); e.Property(x=>x.GroupKey).HasMaxLength(40).IsRequired(); e.Property(x=>x.Key).HasMaxLength(80).IsRequired(); e.Property(x=>x.Label).HasMaxLength(250).IsRequired(); });
    }
}
