using A360.ContractHealth.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace A360.ContractHealth.Web.Data;

public static class DbInitializer
{
    public static async Task SeedAsync(A360DbContext db)
    {
        if(await db.KpiDefinitions.AnyAsync() && await db.Contracts.AnyAsync()) return;
        await ResetAndSeedAsync(db);
    }

    public static async Task ResetAndSeedAsync(A360DbContext db,CancellationToken ct=default)
    {
        // The runtime seed is intentionally code-based so the application can run without manually executing SQL first.
        await db.Database.EnsureCreatedAsync(ct);
        db.ActionItems.RemoveRange(db.ActionItems);
        db.ContractHealth.RemoveRange(db.ContractHealth);
        db.Meetings.RemoveRange(db.Meetings);
        db.Contracts.RemoveRange(db.Contracts);
        db.Customers.RemoveRange(db.Customers);
        db.PerformanceManagers.RemoveRange(db.PerformanceManagers);
        db.KpiDefinitions.RemoveRange(db.KpiDefinitions);
        await db.SaveChangesAsync(ct);

        var kpis = new[]
        {
            ("customer","outcomeKpi","Outcome KPI achievement",1),("customer","topCustomerPriority","Top customer priority",2),("customer","next90DayRisk","Next 90-day risk",3),("customer","pfmAction","PFM action",4),("customer","managementSupport","Management support required",5),
            ("financial","marginChecked","Margin checked in profitability file",1),("financial","billingForecastUpdated","Billing Forecast updated",2),("financial","pastDues","Past Due's",3),("financial","sespBgpCostsChecked","SESP & BGP costs checked",4),
            ("growth","renewalOnTime","Renewal OnTime",1),("growth","tracker2026","Tracker 2026 updated",2),("growth","tracker2027","Tracker 2027 updated",3),
            ("people","idpCompleted","IDP completed",1),("people","hpdResultsUpdated","HPD results updated",2),("people","siopCompleted","SIOP completed",3),
            ("internal","sfdcTasksClosed","SFDC Tasks Closed",1),("internal","reportingStandard","Reporting according to our standard",2),("internal","customerMeetingsPlanned","Customer meetings planned",3),("internal","digitalPrimeDashboard","Digital Prime Dashboard in use?",4),("internal","contractSetupCorrect","Contract setup in SFDC correct?",5),("internal","a360OpsDashboard","A360 OPS Dashboard status",6),("internal","npsShared","NPS Shared",7),("internal","mosCompleted","MOS completed",8),
            ("core","delivery","Delivery",1),("core","financial","Financial",2),("core","risk","Risk",3),("core","renewal","Renewal",4)
        };
        db.KpiDefinitions.AddRange(kpis.Select(x=>new KpiDefinition{GroupKey=x.Item1,Key=x.Item2,Label=x.Item3,DisplayOrder=x.Item4}));

        var pmNames = new[]{"Marcel Tiemann","Anju Chhabra","Tanvi Bachal","Sebastien","Sudha","Ridhwaan"};
        var pms=pmNames.Select(n=>new PerformanceManager{Name=n}).ToList(); db.PerformanceManagers.AddRange(pms);
        var seed = DemoContracts();
        var customerNames=seed.Select(x=>x.Customer).Append("CBG").Distinct().ToList();
        var customers=customerNames.Select(n=>new Customer{Name=n,Region=seed.FirstOrDefault(x=>x.Customer==n)?.Region??"EMEA"}).ToList(); db.Customers.AddRange(customers);
        await db.SaveChangesAsync(ct);

        foreach(var s in seed)
        {
            var c=new Contract{CustomerId=customers.First(x=>x.Name==s.Customer).Id,PerformanceManagerId=pms.First(x=>x.Name==s.Pm).Id,Region=s.Region,ContractValueM=s.Value,CustomerSentiment=s.Sentiment,CustomerRating=s.Rating,LastMeetingDate=new DateTime(2026,9,22),ValueAtRiskM=s.Risk}; db.Contracts.Add(c);
        }
        var cbg=new Contract{CustomerId=customers.First(x=>x.Name=="CBG").Id,PerformanceManagerId=pms.First(x=>x.Name=="Ridhwaan").Id,Region="EMEA",ContractValueM=6.2m,CustomerSentiment="Neutral",CustomerRating=6.5m,LastMeetingDate=new DateTime(2026,9,22),ValueAtRiskM=.4m}; db.Contracts.Add(cbg);
        await db.SaveChangesAsync(ct);

        foreach(var s in seed)
        {
            var c=db.Contracts.First(x=>x.Id==s.Id); AddHealthRows(db,c,s.Health);
        }
        await db.SaveChangesAsync(ct);

        var meetingSeeds = new[]{
            new {Id=101L,Customer="TAP",Pm="Marcel Tiemann",Date=new DateTime(2026,9,22),Rating=8.5m,Sentiment="Positive",Type="Monthly 1:1",Summary="Customer is satisfied with delivery overall. Preventive maintenance follow-up requested.",Owner="Ridhwaan",Due=new DateTime(2026,10,5),Action="Confirm preventive maintenance schedule",Status="Open",Source="Prototype demo"},
            new {Id=102L,Customer="QSGTL (Shell)",Pm="Marcel Tiemann",Date=new DateTime(2026,9,22),Rating=4.8m,Sentiment="Negative",Type="Monthly 1:1",Summary="Customer expressed dissatisfaction despite several operational indicators being green. Validate customer sentiment and service gaps.",Owner="Marcel Tiemann",Due=new DateTime(2026,10,2),Action="Review customer concerns and agree corrective actions",Status="In Progress",Source="Meeting scenario"},
            new {Id=103L,Customer="TANAP",Pm="Marcel Tiemann",Date=new DateTime(2026,9,22),Rating=6.8m,Sentiment="Neutral",Type="Monthly 1:1",Summary="Discussed overdue actions and renewal readiness.",Owner="Anju Chhabra",Due=new DateTime(2026,10,10),Action="Prepare renewal readiness summary",Status="Open",Source="Prototype demo"},
            new {Id=104L,Customer="Pacific Refining",Pm="Tanvi Bachal",Date=new DateTime(2026,9,26),Rating=5.9m,Sentiment="Negative",Type="Escalation Review",Summary="Delivery and risk require management attention. Customer requested clearer recovery milestones.",Owner="Tanvi Bachal",Due=new DateTime(2026,10,1),Action="Create service recovery plan",Status="Open",Source="Prototype demo"},
            new {Id=105L,Customer="CBG",Pm="Ridhwaan",Date=new DateTime(2026,9,22),Rating=6.5m,Sentiment="Neutral",Type="Monthly 1:1",Summary="Snapshot action list loaded as prototype follow-up backlog.",Owner="Ridhwaan",Due=new DateTime(2026,10,5),Action="Review the snapshot action backlog in the meeting workspace",Status="Open",Source="Excel snapshot"}
        };
        foreach(var m in meetingSeeds){var c=customers.First(x=>x.Name==m.Customer);var pm=pms.First(x=>x.Name==m.Pm);var contract=await db.Contracts.FirstAsync(x=>x.CustomerId==c.Id,ct);var meeting=new Meeting{ContractId=contract.Id,PerformanceManagerId=pm.Id,MeetingDate=m.Date,MeetingType=m.Type,CustomerRating=m.Rating,Sentiment=m.Sentiment,Summary=m.Summary,Owner=m.Owner,DueDate=m.Due,ActionText=m.Action,ActionStatus=m.Status,Source=m.Source};db.Meetings.Add(meeting);await db.SaveChangesAsync(ct);db.ActionItems.Add(new ActionItem{MeetingId=meeting.Id,ContractId=contract.Id,Action=m.Action,Owner=m.Owner,DueDate=m.Due,Status=m.Status,Source=m.Source});}
        await db.SaveChangesAsync(ct);
        foreach(var m in meetingSeeds){var contract=await db.Contracts.FirstAsync(x=>x.CustomerId==customers.First(c=>c.Name==m.Customer).Id,ct);var health=await db.ContractHealth.FirstOrDefaultAsync(x=>x.ContractId==contract.Id && x.AssessmentMonth==new DateTime(2026,9,1),ct);var meeting=await db.Meetings.FirstAsync(x=>x.ContractId==contract.Id && x.MeetingDate==m.Date,ct);if(health!=null)health.MeetingId=meeting.Id;contract.LastMeetingDate=m.Date;contract.CustomerRating=m.Rating;contract.CustomerSentiment=m.Sentiment;}
        await db.SaveChangesAsync(ct);
    }

    private static void AddHealthRows(A360DbContext db,Contract c,Dictionary<string,string> current)
    {
        var months=new[]{new DateTime(2026,4,1),new DateTime(2026,5,1),new DateTime(2026,6,1),new DateTime(2026,7,1),new DateTime(2026,8,1),new DateTime(2026,9,1)};
        var rank=current.Values.Select(StatusRank).DefaultIfEmpty(1).Max();
        for(int i=0;i<months.Length;i++){var r=i==5?rank:Math.Max(1,Math.Min(4,rank+(((c.Id*3+i*2)%5)-2)));var overall=r switch{1=>"Green",2=>"Yellow",3=>"Orange",4=>"Red",_=>"Green"};var h=new ContractHealth{ContractId=c.Id,AssessmentMonth=months[i],OutcomeKpi=overall,TopCustomerPriority="Green",Next90DayRisk=overall,PFMAction=overall,ManagementSupport=overall,MarginChecked="Green",BillingForecastUpdated="Green",PastDues="Green",SespBgpCostsChecked="Green",RenewalOnTime=overall,Tracker2026="Green",Tracker2027="Green",IdpCompleted="Green",HpdResultsUpdated="Green",SiopCompleted="Green",SfdcTasksClosed="Green",ReportingStandard="Green",CustomerMeetingsPlanned="Green",DigitalPrimeDashboard="Green",ContractSetupCorrect="Green",A360OpsDashboard="Green",NpsShared="Green",MosCompleted="Green",Delivery=overall,Financial=overall,Risk=overall,Renewal=overall};db.ContractHealth.Add(h);}
    }

    private static int StatusRank(string? s)=>s switch{"Red"=>4,"Orange"=>3,"Yellow"=>2,"Green"=>1,_=>0};

    private record Seed(int Id,string Customer,string Pm,string Region,decimal Value,string Sentiment,decimal Rating,decimal Risk,Dictionary<string,string> Health);
    private static List<Seed> DemoContracts()=>new()
    {
        new(1,"TAP","Marcel Tiemann","EMEA",12.5m,"Positive",8.5m,.10m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Orange"},{"financial","Green"},{"risk","Green"},{"renewal","Green"}}),
        new(2,"TANAP","Marcel Tiemann","EMEA",8.1m,"Neutral",6.8m,.60m,new(){{"outcomeKpi","Orange"},{"next90DayRisk","Orange"},{"pfmAction","Yellow"},{"managementSupport","Yellow"},{"delivery","Green"},{"financial","Orange"},{"risk","Orange"},{"renewal","Green"}}),
        new(3,"QSGTL (Shell)","Marcel Tiemann","EMEA",15.2m,"Negative",4.8m,1.80m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Red"},{"pfmAction","Orange"},{"managementSupport","Red"},{"delivery","Green"},{"financial","Green"},{"risk","Red"},{"renewal","Orange"}}),
        new(4,"KIPC","Marcel Tiemann","EMEA",9.8m,"Positive",8.1m,0m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Green"},{"risk","Green"},{"renewal","Green"}}),
        new(5,"QAFCO","Marcel Tiemann","EMEA",7.6m,"Positive",8.8m,.30m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Yellow"},{"pfmAction","Yellow"},{"managementSupport","Green"},{"delivery","Orange"},{"financial","Green"},{"risk","Orange"},{"renewal","Green"}}),
        new(6,"ADNOC Sour Gas","Marcel Tiemann","EMEA",11.4m,"Positive",9.0m,0m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Green"},{"risk","Green"},{"renewal","Green"}}),
        new(7,"Motor Oil Hellas","Marcel Tiemann","EMEA",6.1m,"Neutral",7.0m,.70m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Orange"},{"pfmAction","Orange"},{"managementSupport","Yellow"},{"delivery","Orange"},{"financial","Orange"},{"risk","Orange"},{"renewal","Orange"}}),
        new(8,"Grupa Azoty","Marcel Tiemann","EMEA",5.9m,"Positive",8.0m,.10m,new(){{"outcomeKpi","Orange"},{"next90DayRisk","Yellow"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Green"},{"risk","Green"},{"renewal","Green"}}),
        new(9,"Rafineria Gdanska","Marcel Tiemann","EMEA",4.8m,"Positive",8.4m,.40m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Yellow"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Orange"},{"risk","Green"},{"renewal","Orange"}}),
        new(10,"VAR Energy","Marcel Tiemann","EMEA",4.3m,"Negative",5.2m,1.20m,new(){{"outcomeKpi","Orange"},{"next90DayRisk","Red"},{"pfmAction","Orange"},{"managementSupport","Red"},{"delivery","Orange"},{"financial","Orange"},{"risk","Red"},{"renewal","Red"}}),
        new(11,"Nordic Energy","Anju Chhabra","EMEA",10.7m,"Positive",8.7m,.10m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Green"},{"risk","Green"},{"renewal","Green"}}),
        new(12,"Gulf Process Co.","Anju Chhabra","AMER",13.2m,"Neutral",7.1m,.80m,new(){{"outcomeKpi","Orange"},{"next90DayRisk","Orange"},{"pfmAction","Yellow"},{"managementSupport","Green"},{"delivery","Orange"},{"financial","Green"},{"risk","Orange"},{"renewal","Green"}}),
        new(13,"Atlantic Chemicals","Tanvi Bachal","AMER",18.4m,"Positive",8.9m,.20m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Green"},{"risk","Green"},{"renewal","Orange"}}),
        new(14,"Pacific Refining","Tanvi Bachal","APJ",7.9m,"Negative",5.9m,1.50m,new(){{"outcomeKpi","Orange"},{"next90DayRisk","Red"},{"pfmAction","Red"},{"managementSupport","Orange"},{"delivery","Red"},{"financial","Orange"},{"risk","Red"},{"renewal","Red"}}),
        new(15,"Euro Process","Sebastien","EMEA",6.8m,"Positive",8.2m,.20m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Orange"},{"risk","Green"},{"renewal","Green"}}),
        new(16,"Blue River Gas","Sebastien","APJ",9.6m,"Neutral",6.9m,.70m,new(){{"outcomeKpi","Orange"},{"next90DayRisk","Orange"},{"pfmAction","Yellow"},{"managementSupport","Yellow"},{"delivery","Green"},{"financial","Orange"},{"risk","Orange"},{"renewal","Orange"}}),
        new(17,"Eastern Utilities","Sudha","APJ",14.3m,"Positive",9.1m,0m,new(){{"outcomeKpi","Green"},{"next90DayRisk","Green"},{"pfmAction","Green"},{"managementSupport","Green"},{"delivery","Green"},{"financial","Green"},{"risk","Green"},{"renewal","Green"}}),
        new(18,"Central Process","Sudha","AMER",5.5m,"Negative",5.5m,1.10m,new(){{"outcomeKpi","Red"},{"next90DayRisk","Red"},{"pfmAction","Orange"},{"managementSupport","Orange"},{"delivery","Orange"},{"financial","Orange"},{"risk","Red"},{"renewal","Orange"}})
    };
}
