using A360.ContractHealth.Web.Dtos;
using A360.ContractHealth.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace A360.ContractHealth.Web.Controllers;

[ApiController]
[Route("api/a360")]
public class A360ApiController : ControllerBase
{
    private readonly IContractHealthService _service;
    public A360ApiController(IContractHealthService service)=>_service=service;

    [HttpGet("health")] public IActionResult Health()=>Ok(new{status="ok",application="A360 Contract Health",utc=DateTime.UtcNow});
    [HttpGet("bootstrap")] public async Task<ActionResult<BootstrapResponse>> Bootstrap(CancellationToken ct)=>Ok(await _service.GetBootstrapAsync(ct));
    [HttpPost("contract-health")] public async Task<IActionResult> UpdateHealth([FromBody] ContractHealthUpdateRequest request,CancellationToken ct){await _service.UpdateKpiAsync(request,ct);return Ok(new{success=true});}
    [HttpPost("meetings")] public async Task<ActionResult<MeetingDto>> SaveMeeting([FromBody] MeetingRequest request,CancellationToken ct)=>Ok(await _service.SaveMeetingAsync(request,ct));
    [HttpPost("contracts")] public async Task<ActionResult<ContractDto>> CreateContract([FromBody] ContractCreateRequest request,CancellationToken ct)=>Ok(await _service.CreateContractAsync(request,ct));
    [HttpPost("actions")] public async Task<IActionResult> Action([FromBody] ActionRequest request,CancellationToken ct){await _service.UpdateActionAsync(request,ct);return Ok(new{success=true});}
    [HttpPost("actions/remove")] public async Task<IActionResult> RemoveAction([FromBody] ActionRequest request,CancellationToken ct){await _service.RemoveActionAsync(request.MeetingId,ct);return Ok(new{success=true});}
    [HttpPost("reset-demo")] public async Task<IActionResult> ResetDemo(CancellationToken ct){await _service.ResetDemoAsync(ct);return Ok(new{success=true});}
}
