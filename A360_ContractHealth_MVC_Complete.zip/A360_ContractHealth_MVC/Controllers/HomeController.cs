using Microsoft.AspNetCore.Mvc;

namespace A360.ContractHealth.Web.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();
}
