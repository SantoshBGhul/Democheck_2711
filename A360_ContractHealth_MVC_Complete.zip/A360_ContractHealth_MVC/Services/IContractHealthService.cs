using A360.ContractHealth.Web.Dtos;

namespace A360.ContractHealth.Web.Services;

public interface IContractHealthService
{
    Task<BootstrapResponse> GetBootstrapAsync(CancellationToken cancellationToken = default);
    Task UpdateKpiAsync(ContractHealthUpdateRequest request, CancellationToken cancellationToken = default);
    Task<MeetingDto> SaveMeetingAsync(MeetingRequest request, CancellationToken cancellationToken = default);
    Task<ContractDto> CreateContractAsync(ContractCreateRequest request, CancellationToken cancellationToken = default);
    Task UpdateActionAsync(ActionRequest request, CancellationToken cancellationToken = default);
    Task RemoveActionAsync(long? meetingId, CancellationToken cancellationToken = default);
    Task ResetDemoAsync(CancellationToken cancellationToken = default);
}
