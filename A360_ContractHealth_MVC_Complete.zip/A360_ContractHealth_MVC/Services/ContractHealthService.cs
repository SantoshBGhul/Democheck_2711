using A360.ContractHealth.Web.Data;
using A360.ContractHealth.Web.Dtos;
using A360.ContractHealth.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace A360.ContractHealth.Web.Services;

public class ContractHealthService : IContractHealthService
{
    private static readonly string[] HealthKeys =
    {
        "outcomeKpi","topCustomerPriority","next90DayRisk","pfmAction","managementSupport",
        "marginChecked","billingForecastUpdated","pastDues","sespBgpCostsChecked",
        "renewalOnTime","tracker2026","tracker2027",
        "idpCompleted","hpdResultsUpdated","siopCompleted",
        "sfdcTasksClosed","reportingStandard","customerMeetingsPlanned","digitalPrimeDashboard","contractSetupCorrect","a360OpsDashboard","npsShared","mosCompleted",
        "delivery","financial","risk","renewal"
    };

    public ContractHealthService(A360DbContext db) => _db = db;
    private readonly A360DbContext _db;

    public async Task<BootstrapResponse> GetBootstrapAsync(CancellationToken cancellationToken = default)
    {
        var contracts = await _db.Contracts.AsNoTracking()
            .Include(c=>c.Customer).Include(c=>c.PerformanceManager)
            .Include(c=>c.HealthAssessments).Include(c=>c.Meetings)
            .Where(c=>c.IsActive).OrderBy(c=>c.Id).ToListAsync(cancellationToken);

        var meetings = await _db.Meetings.AsNoTracking()
            .Include(m=>m.Contract).ThenInclude(c=>c.Customer)
            .Include(m=>m.PerformanceManager)
            .Include(m=>m.HealthAssessments)
            .OrderByDescending(m=>m.MeetingDate).ThenByDescending(m=>m.Id)
            .ToListAsync(cancellationToken);

        return new BootstrapResponse
        {
            Contracts = contracts.Select(ToContractDto).ToList(),
            Meetings = meetings.Select(ToMeetingDto).ToList()
        };
    }

    public async Task UpdateKpiAsync(ContractHealthUpdateRequest request, CancellationToken cancellationToken = default)
    {
        var contract = await _db.Contracts.FirstOrDefaultAsync(x=>x.Id==request.ContractId && x.IsActive,cancellationToken)
            ?? throw new KeyNotFoundException($"Contract {request.ContractId} not found.");
        var allowed = new HashSet<string>(HealthKeys,StringComparer.OrdinalIgnoreCase);
        if(!allowed.Contains(request.Kpi)) throw new ArgumentException($"Unknown KPI: {request.Kpi}");

        var month = ParseMonth(request.MeetingDate);
        var row = await _db.ContractHealth.FirstOrDefaultAsync(x=>x.ContractId==contract.Id && x.AssessmentMonth==month,cancellationToken);
        if(row is null){ row=new ContractHealth{ContractId=contract.Id,AssessmentMonth=month}; _db.ContractHealth.Add(row); }
        SetHealth(row,request.Kpi,NormalizeStatus(request.Status));
        contract.LastMeetingDate = ParseDate(request.MeetingDate);
        contract.UpdatedAtUtc = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task<MeetingDto> SaveMeetingAsync(MeetingRequest request, CancellationToken cancellationToken = default)
    {
        var contract = await _db.Contracts.Include(c=>c.PerformanceManager).FirstOrDefaultAsync(c=>c.Id==request.ContractId && c.IsActive,cancellationToken)
            ?? throw new KeyNotFoundException($"Contract {request.ContractId} not found.");
        var meetingDate = ParseDate(request.Date);
        var pm = await _db.PerformanceManagers.FirstOrDefaultAsync(x=>x.Id==contract.PerformanceManagerId,cancellationToken)
            ?? throw new KeyNotFoundException("Performance Manager not found.");

        var meeting = new Meeting
        {
            ContractId=contract.Id, PerformanceManagerId=pm.Id, MeetingDate=meetingDate, MeetingType=request.Type,
            CustomerRating=request.Rating, Sentiment=NormalizeSentiment(request.Sentiment), Summary=request.Summary,
            ValueDelivered=request.ValueDelivered, Concern=request.Concern, CustomerAction=request.CustomerAction,
            PFMAction=request.PfmAction, ManagementSupport=request.ManagementSupport, Next90DayRisk=NormalizeStatus(request.Next90DayRisk),
            Owner=request.Owner, DueDate=ParseNullableDate(request.Due), ActionText=request.Action, ActionStatus=request.ActionStatus, Source=request.Source
        };
        _db.Meetings.Add(meeting);
        await _db.SaveChangesAsync(cancellationToken);

        contract.CustomerSentiment = meeting.Sentiment; contract.CustomerRating=meeting.CustomerRating; contract.LastMeetingDate=meetingDate;
        contract.ValueDelivered=meeting.ValueDelivered; contract.Concern=meeting.Concern; contract.CustomerAction=meeting.CustomerAction;
        contract.PFMActionText=meeting.PFMAction; contract.ManagementSupportText=meeting.ManagementSupport; contract.UpdatedAtUtc=DateTime.UtcNow;

        var health = await _db.ContractHealth.FirstOrDefaultAsync(x=>x.ContractId==contract.Id && x.AssessmentMonth==monthStart(meetingDate),cancellationToken);
        if(health is null){health=new ContractHealth{ContractId=contract.Id,AssessmentMonth=monthStart(meetingDate),MeetingId=meeting.Id};_db.ContractHealth.Add(health);}
        health.MeetingId=meeting.Id; health.UpdatedAtUtc=DateTime.UtcNow;
        if(request.HealthSnapshot is not null) foreach(var kv in request.HealthSnapshot) if(HealthKeys.Contains(kv.Key,StringComparer.OrdinalIgnoreCase)) SetHealth(health,kv.Key,NormalizeStatus(kv.Value));
        if(!string.IsNullOrWhiteSpace(request.Next90DayRisk)) health.Next90DayRisk=NormalizeStatus(request.Next90DayRisk);

        if(!string.IsNullOrWhiteSpace(request.Action))
        {
            _db.ActionItems.Add(new ActionItem{MeetingId=meeting.Id,ContractId=contract.Id,Action=request.Action.Trim(),Owner=request.Owner,DueDate=ParseNullableDate(request.Due),Status=request.ActionStatus,Source=request.Source});
        }
        await _db.SaveChangesAsync(cancellationToken);
        return ToMeetingDto(await _db.Meetings.AsNoTracking().Include(m=>m.Contract).ThenInclude(c=>c.Customer).Include(m=>m.PerformanceManager).Include(m=>m.HealthAssessments).FirstAsync(m=>m.Id==meeting.Id,cancellationToken));
    }

    public async Task<ContractDto> CreateContractAsync(ContractCreateRequest request, CancellationToken cancellationToken = default)
    {
        if(string.IsNullOrWhiteSpace(request.Customer)) throw new ArgumentException("Customer is required.");
        var customer = await _db.Customers.FirstOrDefaultAsync(x=>x.Name==request.Customer.Trim(),cancellationToken);
        if(customer is null){customer=new Customer{Name=request.Customer.Trim(),Region=request.Region};_db.Customers.Add(customer);await _db.SaveChangesAsync(cancellationToken);}
        var pm = await GetOrCreatePmAsync(request.Pm,cancellationToken);
        var contract = new Contract{CustomerId=customer.Id,PerformanceManagerId=pm.Id,Region=request.Region,ContractValueM=request.Value};
        _db.Contracts.Add(contract); await _db.SaveChangesAsync(cancellationToken);
        return (await GetBootstrapAsync(cancellationToken)).Contracts.First(x=>x.Id==contract.Id);
    }

    public async Task UpdateActionAsync(ActionRequest request, CancellationToken cancellationToken = default)
    {
        ActionItem? action=null;
        if(request.MeetingId.HasValue) action=await _db.ActionItems.FirstOrDefaultAsync(x=>x.MeetingId==request.MeetingId.Value,cancellationToken);
        if(action is null && !string.IsNullOrWhiteSpace(request.Action))
        {
            if(request.ContractId<=0) throw new ArgumentException("ContractId is required.");
            action=new ActionItem{MeetingId=request.MeetingId,ContractId=request.ContractId,Action=request.Action.Trim()};_db.ActionItems.Add(action);
        }
        if(action is null) return;
        action.Owner=request.Owner; action.DueDate=ParseNullableDate(request.Due); action.Status=request.Status; action.UpdatedAtUtc=DateTime.UtcNow;
        if(action.MeetingId.HasValue){var meeting=await _db.Meetings.FirstOrDefaultAsync(x=>x.Id==action.MeetingId.Value,cancellationToken);if(meeting is not null){meeting.ActionStatus=request.Status;meeting.Owner=request.Owner;meeting.DueDate=action.DueDate;meeting.UpdatedAtUtc=DateTime.UtcNow;}}
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task RemoveActionAsync(long? meetingId, CancellationToken cancellationToken = default)
    {
        if(!meetingId.HasValue) return;
        var items=await _db.ActionItems.Where(x=>x.MeetingId==meetingId.Value).ToListAsync(cancellationToken);
        foreach(var item in items){item.Status="Completed";item.UpdatedAtUtc=DateTime.UtcNow;}
        var meeting=await _db.Meetings.FirstOrDefaultAsync(x=>x.Id==meetingId.Value,cancellationToken);if(meeting is not null){meeting.ActionStatus="Completed";meeting.UpdatedAtUtc=DateTime.UtcNow;}
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task ResetDemoAsync(CancellationToken cancellationToken = default)
    {
        await DbInitializer.ResetAndSeedAsync(_db,cancellationToken);
    }

    private async Task<PerformanceManager> GetOrCreatePmAsync(string? name,CancellationToken ct)
    {
        name=string.IsNullOrWhiteSpace(name)?"Unassigned":name.Trim();
        var pm=await _db.PerformanceManagers.FirstOrDefaultAsync(x=>x.Name==name,ct);
        if(pm is not null)return pm; pm=new PerformanceManager{Name=name};_db.PerformanceManagers.Add(pm);await _db.SaveChangesAsync(ct);return pm;
    }

    private ContractDto ToContractDto(Contract c)
    {
        var latest=c.HealthAssessments.OrderByDescending(x=>x.AssessmentMonth).FirstOrDefault();
        var dto=new ContractDto{Id=c.Id,Customer=c.Customer.Name,Pm=c.PerformanceManager.Name,Region=c.Region,Value=c.ContractValueM,Sentiment=c.CustomerSentiment??"",Rating=c.CustomerRating??0,Last=c.LastMeetingDate?.ToString("yyyy-MM-dd"),RiskValue=c.ValueAtRiskM,ValueDelivered=c.ValueDelivered,Concern=c.Concern,CustomerAction=c.CustomerAction,PFMActionText=c.PFMActionText,ManagementSupportText=c.ManagementSupportText};
        if(latest is not null) dto.Health=ToHealthDictionary(latest);
        dto.History=c.HealthAssessments.OrderBy(x=>x.AssessmentMonth).TakeLast(6).Select(h=>new HistoryDto{Month=h.AssessmentMonth.ToString("MMM-yy"),Overall=Overall(h),Rating=FindMeetingRating(c,h.AssessmentMonth)}).ToList();
        return dto;
    }

    private MeetingDto ToMeetingDto(Meeting m) => new(){Id=m.Id,ContractId=m.ContractId,Customer=m.Contract.Customer.Name,Pm=m.PerformanceManager.Name,Date=m.MeetingDate.ToString("yyyy-MM-dd"),Rating=m.CustomerRating,Sentiment=m.Sentiment??"",Type=m.MeetingType,Summary=m.Summary??"",Owner=m.Owner,Due=m.DueDate?.ToString("yyyy-MM-dd"),Action=m.ActionText,ActionStatus=m.ActionStatus,Source=m.Source,HealthSnapshot=m.HealthAssessments.OrderByDescending(h=>h.Id).FirstOrDefault() is { } h?ToHealthDictionary(h):new()};

    private decimal FindMeetingRating(Contract c,DateTime month) => c.Meetings.Where(m=>monthStart(m.MeetingDate)==monthStart(month)).OrderByDescending(m=>m.Id).Select(m=>(decimal?)m.CustomerRating).FirstOrDefault()??0;
    private static Dictionary<string,string?> ToHealthDictionary(ContractHealth h) => new(StringComparer.OrdinalIgnoreCase)
    {
        ["outcomeKpi"]=h.OutcomeKpi,["topCustomerPriority"]=h.TopCustomerPriority,["next90DayRisk"]=h.Next90DayRisk,["pfmAction"]=h.PFMAction,["managementSupport"]=h.ManagementSupport,
        ["marginChecked"]=h.MarginChecked,["billingForecastUpdated"]=h.BillingForecastUpdated,["pastDues"]=h.PastDues,["sespBgpCostsChecked"]=h.SespBgpCostsChecked,
        ["renewalOnTime"]=h.RenewalOnTime,["tracker2026"]=h.Tracker2026,["tracker2027"]=h.Tracker2027,["idpCompleted"]=h.IdpCompleted,["hpdResultsUpdated"]=h.HpdResultsUpdated,["siopCompleted"]=h.SiopCompleted,
        ["sfdcTasksClosed"]=h.SfdcTasksClosed,["reportingStandard"]=h.ReportingStandard,["customerMeetingsPlanned"]=h.CustomerMeetingsPlanned,["digitalPrimeDashboard"]=h.DigitalPrimeDashboard,["contractSetupCorrect"]=h.ContractSetupCorrect,["a360OpsDashboard"]=h.A360OpsDashboard,["npsShared"]=h.NpsShared,["mosCompleted"]=h.MosCompleted,
        ["delivery"]=h.Delivery,["financial"]=h.Financial,["risk"]=h.Risk,["renewal"]=h.Renewal
    };

    private static void SetHealth(ContractHealth h,string key,string? value)
    {
        var p=typeof(ContractHealth).GetProperties().FirstOrDefault(x=>string.Equals(x.Name,MapKey(key),StringComparison.OrdinalIgnoreCase));
        if(p is not null && p.PropertyType==typeof(string)) p.SetValue(h,value);
        h.UpdatedAtUtc=DateTime.UtcNow;
    }
    private static string MapKey(string key) => key switch
    {
        "outcomeKpi"=>"OutcomeKpi","topCustomerPriority"=>"TopCustomerPriority","next90DayRisk"=>"Next90DayRisk","pfmAction"=>"PFMAction","managementSupport"=>"ManagementSupport",
        "marginChecked"=>"MarginChecked","billingForecastUpdated"=>"BillingForecastUpdated","pastDues"=>"PastDues","sespBgpCostsChecked"=>"SespBgpCostsChecked",
        "renewalOnTime"=>"RenewalOnTime","tracker2026"=>"Tracker2026","tracker2027"=>"Tracker2027","idpCompleted"=>"IdpCompleted","hpdResultsUpdated"=>"HpdResultsUpdated","siopCompleted"=>"SiopCompleted",
        "sfdcTasksClosed"=>"SfdcTasksClosed","reportingStandard"=>"ReportingStandard","customerMeetingsPlanned"=>"CustomerMeetingsPlanned","digitalPrimeDashboard"=>"DigitalPrimeDashboard","contractSetupCorrect"=>"ContractSetupCorrect","a360OpsDashboard"=>"A360OpsDashboard","npsShared"=>"NpsShared","mosCompleted"=>"MosCompleted",
        "delivery"=>"Delivery","financial"=>"Financial","risk"=>"Risk","renewal"=>"Renewal", _=>key
    };
    private static string? NormalizeStatus(string? value){if(string.IsNullOrWhiteSpace(value)||value=="Not assessed")return null; var v=value.Trim(); return new[]{"Green","Yellow","Orange","Red"}.FirstOrDefault(x=>x.Equals(v,StringComparison.OrdinalIgnoreCase));}
    private static string? NormalizeSentiment(string? value){if(string.IsNullOrWhiteSpace(value)||value=="Not assessed")return null;return new[]{"Positive","Neutral","Negative"}.FirstOrDefault(x=>x.Equals(value.Trim(),StringComparison.OrdinalIgnoreCase));}
    private static DateTime ParseDate(string? s)=>DateTime.TryParse(s,out var d)?d.Date:DateTime.UtcNow.Date;
    private static DateTime? ParseNullableDate(string? s)=>DateTime.TryParse(s,out var d)?d.Date:null;
    private static DateTime ParseMonth(string? s)=>monthStart(ParseDate(s));
    private static DateTime monthStart(DateTime d)=>new(d.Year,d.Month,1);
    private static string Overall(ContractHealth h){var vals=new[]{h.OutcomeKpi,h.TopCustomerPriority,h.Next90DayRisk,h.PFMAction,h.ManagementSupport,h.MarginChecked,h.BillingForecastUpdated,h.PastDues,h.SespBgpCostsChecked,h.RenewalOnTime,h.Tracker2026,h.Tracker2027,h.IdpCompleted,h.HpdResultsUpdated,h.SiopCompleted,h.SfdcTasksClosed,h.ReportingStandard,h.CustomerMeetingsPlanned,h.DigitalPrimeDashboard,h.ContractSetupCorrect,h.A360OpsDashboard,h.NpsShared,h.MosCompleted,h.Delivery,h.Financial,h.Risk,h.Renewal}.Where(x=>!string.IsNullOrWhiteSpace(x)).Select(x=>x!).ToList();if(vals.Count==0)return "Blank";if(vals.Contains("Red",StringComparer.OrdinalIgnoreCase))return "Red";if(vals.Contains("Orange",StringComparer.OrdinalIgnoreCase))return "Orange";if(vals.Contains("Yellow",StringComparer.OrdinalIgnoreCase))return "Yellow";return "Green";}
}
