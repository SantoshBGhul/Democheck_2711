import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'meetings', pathMatch: 'full' },
  
  {
    path: 'meetings',
    loadComponent: () => import('./pages/meetings/meetings').then(m => m.Meetings),
    title: 'A360 · Meetings',
  },

  {
    path: 'dashboard',
    loadComponent: () => import('./pages/dashboard/dashboard').then(m => m.Dashboard),
    title: 'A360 · Dashboard',
  },

  {
    path: 'actions',
    loadComponent: () => import('./pages/actions/actions').then(m => m.Actions),
    title: 'A360 · Actions',
  },

  {
    path: 'admin',
    loadComponent: () => import('./pages/admin/admin').then(m => m.Admin),
    title: 'A360 · Admin',
  },
 
  { path: '**', redirectTo: 'meetings' },
];
