import { Injectable, inject, signal, computed, resource } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { ApiService } from './api';
import {
  Contract, Meeting, PerformanceManager, DashboardSummary,
  ALL_KPIS, statusScore, statusRank,
} from '../models/a360.models';

export interface Filters {
  pm: string;
  customer: string;
  region: string;
  month: string;
  health: string;
  sentiment: string;
}

const DEFAULT_FILTERS: Filters = {
  pm: 'All', customer: 'All', region: 'All', month: 'All', health: 'All', sentiment: 'All',
};


@Injectable({ providedIn: 'root' })
export class StateService {
  private readonly api = inject(ApiService);

  readonly filters = signal<Filters>({ ...DEFAULT_FILTERS });

  // ============ Resource API (Angular 22) ============
  readonly contractsResource = resource({
    params: () => ({ filters: this.filters() }),
    loader: async ({ params, abortSignal }) => {
      const res = await firstValueFrom(this.api.contracts(this.buildParams(params.filters), 1, 500));
      return res.items;
    },
    defaultValue: [] as readonly Contract[],
  });

  readonly summaryResource = resource({
    params: () => ({ filters: this.filters() }),
    loader: async ({ params }) =>
      await firstValueFrom(this.api.dashboardSummary(this.buildParams(params.filters))),
    defaultValue: {} as DashboardSummary
  });

  readonly pmsResource = resource({
    loader: async () => await firstValueFrom(this.api.performanceManagers()),
    defaultValue: [] as readonly PerformanceManager[],
  });

  readonly meetingsResource = resource({
    loader: async () => {
      const res = await firstValueFrom(this.api.meetings({}, 1, 500));
      return res.items;
    },
    defaultValue: [] as readonly Meeting[],
  });

  // ============ Derived signals ============
  readonly contracts = computed<readonly Contract[]>(() => this.contractsResource.value());
  readonly pms = computed<readonly PerformanceManager[]>(() => this.pmsResource.value());
  readonly meetings = computed<readonly Meeting[]>(() => this.meetingsResource.value());
  readonly summary = computed<DashboardSummary | null>(() => this.summaryResource.value());

  readonly loading = computed(() =>
    this.contractsResource.isLoading() ||
    this.summaryResource.isLoading() ||
    this.pmsResource.isLoading() ||
    this.meetingsResource.isLoading()
  );

  readonly pmsList = computed<readonly string[]>(() => {
    const set = new Set<string>();
    for (const p of this.pms()) set.add(p.name);
    for (const c of this.contracts()) if (c.pmName) set.add(c.pmName);
    return [...set].sort();
  });

  readonly customerList = computed<readonly string[]>(() =>
    [...new Set(this.contracts().map(c => c.customer))].sort()
  );

  // ============ Actions ============
  reload(): void {
    this.contractsResource.reload();
    this.summaryResource.reload();
    this.pmsResource.reload();
    this.meetingsResource.reload();
  }

  setFilter<K extends keyof Filters>(key: K, value: Filters[K]): void {
    this.filters.update(f => ({ ...f, [key]: value }));
  }

  resetFilters(): void {
    this.filters.set({ ...DEFAULT_FILTERS });
  }

  private buildParams(f: Filters): Record<string, string> {
    return {
      pm: f.pm, customer: f.customer, region: f.region,
      month: f.month, health: f.health, sentiment: f.sentiment,
    };
  }

  // ============ Static helpers used by templates ============
  static readonly statusScore = statusScore;
  static readonly statusRank = statusRank;
  static readonly ALL_KPIS = ALL_KPIS;
}