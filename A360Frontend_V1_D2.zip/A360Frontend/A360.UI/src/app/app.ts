import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Topbar } from './core/layout/topbar/topbar';
import { Footer } from './core/layout/footer/footer';
import { FlashToast } from './components/flash-toast/flash-toast';
import { MeetingWizard } from './components/meeting-wizard/meeting-wizard';
import { StateService } from './core/services/state';

@Component({
  selector: 'app-root',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, Topbar, Footer, FlashToast, MeetingWizard, Topbar],
  templateUrl: './app.html',
})
export class App {
  private readonly state = inject(StateService);

  constructor() {
    this.state.reload();
  }
}