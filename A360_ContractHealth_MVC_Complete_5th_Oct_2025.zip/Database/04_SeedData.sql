USE A360_ContractHealth; GO
IF NOT EXISTS(SELECT 1 FROM PerformanceManagers) BEGIN INSERT PerformanceManagers(Name,Region,Email) VALUES('Anita Sharma','EMEA','anita@example.com'),('Rahul Patil','AMER','rahul@example.com'),('Priya Nair','APJ','priya@example.com'); END
-- For the full 100-record demo dataset, run the application once. DbInitializer creates 100 contracts and KPI definitions.
GO