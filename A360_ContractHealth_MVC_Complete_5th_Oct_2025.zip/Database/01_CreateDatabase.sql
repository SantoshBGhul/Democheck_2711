IF DB_ID(N'A360_ContractHealth') IS NULL CREATE DATABASE A360_ContractHealth;
GO
USE A360_ContractHealth;
GO
-- The application uses EF Core EnsureCreated for first-run setup. This script only creates the database.
