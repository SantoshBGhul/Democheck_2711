# A360 Contract Health – ASP.NET Core MVC + SQL Server

## Stack
- ASP.NET Core 8 MVC
- Razor Views (MVC Views; not Razor Pages)
- Entity Framework Core 8 + SQL Server
- Layered architecture: Domain → Application → Infrastructure → Web
- REST-style JSON endpoints under `/api`

## Run
1. Install .NET 8 SDK and SQL Server LocalDB (Visual Studio includes LocalDB).
2. Open `A360.ContractHealth.sln` in Visual Studio 2022.
3. Set `A360.ContractHealth.Web` as startup project.
4. Run with HTTPS.
5. On first run the app creates `A360_ContractHealth` in `(localdb)\MSSQLLocalDB`, creates tables, KPI definitions and 100 demo contracts.

## SQL Server
The default connection is in `src/A360.ContractHealth.Web/appsettings.json`. For full SQL Server change it to e.g. `Server=YOURSERVER;Database=A360_ContractHealth;Trusted_Connection=True;TrustServerCertificate=True;`.

Scripts are in `Database/`: database creation, schema, stored procedures and seed notes. The application initializer is intentionally used for a zero-setup demo.

## Main routes
- `/` or `/Dashboard` – dashboard
- `/Meetings` – meeting history
- `/Meetings/Create` – four-section meeting entry
- `/Actions` – action tracker
- `/Contracts` – master data
- `/api/dashboard`, `/api/contracts`, `/api/meetings`, `/api/actions`
- `POST /api/meetings` – persist a meeting and update health

## Architecture
`Domain` contains entities only. `Application` contains DTOs/contracts. `Infrastructure` contains EF Core, database initialization and service implementation. `Web` contains MVC controllers, Razor Views and static assets.

## Important delete behavior
Foreign keys use `Restrict` / `NoAction` where required to avoid SQL Server's “multiple cascade paths” error. Meeting KPI rows cascade only from Meeting to MeetingKpi.

## Production next steps
Add authentication/authorization, audit user identity, migrations, centralized exception handling, structured logging, validation, configurable health weights, paging, and automated tests before production.
