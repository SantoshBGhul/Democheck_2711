# A360 Contract Health – Architecture

Browser → MVC Controller → Application Interface → Infrastructure Service → EF Core DbContext → SQL Server

### Data flow when saving a meeting
1. Razor form posts `MeetingRequest` to `MeetingsController.Create`.
2. `IContractHealthService.SaveMeetingAsync` creates Meeting.
3. KPI selections are stored in `MeetingKpis`.
4. A health score is calculated from selected statuses.
5. Contract master is updated with score, health, rating, sentiment and risk.
6. `HealthAssessments` stores an auditable snapshot.
7. `ActionItems` stores the follow-up when an action was entered.
8. Dashboard reads current contract state from SQL.

### Health score in this starter implementation
Green=100, Yellow=75, Orange=50, Red=25. Overall health: >=80 Green, >=60 Yellow, >30 Orange, >0 Red, otherwise Blank. These weights are configurable business rules and should be confirmed before production.
