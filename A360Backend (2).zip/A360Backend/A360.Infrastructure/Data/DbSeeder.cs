﻿using A360.Domain.Entities;
using A360.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace A360.Infrastructure.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(A360DbContext db, CancellationToken ct = default)
    {
        await db.Database.MigrateAsync(ct);
        if (await db.Contracts.CountAsync(ct) > 50) return;

        var rnd = new Random(42);

        // 1. SEED PERFORMANCE MANAGERS
        var pmNames = new[] { "Marcel Tiemann", "Anju Chhabra", "Tanvi Bachal", "Sebastien", "Sudha", "Ridhwaan", "Jane Doe", "John Smith" };
        var regions = new[] { "EMEA", "AMER", "APJ" };

        var existingPms = await db.PerformanceManagers.Select(p => p.Name).ToListAsync(ct);
        var newPms = pmNames.Where(name => !existingPms.Contains(name)).Select(name => new PerformanceManager
        {
            Name = name,
            Region = regions[rnd.Next(regions.Length)],
            Email = $"{name.Replace(" ", "").ToLower()}@honeywell.com"
        }).ToList();

        if (newPms.Any())
        {
            db.PerformanceManagers.AddRange(newPms);
            await db.SaveChangesAsync(ct);
        }
        var allPms = await db.PerformanceManagers.ToListAsync(ct);

        // 2. SEED 200 CONTRACTS
        var prefixes = new[] { "Global", "United", "Northern", "Southern", "Eastern", "Western", "Advanced", "Prime", "Apex", "Titan" };
        var suffixes = new[] { "Energy", "Refining", "Chemicals", "Utilities", "Gas", "Petroleum", "Solutions", "Dynamics", "Logistics", "Mining" };
        var contracts = new List<Contract>();

        for (int i = 1; i <= 200; i++)
        {
            var pm = allPms[rnd.Next(allPms.Count)];
            var customer = $"{prefixes[rnd.Next(prefixes.Length)]} {suffixes[rnd.Next(suffixes.Length)]} {i}";
            if (await db.Contracts.AnyAsync(c => c.Customer == customer, ct) || contracts.Any(c => c.Customer == customer))
                customer = $"{customer} Group";

            var sentiment = (Sentiment)rnd.Next(1, 4); // Pos, Neu, Neg
            var value = Math.Round((decimal)(rnd.NextDouble() * 20 + 1), 1);
            var riskValue = Math.Round(value * (decimal)(rnd.NextDouble() * 0.2), 2);

            // Determine target health for the whole contract (60% chance of being mostly Green)
            var mainHealthChance = rnd.NextDouble();
            var baseHealth = mainHealthChance switch
            {
                < 0.60 => HealthStatus.Green,
                < 0.85 => HealthStatus.Yellow,
                < 0.95 => HealthStatus.Orange,
                _ => HealthStatus.Red
            };

            // Helper to vary the status slightly around the base health
            HealthStatus VaryHealth()
            {
                if (baseHealth == HealthStatus.Green) return rnd.NextDouble() > 0.1 ? HealthStatus.Green : HealthStatus.Yellow;
                if (baseHealth == HealthStatus.Yellow) return rnd.NextDouble() > 0.3 ? HealthStatus.Yellow : (rnd.NextDouble() > 0.5 ? HealthStatus.Green : HealthStatus.Orange);
                if (baseHealth == HealthStatus.Orange) return rnd.NextDouble() > 0.3 ? HealthStatus.Orange : (rnd.NextDouble() > 0.5 ? HealthStatus.Yellow : HealthStatus.Red);
                return rnd.NextDouble() > 0.2 ? HealthStatus.Red : HealthStatus.Orange;
            }

            var contract = new Contract
            {
                Customer = customer,
                PmName = pm.Name,
                PerformanceManagerId = pm.Id,
                Region = pm.Region,
                Value = value,
                RiskValue = riskValue,
                Sentiment = sentiment,
                LastMeetingDate = DateTime.UtcNow.AddDays(-rnd.Next(1, 60)),

                // Apply the varied health to all KPIs
                OutcomeKpi = VaryHealth(),
                TopCustomerPriority = VaryHealth(),
                Next90DayRisk = VaryHealth(),
                PfmAction = VaryHealth(),
                ManagementSupport = VaryHealth(),
                MarginChecked = VaryHealth(),
                BillingForecastUpdated = VaryHealth(),
                PastDues = VaryHealth(),
                SespBgpCostsChecked = VaryHealth(),
                RenewalOnTime = VaryHealth(),
                Tracker2026 = VaryHealth(),
                Tracker2027 = VaryHealth(),
                IdpCompleted = VaryHealth(),
                HpdResultsUpdated = VaryHealth(),
                SiopCompleted = VaryHealth(),
                SfdcTasksClosed = VaryHealth(),
                ReportingStandard = VaryHealth(),
                CustomerMeetingsPlanned = VaryHealth(),
                DigitalPrimeDashboard = VaryHealth(),
                ContractSetupCorrect = VaryHealth(),
                A360OpsDashboard = VaryHealth(),
                NpsShared = VaryHealth(),
                MosCompleted = VaryHealth(),

                // Dimensions
                DeliveryHealth = VaryHealth(),
                FinancialHealth = VaryHealth(),
                RiskHealth = VaryHealth(),
                RenewalHealth = VaryHealth(),

                // Seed some dummy text so it's not all NULL
                ValueDelivered = i % 2 == 0 ? "Improved operational efficiency by 15%." : null,
                Concern = i % 3 == 0 ? "Delayed response on critical support tickets." : null,
                CommentCustomer = i % 4 == 0 ? "Customer is generally happy but wants faster reporting." : null
            };
            contracts.Add(contract);
        }

        db.Contracts.AddRange(contracts);
        await db.SaveChangesAsync(ct);

        // 3. SEED HISTORY
        string[] months = ["Apr-26", "May-26", "Jun-26", "Jul-26", "Aug-26", "Sep-26"];
        var histories = new List<ContractHistory>();
        foreach (var c in contracts)
        {
            for (int i = 0; i < months.Length; i++)
            {
                histories.Add(new ContractHistory
                {
                    ContractId = c.Id,
                    Month = months[i],
                    Overall = i == months.Length - 1 ? c.OverallHealth() : RandomHealth(rnd)
                });
            }
        }
        db.ContractHistories.AddRange(histories);
        await db.SaveChangesAsync(ct);

        // 4. SEED MEETINGS
        var actions = new[] { "Review quarterly report", "Schedule maintenance", "Address billing issue", "Conduct safety audit" };
        var owners = new[] { "Marcel Tiemann", "Anju Chhabra", "Tanvi Bachal", "Ridhwaan", "Unassigned" };
        var meetings = new List<Meeting>();

        for (int i = 0; i < 80; i++)
        {
            var contract = contracts[rnd.Next(contracts.Count)];
            var isAction = rnd.NextDouble() > 0.2;

            meetings.Add(new Meeting
            {
                ContractId = contract.Id,
                Customer = contract.Customer,
                PmName = contract.PmName,
                MeetingDate = DateTime.UtcNow.AddDays(-rnd.Next(1, 90)),
                MeetingType = "Monthly 1:1",
                Sentiment = contract.Sentiment,
                ValueDelivered = contract.ValueDelivered,
                Concern = contract.Concern,
                Next90DayRisk = contract.Next90DayRisk,
                Action = isAction ? actions[rnd.Next(actions.Length)] : null,
                Owner = isAction ? owners[rnd.Next(owners.Length)] : null,
                Due = isAction ? DateTime.UtcNow.AddDays(rnd.Next(-10, 30)) : null,
                ActionStatus = isAction ? (ActionStatus)rnd.Next(0, 3) : ActionStatus.Completed,
                Source = "Meeting workspace"
            });
        }
        db.Meetings.AddRange(meetings);
        await db.SaveChangesAsync(ct);
    }

    // Weighted Health Status: 70% Green, 20% Yellow, 8% Orange, 2% Red
    private static HealthStatus RandomHealth(Random rnd)
    {
        var chance = rnd.NextDouble();
        return chance switch
        {
            < 0.70 => HealthStatus.Green,
            < 0.90 => HealthStatus.Yellow,
            < 0.98 => HealthStatus.Orange,
            _ => HealthStatus.Red
        };
    }
}