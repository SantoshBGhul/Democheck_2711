﻿using A360.Application.Common;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace A360.API.Middleware;

public sealed class GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext ctx, Exception ex, CancellationToken ct)
    {
        // This uses the built-in ILogger, which is automatically routed to Serilog
        logger.LogError(ex, "Server Error occurred for {Path}", ctx.Request.Path);

        var (status, code) = ex switch
        {
            NotFoundException => (StatusCodes.Status404NotFound, "NOT_FOUND"),
            ConflictException => (StatusCodes.Status409Conflict, "CONFLICT"),
            ValidationAppException => (StatusCodes.Status400BadRequest, "VALIDATION_ERROR"),
            ArgumentException => (StatusCodes.Status400BadRequest, "INVALID_ARGUMENT"),
            BadHttpRequestException => (StatusCodes.Status400BadRequest, "BAD_REQUEST"),
            InvalidOperationException => (StatusCodes.Status409Conflict, "INVALID_OPERATION"),
            KeyNotFoundException => (StatusCodes.Status404NotFound, "NOT_FOUND"),
            _ => (StatusCodes.Status500InternalServerError, "INTERNAL_ERROR")
        };

        var problem = new ProblemDetails
        {
            Status = status,
            Title = code,
            Detail = ex.Message,
            Instance = ctx.Request.Path
        };
        problem.Extensions["traceId"] = ctx.TraceIdentifier;

        ctx.Response.StatusCode = status;
        await ctx.Response.WriteAsJsonAsync(problem, ct);
        return true;
    }
}