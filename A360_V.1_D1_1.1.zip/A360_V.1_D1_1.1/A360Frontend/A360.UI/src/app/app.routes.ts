import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'meetings', pathMatch: 'full' },
  
  {
    path: 'meetings',
    loadComponent: () => import('./pages/meetings/meetings').then(m => m.Meetings),
    title: 'A360 · Meetings',
  },



  {
    path: 'admin',
    loadComponent: () => import('./pages/admin/admin').then(m => m.Admin),
    title: 'A360 · Admin',
  },
 
  { path: '**', redirectTo: 'meetings' },
];
