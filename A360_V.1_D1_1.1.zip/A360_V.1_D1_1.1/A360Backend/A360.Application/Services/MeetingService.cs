﻿using System.Text.Json;
using A360.Application.Common;
using A360.Application.DTOs;
using A360.Application.Interfaces;
using A360.Domain.Entities;
using A360.Domain.Enums;
using A360.Domain.Interfaces;

namespace A360.Application.Services;

public sealed class MeetingService(IRepository<Meeting> meetings, IRepository<Contract> contracts) : IMeetingService
{
    public async Task<PagedResult<MeetingListDto>> GetPagedAsync(int page, int pageSize, string? customer, CancellationToken ct = default)
    {
        var paged = await meetings.PagedAsync(page, pageSize,
            m => string.IsNullOrWhiteSpace(customer) || customer == "All" || m.Customer == customer,
            q => q.OrderByDescending(m => m.MeetingDate), ct);

        var dtos = paged.Items.Select(MapToDto).ToList();
        return new PagedResult<MeetingListDto>(dtos, paged.Total, paged.Page, paged.PageSize);
    }

    public async Task<MeetingListDto> CreateAsync(CreateMeetingDto dto, CancellationToken ct = default)
    {
        var contract = await contracts.GetByIdAsync(dto.ContractId, ct)
            ?? throw new NotFoundException($"Contract {dto.ContractId} not found.");

        if (string.IsNullOrWhiteSpace(dto.PmName))
            throw new ValidationAppException("Performance Manager is required.");

        // UPSERT LOGIC: Look for an existing meeting for this contract in the same month
        var existingMeetings = await meetings.ListAsync(m =>
            m.ContractId == dto.ContractId &&
            m.MeetingDate.Year == dto.MeetingDate.Year &&
            m.MeetingDate.Month == dto.MeetingDate.Month, ct);

        var meeting = existingMeetings.FirstOrDefault();

        if (meeting != null)
        {
            // UPDATE EXISTING
            meeting.PmName = dto.PmName;
            meeting.MeetingDate = dto.MeetingDate;
            meeting.MeetingType = dto.MeetingType;
            meeting.Sentiment = HealthMapper.ParseSentiment(dto.Sentiment);
            meeting.ValueDelivered = dto.ValueDelivered;
            meeting.Concern = dto.Concern;
            meeting.CustomerAction = dto.CustomerAction;
            meeting.PfmAction = dto.PfmAction;
            meeting.ManagementSupport = dto.ManagementSupport;
            meeting.Next90DayRisk = HealthMapper.Parse(dto.Next90DayRisk);

            meeting.Owner = dto.Owner;
            meeting.Due = dto.Due;
            meeting.Action = dto.Action;

            // If previously completed and a new action is added, reopen it
            if (meeting.ActionStatus == ActionStatus.Completed && !string.IsNullOrWhiteSpace(dto.Action))
                meeting.ActionStatus = ActionStatus.Open;

            meeting.UpdatedAt = DateTime.UtcNow;
            meetings.Update(meeting);
        }
        else
        {
            // CREATE NEW
            meeting = new Meeting
            {
                ContractId = dto.ContractId,
                Customer = contract.Customer,
                PmName = dto.PmName,
                MeetingDate = dto.MeetingDate == default ? DateTime.UtcNow : dto.MeetingDate,
                MeetingType = dto.MeetingType,
                Sentiment = HealthMapper.ParseSentiment(dto.Sentiment),
                ValueDelivered = dto.ValueDelivered,
                Concern = dto.Concern,
                CustomerAction = dto.CustomerAction,
                PfmAction = dto.PfmAction,
                ManagementSupport = dto.ManagementSupport,
                Next90DayRisk = HealthMapper.Parse(dto.Next90DayRisk),
                Owner = dto.Owner,
                Due = dto.Due,
                Action = dto.Action,
                ActionStatus = ActionStatus.Open,
                Source = "Meeting workspace"
            };
            await meetings.AddAsync(meeting, ct);
        }

        // Update contract
        contract.PmName = dto.PmName;
        contract.Sentiment = meeting.Sentiment;
        contract.LastMeetingDate = meeting.MeetingDate;
        contract.ValueDelivered = dto.ValueDelivered;
        contract.Concern = dto.Concern;
        contract.CustomerAction = dto.CustomerAction;
        contract.PfmActionText = dto.PfmAction;
        contract.ManagementSupportText = dto.ManagementSupport;
        contract.Next90DayRisk = meeting.Next90DayRisk;

        if (dto.HealthSnapshot is { Count: > 0 })
        {
            foreach (var kv in dto.HealthSnapshot)
                HealthMapper.ApplyKpi(contract, kv.Key, kv.Value);
            meeting.HealthSnapshotJson = JsonSerializer.Serialize(dto.HealthSnapshot);
        }

        if (dto.GroupComments is { Count: > 0 })
        {
            contract.CommentCustomer = dto.GroupComments.GetValueOrDefault("customer");
            contract.CommentFinancial = dto.GroupComments.GetValueOrDefault("financial");
            contract.CommentGrowth = dto.GroupComments.GetValueOrDefault("growth");
            contract.CommentPeople = dto.GroupComments.GetValueOrDefault("people");
            contract.CommentInternal = dto.GroupComments.GetValueOrDefault("internal");
            meeting.GroupCommentsJson = JsonSerializer.Serialize(dto.GroupComments);
        }

        contract.UpdatedAt = DateTime.UtcNow;
        contracts.Update(contract);
        await meetings.SaveChangesAsync(ct);

        return MapToDto(meeting);
    }

    public async Task UpdateActionStatusAsync(int id, UpdateActionStatusDto dto, CancellationToken ct = default)
    {
        var m = await meetings.GetByIdAsync(id, ct)
            ?? throw new NotFoundException($"Meeting {id} not found.");

        var normalized = dto.Status.Replace(" ", "", StringComparison.OrdinalIgnoreCase);
        if (!Enum.TryParse<ActionStatus>(normalized, true, out var st))
            throw new ValidationAppException($"Invalid action status '{dto.Status}'.");

        m.ActionStatus = st;
        m.UpdatedAt = DateTime.UtcNow;
        meetings.Update(m);
        await meetings.SaveChangesAsync(ct);
    }

    public async Task DeleteActionAsync(int id, CancellationToken ct = default)
    {
        var m = await meetings.GetByIdAsync(id, ct)
            ?? throw new NotFoundException($"Meeting {id} not found.");

        // HARD DELETE the meeting record from the database.
        // This removes it from the Action Tracker and the UI permanently.
        meetings.Remove(m);
        await meetings.SaveChangesAsync(ct);
    }

    private static MeetingListDto MapToDto(Meeting m) => new(
        m.Id, m.ContractId, m.Customer, m.PmName, m.MeetingDate, m.MeetingType,
        HealthMapper.ToString(m.Sentiment), m.Action ?? "", m.Owner ?? "",
        m.Due, m.ActionStatus.ToString(), m.Source, m.UpdatedAt);
}