﻿using A360.Application.Common;
using A360.Application.DTOs;
using A360.Application.Interfaces;
using A360.Domain.Entities;
using A360.Domain.Enums;
using A360.Domain.Interfaces;
using Microsoft.Extensions.Logging;

namespace A360.Application.Services;

public sealed class DashboardService(IRepository<Contract> repo, ILogger<DashboardService>? logger = null) : IDashboardService
{
    private readonly ILogger<DashboardService>? _logger = logger;
    public async Task<DashboardSummaryDto> GetSummaryAsync(string? pm, string? customer, string? region,
        string? month, string? health, string? sentiment, CancellationToken ct = default)
    {
        try
        {
            var sent = string.IsNullOrWhiteSpace(sentiment) || sentiment == "All"
                ? (Sentiment?)null
                : HealthMapper.ParseSentiment(sentiment);

            // Build predicate with health filter included at database level
            var all = await repo.ListAsync(c =>
                (string.IsNullOrWhiteSpace(pm) || pm == "All" || c.PmName == pm) &&
                (string.IsNullOrWhiteSpace(customer) || customer == "All" || c.Customer == customer) &&
                (string.IsNullOrWhiteSpace(region) || region == "All" || c.Region == region) &&
                (sent == null || c.Sentiment == sent), ct);

            var data = all.ToList();

            // Apply in-memory health filter after fetching from database
            if (!string.IsNullOrWhiteSpace(health) && health != "All")
                data = data.Where(c => c.OverallHealth().ToString() == health).ToList();

            var total = Math.Max(1, data.Count);
            var score = ComputeScore(data);
            var positive = data.Count(c => c.Sentiment == Sentiment.Positive);

            return new DashboardSummaryDto(
                Score: score,
                State: score >= 80 ? "Healthy" : score >= 65 ? "Watch" : score >= 45 ? "Attention" : "Critical",
                Total: data.Count,
                Green: data.Count(c => c.OverallHealth() == HealthStatus.Green),
                Yellow: data.Count(c => c.OverallHealth() == HealthStatus.Yellow),
                Orange: data.Count(c => c.OverallHealth() == HealthStatus.Orange),
                Red: data.Count(c => c.OverallHealth() == HealthStatus.Red),
                ContractValue: data.Sum(c => c.Value),
                RiskValue: data.Sum(c => c.RiskValue),
                PositivePct: (int)Math.Round(positive / (double)total * 100));
        }
        catch (OperationCanceledException ex)
        {
            _logger?.LogWarning(ex, "Dashboard query was canceled. Filters: pm={pm}, customer={customer}, region={region}, health={health}, sentiment={sentiment}",
                pm, customer, region, health, sentiment);
            throw;
        }
        catch (Exception ex)
        {
            _logger?.LogError(ex, "Error retrieving dashboard summary. Filters: pm={pm}, customer={customer}", pm, customer);
            throw;
        }
    }

    private static int ComputeScore(List<Contract> data)
    {
        if (data.Count == 0) return 0;
        double sum = 0;
        int counted = 0;

        foreach (var c in data)
        {
            var vals = GetHealthValues(c).Where(v => v != HealthStatus.Blank).ToArray();
            if (vals.Length == 0) continue;
            sum += vals.Average(HealthMapper.StatusScore);
            counted++;
        }
        return counted == 0 ? 0 : (int)Math.Round(sum / counted);
    }

    private static IEnumerable<HealthStatus> GetHealthValues(Contract c) =>
    [
        c.OutcomeKpi, c.TopCustomerPriority, c.Next90DayRisk, c.PfmAction, c.ManagementSupport,
        c.MarginChecked, c.BillingForecastUpdated, c.PastDues, c.SespBgpCostsChecked,
        c.RenewalOnTime, c.Tracker2026, c.Tracker2027,
        c.IdpCompleted, c.HpdResultsUpdated, c.SiopCompleted,
        c.SfdcTasksClosed, c.ReportingStandard, c.CustomerMeetingsPlanned,
        c.DigitalPrimeDashboard, c.ContractSetupCorrect, c.A360OpsDashboard,
        c.NpsShared, c.MosCompleted,
        c.DeliveryHealth, c.FinancialHealth, c.RiskHealth, c.RenewalHealth
    ];
}