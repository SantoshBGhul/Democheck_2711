﻿using System.Linq.Expressions;
using A360.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace A360.Infrastructure.Data;

public class Repository<T>(A360DbContext db) : IRepository<T> where T : class
{
    protected readonly A360DbContext Db = db;
    protected readonly DbSet<T> Set = db.Set<T>();

    public Task<T?> GetByIdAsync(object id, CancellationToken ct = default)
        => Set.FindAsync([id], ct).AsTask();

    public async Task<IReadOnlyList<T>> ListAsync(Expression<Func<T, bool>>? predicate = null, CancellationToken ct = default)
    {
        IQueryable<T> q = Set.AsNoTracking();
        if (predicate is not null) q = q.Where(predicate);
        return await q.ToListAsync(ct);
    }

    public async Task<PagedResult<T>> PagedAsync(int page, int pageSize,
        Expression<Func<T, bool>>? predicate = null,
        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
        CancellationToken ct = default)
    {
        try
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, 200);

            IQueryable<T> q = Set.AsNoTracking();
            if (predicate is not null) q = q.Where(predicate);

            var total = await q.CountAsync(ct);
            if (orderBy is not null) q = orderBy(q);

            var items = await q.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
            return new PagedResult<T>(items, total, page, pageSize);
        }
        catch (OperationCanceledException)
        {
            // Re-throw cancellation exceptions to allow proper handling at the caller level
            throw;
        }
    }

    public async Task<T> AddAsync(T entity, CancellationToken ct = default)
    {
        await Set.AddAsync(entity, ct);
        return entity;
    }

    public void Update(T entity) => Set.Update(entity);
    public void Remove(T entity) => Set.Remove(entity);
    public Task<int> SaveChangesAsync(CancellationToken ct = default) => Db.SaveChangesAsync(ct);
}