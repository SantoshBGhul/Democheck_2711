﻿//using A360.Application.DTOs;
//using A360.Application.Interfaces;

//namespace A360.API.Endpoints;

//public static class MeetingEndpoints
//{
//    public static RouteGroupBuilder MapMeetingEndpoints(this RouteGroupBuilder api)
//    {
//        var group = api.MapGroup("/meetings").WithTags("Meetings");

//        group.MapGet("/", async (IMeetingService svc,
//            int page = 1, int pageSize = 50, string? customer = null,
//            CancellationToken ct = default) =>
//        {
//            page = Math.Max(1, page);
//            pageSize = Math.Clamp(pageSize, 1, 200);
//            return Results.Ok(await svc.GetPagedAsync(page, pageSize, customer, ct));
//        });

//        group.MapPost("/", async (CreateMeetingDto dto, IMeetingService svc, CancellationToken ct) =>
//        {
//            var created = await svc.CreateAsync(dto, ct);
//            return Results.Created($"/api/a360/meetings/{created.Id}", created);
//        })
//        .Produces<MeetingListDto>(StatusCodes.Status201Created)
//        .Produces(StatusCodes.Status400BadRequest)
//        .Produces(StatusCodes.Status404NotFound);

//        return group;
//    }

//    public static RouteGroupBuilder MapActionEndpoints(this RouteGroupBuilder api)
//    {
//        var group = api.MapGroup("/actions").WithTags("Actions");

//        group.MapPatch("/{id:int}", async (int id, UpdateActionStatusDto dto,
//            IMeetingService svc, CancellationToken ct) =>
//        {
//            await svc.UpdateActionStatusAsync(id, dto, ct);
//            return Results.Ok(new { ok = true });
//        })
//        .Produces(StatusCodes.Status200OK)
//        .Produces(StatusCodes.Status400BadRequest)
//        .Produces(StatusCodes.Status404NotFound);

//        group.MapDelete("/{id:int}", async (int id, IMeetingService svc, CancellationToken ct) =>
//        {
//            await svc.DeleteActionAsync(id, ct);
//            return Results.NoContent();
//        });

//        return group;
//    }
//}


using A360.Application.DTOs;
using A360.Application.Interfaces;
using System.ComponentModel.DataAnnotations;

namespace A360.API.Endpoints;

public static class MeetingEndpoints
{
    public static RouteGroupBuilder MapMeetingEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/meetings").WithTags("Meetings");

        group.MapGet("/", async (IMeetingService svc, int page = 1, int pageSize = 50, string? customer = null, CancellationToken ct = default) =>
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, 200);
            return Results.Ok(await svc.GetPagedAsync(page, pageSize, customer, ct));
        });

        group.MapPost("/", async (CreateMeetingDto dto, IMeetingService svc, CancellationToken ct) =>
        {
            // 1. Data Annotations Validation
            var validationContext = new ValidationContext(dto);
            var validationResults = new List<ValidationResult>();
            if (!Validator.TryValidateObject(dto, validationContext, validationResults, true))
            {
                var errors = validationResults.ToDictionary(
                    r => r.MemberNames.FirstOrDefault() ?? "general",
                    r => new[] { r.ErrorMessage ?? "Invalid" }
                );
                return Results.ValidationProblem(errors);
            }

            // 2. Business Logic Validation
            if (dto.MeetingDate > DateTime.UtcNow.AddDays(1))
                return Results.BadRequest(new { error = "Meeting date cannot be in the future." });

            if (dto.Sentiment == "Blank" && string.IsNullOrWhiteSpace(dto.Concern))
                return Results.BadRequest(new { error = "You must provide a Concern if sentiment is not assessed." });

            // 3. Save to Database
            var created = await svc.CreateAsync(dto, ct);
            return Results.Created($"/api/a360/meetings/{created.Id}", created);
        })
        .Produces<MeetingListDto>(StatusCodes.Status201Created)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status404NotFound);

        return group;
    }

    public static RouteGroupBuilder MapActionEndpoints(this RouteGroupBuilder api)
    {
        var group = api.MapGroup("/actions").WithTags("Actions");

        group.MapPatch("/{id:int}", async (int id, UpdateActionStatusDto dto,
            IMeetingService svc, CancellationToken ct) =>
        {
            await svc.UpdateActionStatusAsync(id, dto, ct);
            return Results.Ok(new { ok = true });
        })
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status404NotFound);

        group.MapDelete("/{id:int}", async (int id, IMeetingService svc, CancellationToken ct) =>
        {
            await svc.DeleteActionAsync(id, ct);
            return Results.NoContent();
        });

        return group;
    }
}
