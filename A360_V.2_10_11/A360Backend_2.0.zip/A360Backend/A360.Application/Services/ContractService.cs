﻿using A360.Application.Common;
using A360.Application.DTOs;
using A360.Application.Interfaces;
using A360.Domain.Entities;
using A360.Domain.Enums;
using A360.Domain.Interfaces;

namespace A360.Application.Services;

public sealed class ContractService(
    IRepository<Contract> repo,
    IRepository<PerformanceManager> pms) : IContractService
{
    public async Task<PagedResult<ContractListDto>> GetPagedAsync(int page, int pageSize,
        string? pm, string? customer, string? region, string? month,
        string? health, string? sentiment, CancellationToken ct = default)
    {
        var predicate = BuildPredicate(pm, customer, region, month, sentiment);
        var all = await repo.ListAsync(predicate, ct);
        var dtos = FilterByHealth(all.OrderBy(c => c.Customer).Select(MapToDto).ToList(), health);
        var total = dtos.Count;
        var items = pageSize > 0 ? dtos.Skip((page - 1) * pageSize).Take(pageSize).ToList() : dtos;
        return new PagedResult<ContractListDto>(items, total, page, pageSize > 0 ? pageSize : total);
    }

    public async Task<IReadOnlyList<ContractListDto>> GetFilteredAsync(
        string? pm, string? customer, string? region, string? month,
        string? health, string? sentiment, CancellationToken ct = default)
    {
        var all = await repo.ListAsync(BuildPredicate(pm, customer, region, month, sentiment), ct);
        var dtos = all.Select(MapToDto).ToList();
        return FilterByHealth(dtos, health);
    }

    public async Task<ContractListDto?> GetByIdAsync(int id, CancellationToken ct = default)
    {
        var c = await repo.GetByIdAsync(id, ct);
        return c is null ? null : MapToDto(c);
    }

    public async Task<ContractListDto> CreateAsync(CreateContractDto dto, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(dto.Customer)) throw new ValidationAppException("Customer name is required.");
        if (dto.Value < 0) throw new ValidationAppException("Contract value cannot be negative.");
        if (string.IsNullOrWhiteSpace(dto.PmName)) throw new ValidationAppException("Performance Manager is required.");

        var existing = await repo.ListAsync(c => c.Customer == dto.Customer.Trim(), ct);
        if (existing.Count > 0) throw new ConflictException($"Contract '{dto.Customer}' already exists.");

        var pmName = dto.PmName.Trim();
        var existingPm = (await pms.ListAsync(p => p.Name.ToLower() == pmName.ToLower(), ct)).FirstOrDefault();
        if (existingPm == null)
        {
            existingPm = new PerformanceManager { Name = pmName, Region = dto.Region };
            await pms.AddAsync(existingPm, ct);
            await pms.SaveChangesAsync(ct);
        }

        var entity = new Contract
        {
            Customer = dto.Customer.Trim(),
            PmName = existingPm.Name,
            PerformanceManagerId = existingPm.Id,
            Region = dto.Region,
            Value = dto.Value,
            LastMeetingDate = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
        await repo.AddAsync(entity, ct);
        await repo.SaveChangesAsync(ct);
        return MapToDto(entity);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct = default)
    {
        var c = await repo.GetByIdAsync(id, ct);
        if (c is null) return false;
        repo.Remove(c);
        await repo.SaveChangesAsync(ct);
        return true;
    }

    public async Task UpdateKpiAsync(UpdateKpiDto dto, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(dto.Key)) throw new ValidationAppException("KPI key is required.");
        var c = await repo.GetByIdAsync(dto.ContractId, ct)
            ?? throw new NotFoundException($"Contract {dto.ContractId} not found.");

        HealthMapper.ApplyKpi(c, dto.Key, dto.Value);
        c.UpdatedAt = DateTime.UtcNow;
        c.LastMeetingDate = DateTime.UtcNow;
        repo.Update(c);
        await repo.SaveChangesAsync(ct);
    }

    private static System.Linq.Expressions.Expression<Func<Contract, bool>> BuildPredicate(
        string? pm, string? customer, string? region, string? month, string? sentiment)
    {
        var sent = string.IsNullOrWhiteSpace(sentiment) || sentiment == "All"
            ? (Sentiment?)null
            : HealthMapper.ParseSentiment(sentiment);
        var monthStart = ParseMonth(month);
        var monthEnd = monthStart?.AddMonths(1);

        return c =>
            (string.IsNullOrWhiteSpace(pm) || pm == "All" || c.PmName == pm) &&
            (string.IsNullOrWhiteSpace(customer) || customer == "All" || c.Customer == customer) &&
            (string.IsNullOrWhiteSpace(region) || region == "All" || c.Region == region) &&
            (monthStart == null || (c.LastMeetingDate >= monthStart && c.LastMeetingDate < monthEnd)) &&
            (sent == null || c.Sentiment == sent);
    }

    internal static DateTime? ParseMonth(string? month)
    {
        if (string.IsNullOrWhiteSpace(month) || month == "All") return null;
        if (DateTime.TryParseExact(month, "yyyy-MM", System.Globalization.CultureInfo.InvariantCulture,
            System.Globalization.DateTimeStyles.None, out var date)) return date;
        throw new ValidationAppException("Month must be in yyyy-MM format.");
    }

    private static List<ContractListDto> FilterByHealth(List<ContractListDto> dtos, string? health)
        => string.IsNullOrWhiteSpace(health) || health == "All"
            ? dtos
            : dtos.Where(d => d.OverallHealth == health).ToList();

    private static ContractListDto MapToDto(Contract c) => new(
        c.Id, c.Customer, c.PmName, c.Region, c.Value, c.RiskValue,
        HealthMapper.ToString(c.Sentiment), c.LastMeetingDate,
        c.OverallHealth().ToString(),
        c.ValueDelivered ?? "", c.Concern ?? "", c.CustomerAction ?? "",
        c.PfmActionText ?? "", c.ManagementSupportText ?? "",

        // MAP THE NEW FIELDS TO THE FRONTEND
        c.ServiceScore, c.ServiceCoverage, c.ServiceHealth,
        c.CsatScore, c.NpsScore,
        c.PipelineValue, c.BookedMarginPct, c.GrossMarginPct,
        c.PreventiveHrs, c.CyberHrs, c.TrainingHrs, c.BgpPlusHrs,

        HealthMapper.ToString(c.OutcomeKpi), HealthMapper.ToString(c.TopCustomerPriority),
        HealthMapper.ToString(c.Next90DayRisk), HealthMapper.ToString(c.PfmAction),
        HealthMapper.ToString(c.ManagementSupport),
        HealthMapper.ToString(c.MarginChecked), HealthMapper.ToString(c.BillingForecastUpdated),
        HealthMapper.ToString(c.PastDues), HealthMapper.ToString(c.SespBgpCostsChecked),
        HealthMapper.ToString(c.RenewalOnTime), HealthMapper.ToString(c.Tracker2026),
        HealthMapper.ToString(c.Tracker2027),
        HealthMapper.ToString(c.IdpCompleted), HealthMapper.ToString(c.HpdResultsUpdated),
        HealthMapper.ToString(c.SiopCompleted),
        HealthMapper.ToString(c.SfdcTasksClosed), HealthMapper.ToString(c.ReportingStandard),
        HealthMapper.ToString(c.CustomerMeetingsPlanned), HealthMapper.ToString(c.DigitalPrimeDashboard),
        HealthMapper.ToString(c.ContractSetupCorrect), HealthMapper.ToString(c.A360OpsDashboard),
        HealthMapper.ToString(c.NpsShared), HealthMapper.ToString(c.MosCompleted),
        HealthMapper.ToString(c.DeliveryHealth), HealthMapper.ToString(c.FinancialHealth),
        HealthMapper.ToString(c.RiskHealth), HealthMapper.ToString(c.RenewalHealth),
        c.CommentCustomer ?? "", c.CommentFinancial ?? "", c.CommentGrowth ?? "",
        c.CommentPeople ?? "", c.CommentInternal ?? "",
        c.History.OrderBy(h => h.Month).Select(h => new ContractHistoryDto(h.Month, h.Overall.ToString())).ToList()
    );
}