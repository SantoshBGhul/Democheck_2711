using A360.Application.Common;
using A360.Application.DTOs;
using A360.Application.Interfaces;
using A360.Domain.Entities;
using A360.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace A360.Application.Services;

public sealed class PerformanceManagerService(
    IRepository<PerformanceManager> pms,
    IRepository<Contract> contracts) : IPerformanceManagerService
{
    public async Task<IReadOnlyList<PerformanceManagerDto>> GetAllAsync(CancellationToken ct = default)
    {
        // Execute both queries sequentially to avoid DbContext concurrency issues
        // Both queries must be fully awaited and materialized before moving to LINQ operations
        var all = await pms.ListAsync(ct: ct);
        var list = await contracts.ListAsync(ct: ct);

        // Perform all LINQ operations on materialized data outside of DbContext scope
        // Count results are now in-memory, so this is safe after both queries complete
        var contractCountByPmName = list
            .GroupBy(c => c.PmName, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.Count(), StringComparer.OrdinalIgnoreCase);

        return all.OrderBy(p => p.Name)
            .Select(p => new PerformanceManagerDto(
                p.Id, p.Name, p.Region, p.Email,
                contractCountByPmName.TryGetValue(p.Name, out var count) ? count : 0))
            .ToList();
    }

    public async Task<PerformanceManagerDto> CreateAsync(CreatePerformanceManagerDto dto, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(dto.Name))
            throw new ValidationAppException("Name is required.");

        var name = dto.Name.Trim();

        // Fetch all performance managers and do case-insensitive comparison in-memory
        // This avoids database provider compatibility issues with string operations
        var all = await pms.ListAsync(ct: ct);
        var existing = all.FirstOrDefault(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

        if (existing != null)
            throw new ConflictException($"Performance Manager '{name}' already exists.");

        var entity = new PerformanceManager
        {
            Name = name,
            Region = dto.Region,
            Email = dto.Email
        };
        await pms.AddAsync(entity, ct);
        await pms.SaveChangesAsync(ct);
        return new PerformanceManagerDto(entity.Id, entity.Name, entity.Region, entity.Email, 0);
    }

    //public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    //{
    //    var pm = await pms.GetByIdAsync(id, ct);
    //    if (pm is null) return false;
    //    pms.Remove(pm);
    //    await pms.SaveChangesAsync(ct);
    //    return true;
    //}

    public async Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var pm = await pms.GetByIdAsync(id, ct);
        if (pm is null) return false;

        var linked = await contracts.ListAsync(c => c.PerformanceManagerId == id || c.PmName == pm.Name, ct);
        if (linked.Count > 0)
            throw new ConflictException($"Cannot delete Performance Manager '{pm.Name}' because they are assigned to accounts. Remove or reassign the accounts first.");

        pms.Remove(pm);
        await pms.SaveChangesAsync(ct);
        return true;
    }

}
