using A360.API.Endpoints;
using A360.API.Middleware;
using A360.Application.Interfaces;
using A360.Application.Services;
using A360.Domain.Interfaces;
using A360.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// ============================================================
// 1. CONFIGURE SERILOG (FILE LOGGING)
// ============================================================
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    .WriteTo.File("Logs/api-log-.txt", rollingInterval: RollingInterval.Day)
    .WriteTo.File("Logs/client-errors-.txt", rollingInterval: RollingInterval.Day,
        restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Warning,
        outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
    .CreateLogger();

builder.Host.UseSerilog();

// ============================================================
// 2. SERVICES
// ============================================================
builder.Services.AddDbContext<A360DbContext>(opt =>
    opt.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection"),
        sql =>
        {
            sql.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null);
            sql.CommandTimeout(60);
        })); // Set database command timeout to 60 seconds to prevent cancellation

builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<IContractService, ContractService>();
builder.Services.AddScoped<IMeetingService, MeetingService>();
builder.Services.AddScoped<IPerformanceManagerService, PerformanceManagerService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();

// Configure HTTP request timeout (should align with database timeout)
builder.Services.Configure<HostOptions>(options =>
{
    options.ShutdownTimeout = TimeSpan.FromSeconds(90);
});

builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddProblemDetails();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "A360 Contract Health API", Version = "v1" });
});

builder.Services.AddCors(o => o.AddPolicy("Angular", p =>
    p.WithOrigins("http://localhost:4200")
     .AllowAnyHeader()
     .AllowAnyMethod()
     .AllowCredentials()));

var app = builder.Build();

// ============================================================
// 3. MIDDLEWARE
// ============================================================
app.UseExceptionHandler();
app.UseStatusCodePages();
app.UseCors("Angular");

// Request Logging
app.UseSerilogRequestLogging(options =>
{
    options.EnrichDiagnosticContext = (diagnosticContext, httpContext) =>
    {
        diagnosticContext.Set("RequestHost", httpContext.Request.Host.Value);
        diagnosticContext.Set("RequestScheme", httpContext.Request.Scheme);
    };
});

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ============================================================
// 4. API ROUTES
// ============================================================
var api = app.MapGroup("/api/a360");

api.MapDashboardEndpoints();
api.MapContractEndpoints();
api.MapContractHealthEndpoints();
api.MapMeetingEndpoints();
api.MapActionEndpoints();
api.MapPerformanceManagerEndpoints();

// Request Processor Endpoint (handles Angular request wrapper format)
app.MapRequestProcessorEndpoint();

// ============================================================
// 5. CLIENT ERROR LOGGING ENDPOINT
// ============================================================
api.MapPost("/logs/client-error", (ClientErrorDto dto, ILogger<Program> logger) =>
{
    // Logs into the "client-errors" file configured above
    logger.LogWarning(
        "CLIENT ERROR: {Message} | URL: {Url} | Stack: {Stack}",
        dto.Message, dto.Url, dto.Stack);
    return Results.Ok(new { ok = true });
}).WithTags("Logging");

// ============================================================
// 6. DB SEED
// ============================================================
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<A360DbContext>();
    if (builder.Configuration.GetValue<bool>("SeedSampleData"))
        await DbSeeder.SeedAsync(db);
    else
        await db.Database.MigrateAsync();
}

app.Run();

// DTO for frontend errors
public record ClientErrorDto(string Message, string? Stack, string? Url, string? Timestamp);