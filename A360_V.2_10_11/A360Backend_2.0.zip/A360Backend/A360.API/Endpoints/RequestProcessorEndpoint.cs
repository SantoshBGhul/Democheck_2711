using A360.Application.DTOs;
using A360.Application.Interfaces;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Text.Json;

namespace A360.API.Endpoints;

/// <summary>
/// Handles requests from the Angular application that use a request processor pattern.
/// Unwraps the request format: {app, action, data, requestType} and routes to appropriate service methods.
/// </summary>
public static class RequestProcessorEndpoint
{
    public static void MapRequestProcessorEndpoint(this WebApplication app)
    {
        app.MapPost("/api/request-processor", async (
            RequestProcessorInput input,
            IMeetingService meetingSvc,
            IPerformanceManagerService performanceSvc,
            CancellationToken ct) =>
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(input.Action) || string.IsNullOrWhiteSpace(input.Data))
                    return Results.BadRequest(new { error = "Action and Data are required." });

                // Parse the JSON data string
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var data = JsonSerializer.Deserialize<JsonElement>(input.Data, options);

                // Route based on action
                return input.Action switch
                {
                    // Meeting Actions
                    "CreateMeeting" => await HandleCreateMeeting(data, meetingSvc, options, ct),
                    "GetMeetings" => await HandleGetMeetings(data, meetingSvc, options, ct),

                    // Performance Manager Actions
                    "CreatePerformanceManager" => await HandleCreatePerformanceManager(data, performanceSvc, options, ct),
                    "GetPerformanceManagers" => await HandleGetPerformanceManagers(performanceSvc, ct),
                    "DeletePerformanceManager" => await HandleDeletePerformanceManager(data, performanceSvc, options, ct),

                    _ => Results.BadRequest(new { error = $"Unknown action: {input.Action}" })
                };
            }
            catch (JsonException ex)
            {
                return Results.BadRequest(new { error = "Invalid JSON data format.", details = ex.Message });
            }
            catch (Exception ex)
            {
                return new CustomStatusCodeResult(StatusCodes.Status500InternalServerError,
                    new { error = "An error occurred processing the request.", details = ex.Message });
            }
        })
        .WithName("RequestProcessor")
        .WithTags("Request Processor")
        .Produces(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status400BadRequest)
        .Produces(StatusCodes.Status409Conflict)
        .Produces(StatusCodes.Status500InternalServerError);
    }

    private static async Task<IResult> HandleCreateMeeting(JsonElement data, IMeetingService svc, JsonSerializerOptions options, CancellationToken ct)
    {
        try
        {
            var dto = JsonSerializer.Deserialize<CreateMeetingDto>(data.GetRawText(), options);
            if (dto == null)
                return Results.BadRequest(new { error = "Invalid meeting data." });

            var created = await svc.CreateAsync(dto, ct);
            return Results.Created($"/api/a360/meetings/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return Results.BadRequest(new { error = ex.Message });
        }
    }

    private static async Task<IResult> HandleGetMeetings(JsonElement data, IMeetingService svc, JsonSerializerOptions options, CancellationToken ct)
    {
        var page = 1;
        var pageSize = 50;
        string? customer = null;

        if (data.ValueKind == JsonValueKind.Object)
        {
            if (data.TryGetProperty("page", out var pageProp) && pageProp.TryGetInt32(out var p))
                page = p;
            if (data.TryGetProperty("pageSize", out var sizeProp) && sizeProp.TryGetInt32(out var s))
                pageSize = s;
            if (data.TryGetProperty("customer", out var custProp) && custProp.ValueKind != JsonValueKind.Null)
                customer = custProp.GetString();
        }

        page = Math.Max(1, page);
        pageSize = Math.Max(0, pageSize);

        var result = await svc.GetPagedAsync(page, pageSize, customer, ct);
        return Results.Ok(result);
    }

    private static async Task<IResult> HandleCreatePerformanceManager(JsonElement data, IPerformanceManagerService svc, JsonSerializerOptions options, CancellationToken ct)
    {
        try
        {
            var dto = JsonSerializer.Deserialize<CreatePerformanceManagerDto>(data.GetRawText(), options);
            if (dto == null)
                return Results.BadRequest(new { error = "Invalid performance manager data." });

            var created = await svc.CreateAsync(dto, ct);
            return Results.Created($"/api/a360/performance-managers/{created.Id}", created);
        }
        catch (Exception ex)
        {
            return Results.BadRequest(new { error = ex.Message });
        }
    }

    private static async Task<IResult> HandleGetPerformanceManagers(IPerformanceManagerService svc, CancellationToken ct)
    {
        var result = await svc.GetAllAsync(ct);
        return Results.Ok(result);
    }

    private static async Task<IResult> HandleDeletePerformanceManager(
    JsonElement data,
    IPerformanceManagerService svc,
    JsonSerializerOptions options,
    CancellationToken ct)
    {
        try
        {
            if (data.ValueKind == JsonValueKind.Object && data.TryGetProperty("id", out var idProp))
            {
                var id = idProp.GetString();
                if (string.IsNullOrEmpty(id))
                    return Results.BadRequest(new { error = "Valid performance manager ID is required." });

                if (!Guid.TryParse(id, out var parsedId))
                    return Results.BadRequest(new { error = "Valid performance manager ID is required." });
                var deleted = await svc.DeleteAsync(parsedId, ct);
                return deleted
                    ? Results.Ok(new { message = "Performance Manager successfully removed." })
                    : Results.NotFound(new { error = "Performance Manager not found." });
            }

            return Results.BadRequest(new { error = "Invalid payload structure. ID property is missing." });
        }
        catch (Exception ex)
        {
            return Results.BadRequest(new { error = ex.Message });
        }
    }
}

public record RequestProcessorInput(string App, string Action, string Data, string RequestType);

public class CustomStatusCodeResult : IResult
{
    private readonly int _statusCode;
    private readonly object? _data;

    public CustomStatusCodeResult(int statusCode, object? data = null)
    {
        _statusCode = statusCode;
        _data = data;
    }

    public async Task ExecuteAsync(HttpContext httpContext)
    {
        httpContext.Response.StatusCode = _statusCode;
        if (_data != null)
        {
            await httpContext.Response.WriteAsJsonAsync(_data);
        }
    }
}
