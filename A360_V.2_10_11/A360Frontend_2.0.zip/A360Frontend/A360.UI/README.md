# A360UI

## A360 gateway and local operation

The UI sends A360 requests to the configured security request processor. The
processor forwards the inner `GET` or `POST` action to A360; deletion uses
`POST` actions ending in `/delete`. Successful POST responses must contain
the processor's `StatusCode` and JSON-encoded `data` fields. The A360 API
returns HTTP 200 for successful POSTs because the current processor treats
other statuses as failures.

Run the A360 API and the security request processor before starting the UI.
The development gateway address is configured in `src/environments/environment.ts`.
The optimized build currently uses that same file; configure an appropriate
gateway address and Angular file replacement before using another environment.
Restart the A360 API after changing backend code. Automatic sample data is
disabled by default; to explicitly enable it set `SeedSampleData` to `true`
in the API configuration. Database migrations still run at startup.

The dashboard month filter uses each contract's last meeting date. Admin and
the meeting wizard load all contracts independently of dashboard filters.
Deleting a manager is blocked while accounts are assigned. Deleting an action
clears the action on its meeting without deleting the meeting. Account deletion
also deletes associated meetings and history according to database relationships.

Before any real deployment, separately verify gateway authentication and
authorization, CSRF protections, HTTPS, allowed origins, secret management,
database backups, and hosting configuration. These cannot be guaranteed by
the frontend and A360 API build alone.

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 22.2.2.

## Development server

To start a local development server, run:

```bash
ng serve
```

Once the server is running, open your browser and navigate to `http://localhost:4200/`. The application will automatically reload whenever you modify any of the source files.

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the project run:

```bash
ng build
```

This will compile your project and store the build artifacts in the `dist/` directory. By default, the production build optimizes your application for performance and speed.

## Running unit tests

To execute unit tests with the [Vitest](https://vitest.dev/) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
