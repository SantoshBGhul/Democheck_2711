import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Topbar } from './core/layout/topbar/topbar';
import { Footer } from './core/layout/footer/footer';
import { FlashToast } from './components/flash-toast/flash-toast';
import { MeetingWizard } from './components/meeting-wizard/meeting-wizard';
import { StateService } from './core/services/state';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from '../environments/environment';
import { ApiService } from './services/api-service';


@Component({
  selector: 'app-root',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, Topbar, Footer, FlashToast, MeetingWizard, Topbar],
  templateUrl: './app.html',
})
export class App {
  private readonly state = inject(StateService);
    isAccess = false;
    userDetails: any;
    userRoles: any;
    userInitial: any;
    userName: string = '';
    showAdmin: boolean = false;
    businessTitle: any;
    sessionService: any;
    toastr: any;
    errorHandlingService: any;
    usageTrackerLoaded: boolean = false;


  constructor(
    private spinner: NgxSpinnerService,
            public service: ApiService
  ) {
    this.state.reload();
  }
      getUserDetails(userId: string) {
          this.spinner.show();
          this.service.getUserDetails(userId).subscribe((res: any) => {
              //console.log(this.userRoles);
  
              if ((res.Status === 403 || res.Status === 401) && res.data === 'unauthorized access') {
                  //this.toastr.error('You are not authorised to access this application', 'Error',{toastComponent:ToastermessageComponent});
                  setTimeout(() => {
                      window.location.href = res.URL;
                  }, 3000);
              } else {
                  sessionStorage.setItem("EID", res.employee.eid); //not work
                  sessionStorage.setItem("username", `${res.employee.nameFirst}-${res.employee.nameLast}`); //not work
  
                  if (res.UserApplicationList.indexOf(environment.applicationName) > -1) {
  
                      this.userDetails = res.employee;
                      this.userRoles = res.listOfRoleName;
              
  
                      if (this.userRoles.includes('LeadEngineering - Pole Leader')) {
                          this.isAccess = true
                          sessionStorage.setItem('isAccess', JSON.stringify(this.isAccess));
                      }
                      else {
                          this.isAccess = false
                          sessionStorage.setItem('isAccess', JSON.stringify(this.isAccess));
                      }
  
                      this.userInitial = (res.employee.nameFirst) + ' ' + (res.employee.nameLast);
                      this.service.userName = res.employee.nameFirst + ' ' + res.employee.nameLast;
                      this.service.userFirstName = res.employee.nameFirst;
                      this.service.businessTitle = res.employee.businessTitle;
                      this.service.userId = res.employee.eid;
  
                      this.service.roleId = res.listOfRoleId[0];
                      this.service.roleName = res.listOfRoleName.find((role: string) => role.includes('LeadEngineering'));
                      this.service.getConfigurationData().subscribe((configData: any) => {
                          this.service.setConfigurationData(configData);
                      });
                      this.service.userDetails = res;
                      //session timeout started
                      //this.sessionService.getSessionTimeoutValue();
                  } else {
                      // this.toastr.error('You are not authorised to access this application', 'Error',{toastComponent:ToastermessageComponent});
                      setTimeout(() => {
                          // window.location.href = res.redirectUrl;
                      }, 3000);
                  }
              }
          }, err => {
              this.spinner.hide();
              //this.errorHandlingService.handleErrorMessages(err);
          });
}
}

