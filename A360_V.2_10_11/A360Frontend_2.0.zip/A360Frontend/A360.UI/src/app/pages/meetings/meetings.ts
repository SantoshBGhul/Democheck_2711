import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { StateService } from '../../core/services/state';
import { MeetingWizardService } from '../../components/meeting-wizard/meeting-wizard.service';
import { Meeting } from '../../core/models/a360.models';

@Component({
  selector: 'app-meetings',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe],
  templateUrl: './meetings.html',
})
export class Meetings {
  protected readonly state = inject(StateService);
  private readonly wizard = inject(MeetingWizardService);

  protected readonly pageSize = 10;
  protected readonly currentPage = signal(1);
  protected readonly Math = Math;

  protected readonly sortedMeetings = computed<readonly Meeting[]>(() =>
    [...this.state.meetings()].sort((a, b) => {
      // 1. Primary Sort: Meeting Date (Newest first)
      const dateA = a.meetingDate ? new Date(a.meetingDate).getTime() : 0;
      const dateB = b.meetingDate ? new Date(b.meetingDate).getTime() : 0;
      
      if (dateB !== dateA) {
        return dateB - dateA;
      }

      const updatedA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
      const updatedB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
      
      if (updatedB !== updatedA) {
        return updatedB - updatedA;
      }
      
      return b.id - a.id; 
    })
  );

  protected readonly totalPages = computed(() =>
    Math.max(1, Math.ceil(this.sortedMeetings().length / this.pageSize))
  );

  protected readonly paginatedMeetings = computed<readonly Meeting[]>(() => {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.sortedMeetings().slice(start, start + this.pageSize);
  });

  protected nextPage(): void {
    if (this.currentPage() < this.totalPages()) this.currentPage.update(p => p + 1);
  }

  protected prevPage(): void {
    if (this.currentPage() > 1) this.currentPage.update(p => p - 1);
  }

  protected startMeeting(): void {
    this.wizard.open();
  }

  protected sentimentClass(s: string): string {
    return s === 'Positive' ? 'bg-emerald-50 text-emerald-800'
      : s === 'Negative' ? 'bg-red-50 text-red-800'
      : 'bg-slate-100 text-slate-500';
  }
}