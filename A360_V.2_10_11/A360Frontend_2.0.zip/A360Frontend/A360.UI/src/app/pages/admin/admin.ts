import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { StateService } from '../../core/services/state';
import { ApiService } from '../../core/services/api';
import { FlashService } from '../../core/services/flash.service';
import { Contract, PerformanceManager, initialsOf } from '../../core/models/a360.models';
@Component({
  selector: 'app-admin',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  templateUrl: './admin.html',
})
export class Admin {
  protected readonly state = inject(StateService);
  private readonly api = inject(ApiService);
  private readonly flash = inject(FlashService);
  protected readonly initials = initialsOf;
  protected readonly pms = computed<readonly PerformanceManager[]>(() => this.state.pms());
  protected readonly contracts = computed<readonly Contract[]>(() =>
    [...this.state.allContracts()].sort((a, b) => a.customer.localeCompare(b.customer))
  );
  // PM form
  protected pmName = signal('');
  protected pmRegion = signal('EMEA');
  protected pmEmail = signal('');
  // Account form
  protected acName = signal('');
  protected acPm = signal('');
  protected acRegion = signal('EMEA');
  protected acValue = signal(0);
  protected readonly pendingDelete = signal<{ kind: 'pm'; item: PerformanceManager } | { kind: 'account'; item: Contract } | null>(null);
  protected readonly deleting = signal(false);
  protected async addPM(): Promise<void> {
    const name = this.pmName().trim();
    if (!name) { this.flash.show('Enter a Performance Manager name'); return; }
    try {
      await firstValueFrom(this.api.CreatePerformanceManager({
        name, region: this.pmRegion(), email: this.pmEmail().trim() || undefined,
      }));
      this.pmName.set(''); this.pmEmail.set('');
      this.state.reload();
      this.flash.show(`"${name}" added`);
    } catch { /* interceptor handles */ }
  }
  protected deletePM(p: PerformanceManager): void {
    if (p.accountCount > 0) {
      this.flash.show(`"${p.name}" is assigned to ${p.accountCount} account(s). Reassign or remove them first.`, 5000);
      return;
    }
    this.pendingDelete.set({ kind: 'pm', item: p });
  }
  protected async addAccount(): Promise<void> {
    const name = this.acName().trim();
    if (!name) { this.flash.show('Enter an account name'); return; }
    if (!this.pms().some(p => p.name === this.acPm())) {
      this.flash.show('Select a Performance Manager for the account');
      return;
    }
    try {
      await firstValueFrom(this.api.createContract({
        customer: name,
        pmName: this.acPm(),
        region: this.acRegion(),
        value: Number(this.acValue()) || 0,
      }));
      this.acName.set(''); this.acValue.set(0);
      this.state.reload();
      this.flash.show(`Account "${name}" added`);
    } catch { /* handled */ }
  }
  protected deleteAccount(c: Contract): void {
    this.pendingDelete.set({ kind: 'account', item: c });
  }

  protected async confirmDelete(): Promise<void> {
    const pending = this.pendingDelete();
    if (!pending || this.deleting()) return;
    this.deleting.set(true);
    try {
      if (pending.kind === 'pm') await firstValueFrom(this.api.DeletePerformanceManager(pending.item.id));
      else await firstValueFrom(this.api.deleteContract(pending.item.id));
      this.pendingDelete.set(null);
      this.state.reload();
      this.flash.show(pending.kind === 'pm' ? 'Performance Manager removed' : 'Account removed');
    } catch { /* reported by the API service or interceptor */ }
    finally { this.deleting.set(false); }
  }
  protected healthDot(h: string): string {
    switch (h) {
      case 'Green': return 'bg-emerald-500';
      case 'Yellow': return 'bg-yellow-500';
      case 'Orange': return 'bg-orange-500';
      case 'Red': return 'bg-red-500';
      default: return 'bg-slate-300';
    }
  }
}