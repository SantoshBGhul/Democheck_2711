import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { environment } from '../../../environments/environment';
import { ApiService } from './api';

describe('ApiService request processor', () => {
  let service: ApiService;
  let http: HttpTestingController;
  const url = environment.baseUrl + environment.reqProcessorUrl;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(ApiService);
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());

  it('uses POST for all deletes and unwraps the gateway response', () => {
    const cases = [
      { call: () => service.deleteContract(4), action: environment.DeleteContract.replace('{id}', '4') },
      { call: () => service.deleteAction(9), action: environment.DeleteAction.replace('{id}', '9') },
      { call: () => service.DeletePerformanceManager('a/b'), action: environment.DeletePerformanceManager.replace('{id}', 'a%2Fb') },
    ];
    for (const item of cases) {
      let success = false;
      item.call().subscribe(result => { success = result.ok; });
      const req = http.expectOne(url);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual({ app: environment.applicationName, action: item.action, requestType: 'POST', data: '{}' });
      req.flush({ StatusCode: 200, data: '{"ok":true}' });
      expect(success).toBe(true);
    }
  });

  it('rejects wrapped backend errors even when the gateway returns HTTP 200', () => {
    let message = '';
    service.createContract({ customer: 'Existing', pmName: 'Manager', region: 'EMEA', value: 1 })
      .subscribe({ error: error => { message = error.message; } });
    http.expectOne(url).flush({ StatusCode: 400, data: JSON.stringify({ status: 409, detail: 'Contract already exists.' }) });
    expect(message).toBe('Contract already exists.');
  });

  it('rejects a gateway exception and an unconfirmed deletion', () => {
    let errors = 0;
    service.DeletePerformanceManager('id').subscribe({ error: () => errors++ });
    http.expectOne(url).flush('Exception occur');
    service.deleteContract(4).subscribe({ error: () => errors++ });
    http.expectOne(url).flush({ StatusCode: 200, data: '{}' });
    expect(errors).toBe(2);
  });

  it('rejects invalid gateway GET and POST response shapes', () => {
    let errors = 0;
    service.GetPerformanceManagers().subscribe({ error: () => errors++ });
    http.expectOne(url).flush('Exception occur');
    service.GetMeetings({}, 1, 0).subscribe({ error: () => errors++ });
    http.expectOne(url).flush({ Status: 403, data: 'unauthorized access' });
    service.CreatePerformanceManager({ name: 'Manager', region: 'EMEA' }).subscribe({ error: () => errors++ });
    http.expectOne(url).flush({ StatusCode: 200, data: '{}' });
    expect(errors).toBe(3);
  });

  it('surfaces backend validation messages from the gateway wrapper', () => {
    let message = '';
    service.updateKpi({ contractId: 7, key: 'outcomeKpi', value: 'Green' })
      .subscribe({ error: error => { message = error.message; } });
    http.expectOne(url).flush({ StatusCode: 400, data: JSON.stringify({ errors: { key: ['Invalid KPI.'] } }) });
    expect(message).toBe('Invalid KPI.');
  });

  it('explains a generic backend 404 and preserves a specific record error', () => {
    let message = '';
    service.deleteContract(4).subscribe({ error: error => { message = error.message; } });
    http.expectOne(url).flush({ StatusCode: 400, data: JSON.stringify({ status: 404, title: 'Not Found' }) });
    expect(message).toContain('Check that the updated A360 API is running');

    service.deleteContract(4).subscribe({ error: error => { message = error.message; } });
    http.expectOne(url).flush({ StatusCode: 400, data: JSON.stringify({ error: 'Account not found.' }) });
    expect(message).toBe('Account not found.');
  });

  it('puts filters and pagination in the forwarded GET URL', () => {
    service.GetContracts({ customer: 'A & B' }, 2, 10).subscribe();
    const req = http.expectOne(url);
    expect(req.request.body.requestType).toBe('GET');
    const action = req.request.body.action as string;
    const query = new URLSearchParams(action.split('?')[1]);
    expect(query.get('customer')).toBe('A & B');
    expect(query.get('page')).toBe('2');
    expect(query.get('pageSize')).toBe('10');
    req.flush({ items: [], total: 0, page: 2, pageSize: 10 });
  });

  it('sends updates with serialized data and unwraps their response', () => {
    const kpi = { contractId: 7, key: 'outcomeKpi', value: 'Green' };
    service.updateKpi(kpi).subscribe();
    const req = http.expectOne(url);
    expect(req.request.body).toEqual({
      app: environment.applicationName, action: environment.CreateContractHealth,
      requestType: 'POST', data: JSON.stringify(kpi),
    });
    req.flush({ StatusCode: 200, data: '{"ok":true}' });
  });
});
