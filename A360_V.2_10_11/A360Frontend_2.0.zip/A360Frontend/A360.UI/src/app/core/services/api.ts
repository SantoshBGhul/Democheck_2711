import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import {
  Contract, Meeting, PerformanceManager, PagedResult, DashboardSummary,
  CreateContractRequest, UpdateKpiRequest, CreateMeetingRequest,
  CreatePerformanceManagerRequest,
} from '../models/a360.models';
import { environment } from '../../../environments/environment';
import { FlashService } from './flash.service';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly flash = inject(FlashService);

  GetDashboardSummary(filters: Record<string, string>): Observable<DashboardSummary> {
    return this.get<DashboardSummary>(environment.GetDashboardSummary, filters).pipe(map(result => {
      if (typeof result.score !== 'number' || typeof result.total !== 'number') {
        return this.fail('Unable to retrieve the dashboard summary.');
      }
      return result;
    }));
  }

  GetContracts(filters: Record<string, string>, page = 1, pageSize = 0): Observable<PagedResult<Contract>> {
    return this.get<PagedResult<Contract>>(environment.GetContracts, { ...filters, page, pageSize })
      .pipe(map(result => this.requirePage(result)));
  }

  GetContract(id: number): Observable<Contract> {
    return this.get(environment.GetContractById.replace('{id}', encodeURIComponent(String(id))));
  }

  createContract(body: CreateContractRequest): Observable<Contract> {
    return this.post<Contract>(environment.CreateContract, body).pipe(map(result => {
      if (typeof result.id !== 'number') return this.fail('Could not confirm account creation. Refresh the list before retrying.');
      return result;
    }));
  }

  deleteContract(id: number): Observable<{ ok: boolean }> {
    return this.deleteByPost(environment.DeleteContract.replace('{id}', encodeURIComponent(String(id))));
  }

  updateKpi(body: UpdateKpiRequest): Observable<{ ok: boolean }> {
    return this.confirmedPost(environment.CreateContractHealth, body);
  }

  GetMeetings(filters: Record<string, string> = {}, page = 1, pageSize = 0): Observable<PagedResult<Meeting>> {
    return this.get<PagedResult<Meeting>>(environment.GetMeetings, { ...filters, page, pageSize })
      .pipe(map(result => this.requirePage(result)));
  }

  createMeeting(body: CreateMeetingRequest): Observable<Meeting> {
    return this.post<Meeting>(environment.CreateMeeting, body).pipe(map(result => {
      if (typeof result.id !== 'number') return this.fail('Could not confirm meeting creation. Refresh the list before retrying.');
      return result;
    }));
  }

  updateActionStatus(id: number, status: string): Observable<{ ok: boolean }> {
    return this.confirmedPost(environment.UpdateAction.replace('{id}', encodeURIComponent(String(id))), { status });
  }

  deleteAction(id: number): Observable<{ ok: boolean }> {
    return this.deleteByPost(environment.DeleteAction.replace('{id}', encodeURIComponent(String(id))));
  }

  GetPerformanceManagers(): Observable<readonly PerformanceManager[]> {
    return this.get<readonly PerformanceManager[]>(environment.GetPerformanceManagers).pipe(map(result => {
      if (!Array.isArray(result)) return this.fail('Unable to retrieve Performance Managers.');
      return result;
    }));
  }

  CreatePerformanceManager(body: CreatePerformanceManagerRequest): Observable<PerformanceManager> {
    return this.post<PerformanceManager>(environment.CreatePerformanceManager, body).pipe(map(result => {
      if (typeof result.id !== 'string') return this.fail('Could not confirm manager creation. Refresh the list before retrying.');
      return result;
    }));
  }

  DeletePerformanceManager(id: string): Observable<{ ok: boolean }> {
    return this.deleteByPost(environment.DeletePerformanceManager.replace('{id}', encodeURIComponent(id)));
  }

  private deleteByPost(action: string): Observable<{ ok: boolean }> {
    return this.confirmedPost(action, {});
  }

  private confirmedPost(action: string, body: object): Observable<{ ok: boolean }> {
    return this.post<{ ok: boolean }>(action, body).pipe(map(result => {
      if (result.ok !== true) return this.fail('Could not confirm the operation. Refresh the list before retrying.');
      return result;
    }));
  }

  private get<T>(action: string, values: Record<string, string | number> = {}): Observable<T> {
    let params = new HttpParams();
    for (const [key, value] of Object.entries(values)) {
      if (value !== '') params = params.set(key, String(value));
    }
    const query = params.toString();
    return this.http.post<unknown>(environment.baseUrl + environment.reqProcessorUrl, {
      app: environment.applicationName,
      action: query ? `${action}?${query}` : action,
      requestType: 'GET',
    }).pipe(map(response => {
      if (response === null || typeof response !== 'object' || 'StatusCode' in response) {
        return this.fail('Unable to retrieve data. Please try again.');
      }
      return response as T;
    }));
  }

  private post<T>(action: string, body: object): Observable<T> {
    return this.http.post<unknown>(environment.baseUrl + environment.reqProcessorUrl, {
      app: environment.applicationName, action, data: JSON.stringify(body), requestType: 'POST',
    }).pipe(map(response => {
      if (typeof response !== 'object' || response === null || !('StatusCode' in response) ||
          !('data' in response) || typeof response.StatusCode !== 'number' ||
          typeof response.data !== 'string') {
        return this.fail('The server returned an unexpected response. Check whether the operation completed before retrying.');
      }

      let data: unknown;
      try {
        data = JSON.parse(response.data);
      } catch {
        return this.fail('The server returned an invalid response. Check whether the operation completed before retrying.');
      }
      if (response.StatusCode !== 200) {
        const validationErrors = typeof data === 'object' && data !== null && 'errors' in data &&
          typeof data.errors === 'object' && data.errors !== null
          ? Object.values(data.errors).flat().filter((value): value is string => typeof value === 'string').join(' ')
          : '';
        const detail = typeof data === 'object' && data !== null
          ? ('detail' in data && typeof data.detail === 'string' ? data.detail
            : 'error' in data && typeof data.error === 'string' ? data.error
            : 'title' in data && typeof data.title === 'string' ? data.title : undefined)
          : typeof data === 'string' ? data : undefined;
        if (typeof data === 'object' && data !== null && 'status' in data && data.status === 404 &&
            (!detail || detail === 'Not Found')) {
          return this.fail('The API endpoint or record was not found. Check that the updated A360 API is running, then refresh and try again.');
        }
        return this.fail(validationErrors || detail || 'The operation failed. Please try again.');
      }
      if (data === null || typeof data !== 'object') {
        return this.fail('The server returned an unexpected response. Check whether the operation completed before retrying.');
      }
      if ('ok' in data && data.ok !== true) return this.fail('The operation failed.');
      return data as T;
    }));
  }

  private fail(message: string): never {
    this.flash.show(message, 5000);
    throw new Error(message);
  }

  private requirePage<T>(result: PagedResult<T>): PagedResult<T> {
    if (!Array.isArray(result.items)) return this.fail('Unable to retrieve the requested list.');
    return result;
  }
}
