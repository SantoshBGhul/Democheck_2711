import { Injectable, inject } from '@angular/core';
import { HttpBackend, HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ErrorLogService {
  private readonly http = new HttpClient(inject(HttpBackend));

  logError(error: any): void {
    const payload = {
      message: error?.message || String(error),
      stack: error?.stack || 'No stack trace available',
      url: window.location.href,
      timestamp: new Date().toISOString()
    };

    // Fire and forget (do not await, we don't want logging to block the UI)
    this.http.post<{ StatusCode?: number }>(environment.baseUrl + environment.reqProcessorUrl, {
      app: environment.applicationName,
      action: environment.LogClientError,
      requestType: 'POST',
      data: JSON.stringify(payload),
    }).subscribe({
      next: response => {
        if (response?.StatusCode !== 200) console.error('Failed to send error to backend', response);
      },
      error: (err) => console.error('Failed to send error to backend', err)
    });
  }
}