import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { StateService } from '../../services/state';
import { MeetingWizardService } from '../../../components/meeting-wizard/meeting-wizard.service';

interface NavItem {
  readonly path: string;
  readonly label: string;
}

@Component({
  selector: 'app-topbar',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, FormsModule],
  templateUrl: './topbar.html',
})
export class Topbar {
  private readonly state = inject(StateService);
  private readonly wizard = inject(MeetingWizardService);
  private readonly router = inject(Router);

  // protected readonly searchTerm = signal('');
  
  protected readonly isMobileMenuOpen = signal(false);

  protected readonly nav: readonly NavItem[] = [
    { path: '/dashboard', label: 'Dashboard' },
    { path: '/meetings', label: 'Meetings' },
    { path: '/actions', label: 'Actions' },
    { path: '/admin', label: 'Admin' },
  ];

  protected toggleMobileMenu(): void {
    this.isMobileMenuOpen.update(v => !v);
  }

  // protected onSearch(value: string): void {
  //   this.searchTerm.set(value);
  //   const s = value.trim().toLowerCase();

  //   if (!s) {
  //     this.state.setFilter('customer', 'All');
  //     return;
  //   }
  //   const match = this.state.contracts().find(c => c.customer.toLowerCase().includes(s));
  //   if (match) this.state.setFilter('customer', match.customer);
  // }


  protected goToActions(): void {
    void this.router.navigate(['/actions']);
  }
}