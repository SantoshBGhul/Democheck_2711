// ============================================================
// A360 · DOMAIN MODELS (mirrors .NET DTOs)
// ============================================================

export type HealthStatus = 'Blank' | 'Green' | 'Yellow' | 'Orange' | 'Red';
export type Sentiment = 'Blank' | 'Positive' | 'Neutral' | 'Negative';
export type ActionStatus = 'Open' | 'InProgress' | 'Completed';
export type OverallState = 'Blank' | 'Healthy' | 'Watch' | 'Attention' | 'Critical';

export interface ContractHistory {
  readonly month: string;
  readonly overall: HealthStatus;
}

export interface Contract {
  readonly id: number;
  readonly customer: string;
  readonly pmName: string;
  readonly region: string;
  readonly value: number;
  readonly riskValue: number;
  readonly sentiment: Sentiment;
  readonly updatedAt: string;
  readonly lastMeetingDate: string;
  readonly overallHealth: HealthStatus;

  // NEW DYNAMIC METRICS
  readonly serviceScore: number | null;
  readonly serviceCoverage: number | null;
  readonly serviceHealth: number | null;
  readonly csatScore: number | null;
  readonly npsScore: number | null;
  readonly pipelineValue: number | null;
  readonly bookedMarginPct: number | null;
  readonly grossMarginPct: number | null;
  readonly preventiveHrs: number | null;
  readonly cyberHrs: number | null;
  readonly trainingHrs: number | null;
  readonly bgpPlusHrs: number | null;
  
  // Notes
  readonly valueDelivered: string;
  readonly concern: string;
  readonly customerAction: string;
  readonly pfmActionText: string;
  readonly managementSupportText: string;

  // Customer & Outcomes KPIs
  readonly outcomeKpi: HealthStatus;
  readonly topCustomerPriority: HealthStatus;
  readonly next90DayRisk: HealthStatus;
  readonly pfmAction: HealthStatus;
  readonly managementSupport: HealthStatus;

  // Financial KPIs
  readonly marginChecked: HealthStatus;
  readonly billingForecastUpdated: HealthStatus;
  readonly pastDues: HealthStatus;
  readonly sespBgpCostsChecked: HealthStatus;

  // Growth
  readonly renewalOnTime: HealthStatus;
  readonly tracker2026: HealthStatus;
  readonly tracker2027: HealthStatus;

  // People
  readonly idpCompleted: HealthStatus;
  readonly hpdResultsUpdated: HealthStatus;
  readonly siopCompleted: HealthStatus;

  // Internal
  readonly sfdcTasksClosed: HealthStatus;
  readonly reportingStandard: HealthStatus;
  readonly customerMeetingsPlanned: HealthStatus;
  readonly digitalPrimeDashboard: HealthStatus;
  readonly contractSetupCorrect: HealthStatus;
  readonly a360OpsDashboard: HealthStatus;
  readonly npsShared: HealthStatus;
  readonly mosCompleted: HealthStatus;

  // Dimensions
  readonly deliveryHealth: HealthStatus;
  readonly financialHealth: HealthStatus;
  readonly riskHealth: HealthStatus;
  readonly renewalHealth: HealthStatus;

  // Group comments
  readonly commentCustomer: string;
  readonly commentFinancial: string;
  readonly commentGrowth: string;
  readonly commentPeople: string;
  readonly commentInternal: string;

  readonly history: readonly ContractHistory[];
}

export interface Meeting {
  readonly id: number;
  readonly contractId: number;
  readonly customer: string;
  readonly pmName: string;
  readonly meetingDate: string;
  readonly meetingType: string;
  readonly sentiment: Sentiment;
  readonly action: string;
  readonly owner: string;
  readonly due?: string | null;
  readonly actionStatus: ActionStatus;
  readonly source: string;
  readonly updatedAt: string;
}

export interface PerformanceManager {
  readonly id: string;
  readonly name: string;
  readonly region: string;
  readonly email?: string;
  readonly accountCount: number;
}

export interface PagedResult<T> {
  readonly items: readonly T[];
  readonly total: number;
  readonly page: number;
  readonly pageSize: number;
}

export interface DashboardSummary {
  readonly score: number;
  readonly state: OverallState;
  readonly total: number;
  readonly green: number;
  readonly yellow: number;
  readonly orange: number;
  readonly red: number;
  readonly contractValue: number;
  readonly riskValue: number;
  readonly positivePct: number;
}

// ============ Request payloads ============

export interface CreateContractRequest {
  readonly customer: string;
  readonly pmName: string;
  readonly region: string;
  readonly value: number;
}

export interface UpdateKpiRequest {
  readonly contractId: number;
  readonly key: string;
  readonly value: string;
}

export interface CreateMeetingRequest {
  readonly contractId: number;
  readonly pmName: string;
  readonly meetingDate: string;
  readonly meetingType: string;
  readonly sentiment: string;
  readonly valueDelivered: string;
  readonly concern: string;
  readonly customerAction: string;
  readonly pfmAction: string;
  readonly managementSupport: string;
  readonly next90DayRisk: string;
  readonly owner: string;
  readonly due: string | null;
  readonly action: string;
  readonly healthSnapshot: Record<string, string>;
  readonly groupComments: Record<string, string>;
  
  readonly serviceScore: number | null;
  readonly serviceCoverage: number | null;
  readonly serviceHealth: number | null;
  readonly csatScore: number | null;
  readonly npsScore: number | null;
  readonly pipelineValue: number | null;
  readonly bookedMarginPct: number | null;
  readonly grossMarginPct: number | null;
  readonly preventiveHrs: number | null;
  readonly cyberHrs: number | null;
  readonly trainingHrs: number | null;
  readonly bgpPlusHrs: number | null;
}

export interface CreatePerformanceManagerRequest {
  readonly name: string;
  readonly region: string;
  readonly email?: string;
}

// ============ KPI catalog ============

export type GroupCommentKey = 'customer' | 'financial' | 'growth' | 'people' | 'internal';

export interface KpiDefinition {
  readonly key: keyof Contract;
  readonly label: string;
}

export interface KpiGroup {
  readonly id: string;
  readonly commentKey: GroupCommentKey;
  readonly title: string;
  readonly sub: string;
  readonly commentLabel: string;
  readonly commentPlaceholder: string;
  readonly defs: readonly KpiDefinition[];
}

export const KPI_GROUPS: readonly KpiGroup[] = [
  {
    id: 'customer',
    commentKey: 'customer',
    title: 'Customer & Outcomes Score',
    sub: 'Outcomes, priorities, risks and support',
    commentLabel: 'Customer & Outcomes · Overall Comment',
    commentPlaceholder: 'Add an overall comment for the Customer & Outcomes group…',
    defs: [
      { key: 'outcomeKpi', label: 'Outcome KPI achievement' },
      { key: 'topCustomerPriority', label: 'Top customer priority' },
      { key: 'next90DayRisk', label: 'Next 90-day risk' },
      { key: 'pfmAction', label: 'PFM action' },
      { key: 'managementSupport', label: 'Management support required' },
    ],
  },
  {
    id: 'financial',
    commentKey: 'financial',
    title: 'Financial',
    sub: 'Profitability, billing and cost checks',
    commentLabel: 'Financial · Overall Comment',
    commentPlaceholder: 'Add an overall comment for the Financial group…',
    defs: [
      { key: 'marginChecked', label: 'Margin checked in profitability file' },
      { key: 'billingForecastUpdated', label: 'Billing Forecast updated' },
      { key: 'pastDues', label: "Past Due's" },
      { key: 'sespBgpCostsChecked', label: 'SESP & BGP costs checked' },
    ],
  },
  {
    id: 'growth',
    commentKey: 'growth',
    title: 'Growth',
    sub: 'Renewal and growth readiness',
    commentLabel: 'Growth · Overall Comment',
    commentPlaceholder: 'Add an overall comment for the Growth group…',
    defs: [
      { key: 'renewalOnTime', label: 'Renewal OnTime' },
      { key: 'tracker2026', label: 'Tracker 2026 updated' },
      { key: 'tracker2027', label: 'Tracker 2027 updated' },
    ],
  },
  {
    id: 'people',
    commentKey: 'people',
    title: 'People',
    sub: 'IDP, HPD and SIOP checks',
    commentLabel: 'People · Overall Comment',
    commentPlaceholder: 'Add an overall comment for the People group…',
    defs: [
      { key: 'idpCompleted', label: 'IDP completed' },
      { key: 'hpdResultsUpdated', label: 'HPD results updated' },
      { key: 'siopCompleted', label: 'SIOP completed' },
    ],
  },
  {
    id: 'internal',
    commentKey: 'internal',
    title: 'Internal Activities',
    sub: 'Operational execution and dashboard hygiene',
    commentLabel: 'Internal Activities · Overall Comment',
    commentPlaceholder: 'Add an overall comment for the Internal Activities group…',
    defs: [
      { key: 'sfdcTasksClosed', label: 'SFDC Tasks Closed' },
      { key: 'reportingStandard', label: 'Reporting according to our standard' },
      { key: 'customerMeetingsPlanned', label: 'Customer meetings planned' },
      { key: 'digitalPrimeDashboard', label: 'Digital Prime Dashboard in use?' },
      { key: 'contractSetupCorrect', label: 'Contract setup in SFDC correct?' },
      { key: 'a360OpsDashboard', label: 'A360 OPS Dashboard status' },
      { key: 'npsShared', label: 'NPS Shared' },
      { key: 'mosCompleted', label: 'MOS completed' },
    ],
  },
];

export const ALL_KPIS: readonly KpiDefinition[] = KPI_GROUPS.flatMap(g => g.defs);

export const HEALTH_STATUSES: readonly HealthStatus[] = ['Green', 'Yellow', 'Orange', 'Red'];
export const HISTORY_MONTHS: readonly string[] = ['Apr-26', 'May-26', 'Jun-26', 'Jul-26', 'Aug-26', 'Sep-26'];

// ============ Pure helpers ============

export function statusScore(v: HealthStatus | string | undefined): number {
  switch (v) {
    case 'Green': return 100;
    case 'Yellow': return 80;
    case 'Orange': return 60;
    case 'Red': return 20;
    default: return 0;
  }
}

export function statusRank(v: HealthStatus | string | undefined): number {
  switch (v) {
    case 'Red': return 4;
    case 'Orange': return 3;
    case 'Yellow': return 2;
    case 'Green': return 1;
    default: return 0;
  }
}

export function sentimentClass(s: Sentiment | string | undefined): string {
  if (s === 'Positive') return 'pos';
  if (s === 'Negative') return 'neg';
  return 'neutral';
}

export function initialsOf(name: string | undefined | null): string {
  const parts = String(name ?? '?').trim().split(/\s+/).slice(0, 2);
  const v = parts.map(w => w[0] ?? '').join('').toUpperCase();
  return v || '?';
}