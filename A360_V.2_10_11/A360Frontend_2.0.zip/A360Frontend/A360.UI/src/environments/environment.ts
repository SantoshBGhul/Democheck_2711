// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
 
export const environment = {
  production: false,
  applicationTitle: 'A360ContractHealth',
  baseUrl: 'http://localhost:61785',
  // applicationName: 'T&L',
  applicationName: 'A360ContractHealth',
  securityName: 'Security',
  reqProcessorUrl: '/RequestProcessor',
  fileProcessorURL: '/FileProcessor',
  sessionTimeoutURL: '/Account/SessionTimeoutValue',
  redirectURL: 'https://geshpsappsuiteqa.honeywell.com/GESGlobalExcellence/SecurityManager/PlatformUIManager/#/my-dashboard',
 
  /* usage Tracker URL */
  usageTrackerBaseUrl: 'http://localhost:5500',
  usageApplicationName: 'usageTracker',
  saveNewUsageUrl: '/api/productivity/SaveNewUsage',
  waDetails: '/api/WAPortal/waDetails',
  trialCount: '/api/UsageConfiguration/TrialAttemptsCount',
  userTrialCount: '/api/UsageConfiguration/TrialAttemptsByEIDandAppName',
  applicationFilesUrl: '/api/ApplicationFiles/GetApplicationFiles',
  downloadApplicationFiles: '/api/ApplicationFiles/ApplicationFiles/DownloadFile',
 
  /* Lead Engineering API */
  // Impact on dashboard
  getDashbordImpactOnDisciplinMAster: "/api/Dashbord/getDashbordImpactOnDisciplinMAster",
  getDashbordImpactOnDisciplinBasedOnProductCode: "/api/Dashbord/getDashbordImpactOnDisciplinBasedOnProductCode",
  saveAndUpdatDashbordImpactOnDiscipline: "/api/Dashbord/saveAndUpdatDashbordImpactOnDiscipline",
 
  //  NormalizedIo
 
  // header api
  getGuideEACAnalysisAllData: "/api/GuideEACAnalysisMaster/getGuideEACAnalysisAllData",
 
  //  ProductMaster
  GetProjectList: '/api/ProductMaster/getProjectList',
  GetAllProjectList: '/api/ProductMaster/getAllProjectList',
  GetProjectListBasedOnEID: '/api/ProductMaster/getProjectListBasedOnEID',
  GetProjectInfoForMultipleProject: '/api/ProductMaster/getProjectInfoForMultipleProject',
  UpdateLEDetail: '/api/ProductMaster/addMultipleUsersForLE',
  productivityPlanReasons: '/api/ProductitvityPlan/productivityPlanReasons',
  ProjectSaving: '/api/ProductMaster/ProjectSaving',
 
  // productivity plan
  GetProductitvityPlanBasedProductCode: "/api/ProductitvityPlan/GetProductitvityPlanBasedProductCode",
  SaveActivityExecution: "/api/ProductitvityPlan/saveActivityExecution",
 
  //projectApprovalRejectionHistory page
  GetSendedForApproval: "/api/ApprovalHistory/GetSendedForApproval",
  GetApprovalListBasedOnPole: "/api/ApprovalHistory/GetApprovalListBasedOnPole",
  sendedForApproval: "/api/ApprovalHistory/sendedForApproval",
  updateProductivityPlan: "/api/ProductitvityPlan/updateProductivityPlan",
  updateNormalizedIo: "/api/NormalizedIo/updateNormalizedIo",
 
  // end
 
  // normalized record
  GetNormalizedIoRecordsBasedOnProductCode: "/api/NormalizedIORecords/getNormalizedIoRecordsBasedOnProductCode",
  SaveNormalizedIoRecords: "/api/NormalizedIORecords/saveNormalizedIoRecords",
  SaveAndUpdateFirstRecord: "/api/NormalizedIORecords/saveAndUpdateFirstRecord",
 
  // END
 
  // NormaliIO Page
  GetNormalizedIoMaster: '/api/NormalizedIo/getNormalizedIoMaster',
  GetNormalizedIoBasedOnProductCode: "/api/NormalizedIo/getNormalizedIoBasedOnProductCode",
  SaveNormalizedIo: '/api/NormalizedIo/saveNormalizedIo',
  normalizedIoReasons: '/api/NormalizedIo/normalizedIoReasons',
 
  // END
 
  // Tool benifit
  GetToolBenifitsBasedProductCode: "/api/ToolBenfit/GetToolBenifitsBasedProductCode",
  getMasterDataBenfitTools: "/api/ToolBenfit/getMasterDataBenfitTools",
  SaveAndUpdateToolBenifits: "/api/ToolBenfit/SaveAndUpdateToolBenifits",
  GetSelectedDatabBenfitTools: "/api/ToolBenfit/getSelectedDatabBenfitTools",
 
  // end yes
  GetEngPlaningDetailsBaseOnProjectCode: "/api/EngPlanningDetails/getEngPlaningDetailsBaseOnProjectCode",
  SaveEngPlaningDetails: "/api/EngPlanningDetails/saveEngPlaningDetails",
 
  GetEngPlaningDetailsMaster: "/api/EngPlanningDetails/getEngPlaningDetailsMaster",
 
  // Dashboard
  GetDashbordOverrunsBasedOnProductCode: "/api/Dashbord/getDashbordOverrunsBasedOnProductCode",
  SaveAndUpdatDashbordOverruns: "/api/Dashbord/saveAndUpdatDashbordOverruns",
  GetDashbordBillingBasedOnProductCode: "/api/Dashbord/getDashbordBillingBasedOnProductCode",
  SaveAndUpdatDashbordBilling: "/api/Dashbord/saveAndUpdatDashbordBilling",
  GetDashbordEACBasedOnProductCode: "/api/Dashbord/getDashbordEACBasedOnProductCode",
  SaveAndUpdatDashbordEAC: "/api/Dashbord/saveAndUpdatDashbordEAC",
  GetDashbordOrdersBasedOnProductCode: "/api/Dashbord/getDashbordOrdersBasedOnProductCode",
  SaveAndUpdatDashbordOrders: "/api/Dashbord/saveAndUpdatDashbordOrders",
  GetDashbordUnspelledBasedOnProductCode: "/api/Dashbord/getDashbordUnspelledBasedOnProductCode",
  SaveAndUpdatDashbordUnspelled: "/api/Dashbord/saveAndUpdatDashbordUnspelled",
  GetDashbordRiskBasedOnProductCode: "/api/Dashbord/getDashbordRiskBasedOnProductCode",
  SaveAndUpdatDashbordRisk: "/api/Dashbord/saveAndUpdatDashbordRisk",
  GetDashbordRiskHandOverBasedOnProductCode: "/api/Dashbord/getDashbordRiskHandOverBasedOnProductCode",
  SaveAndUpdatDashbordRiskHandover: "/api/Dashbord/saveAndUpdatDashbordRiskHandover",
  GetPalnningWorkBasedOnProjectCode: "/api/EngPlanningDetails/getPalnningWorkBasedOnProjectCode",
  SaveandUpdatePalnningWork: "/api/EngPlanningDetails/saveandUpdatePalnningWork",
  GetGuideEACAnalysisAllData: "/api/GuideEACAnalysisMaster/getGuideEACAnalysisAllData",
  GetRiskRecordBasedOnProjectCode:"/api/RiskExposure/GetRiskRecordBasedOnProjectCode",
  GetRAndORecordBasedOnProjectCode: "/api/RAndORecord/GetRAndORecordBasedOnProjectCode",
  GetChangeOrdersByProjectCode: "/api/Dashbord/GetChangeOrdersByProjectCode",
  GetEACByProjectCode: "/api/Dashbord/GetEACByProjectCode",
  GetUpsellByProjectCode: "/api/Dashbord/GetUpsellByProjectCode",
  uploadEACData:"/api/Dashbord/UploadEACData",
 
  // Project Lys
  GetProjectCheckList: "/api/ProjectCheckList/getProjectCheckList",
  GetProjectCheckListMaster: "/api/ProjectCheckList/getProjectCheckListMaster",
  SaveAndUpdateProjectCheckList: "/api/ProjectCheckList/SaveAndUpdateProjectCheckList",
  removeProjectCodeAccess: "/api/ProductMaster/removeProjectCodeAccess",
 
// A360 Contract Health 
// Actions
UpdateAction: "/api/a360/actions/{id}",
DeleteAction: "/api/a360/actions/{id}/delete",

// Contract Health
CreateContractHealth: "/api/a360/contract-health",

// Contracts
GetContracts: "/api/a360/contracts",
CreateContract: "/api/a360/contracts",
GetFilteredContracts: "/api/a360/contracts/filtered",
GetContractById: "/api/a360/contracts/{id}",
DeleteContract: "/api/a360/contracts/{id}/delete",

// Dashboard
GetDashboardSummary: "/api/a360/dashboard/summary",

// Logging
LogClientError: "/api/a360/logs/client-error",

// Meetings
GetMeetings: "/api/a360/meetings",
CreateMeeting: "/api/a360/meetings",

// Performance Managers
GetPerformanceManagers: "/api/a360/performance-managers",
CreatePerformanceManager: "/api/a360/performance-managers",
DeletePerformanceManager: "/api/a360/performance-managers/{id}/delete",

};
 
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.