import {
  ChangeDetectionStrategy, Component, computed, effect, inject, signal,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { MeetingWizardService } from './meeting-wizard.service';
import { StateService } from '../../core/services/state';
import { ApiService } from '../../core/services/api';
import { FlashService } from '../../core/services/flash.service';
import {
  ALL_KPIS, HEALTH_STATUSES, KPI_GROUPS,
  Contract, HealthStatus, KpiDefinition, KpiGroup, GroupCommentKey,
} from '../../core/models/a360.models';

type KpiSelections = Record<string, string>;
type GroupComments = Record<GroupCommentKey, string>;

const EMPTY_COMMENTS: GroupComments = {
  customer: '', financial: '', growth: '', people: '', internal: '',
};

@Component({
  selector: 'app-meeting-wizard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule],
  templateUrl: './meeting-wizard.html',
})
export class MeetingWizard {
  private readonly wizardSvc = inject(MeetingWizardService);
  private readonly state     = inject(StateService);
  private readonly api       = inject(ApiService);
  private readonly flash     = inject(FlashService);

  protected readonly wizard   = this.wizardSvc;
  protected readonly kpiGroups = KPI_GROUPS;
  protected readonly statuses  = HEALTH_STATUSES;

  protected readonly step2Groups: readonly KpiGroup[] = [KPI_GROUPS[0], KPI_GROUPS[1]];
  protected readonly step3Groups: readonly KpiGroup[] = [KPI_GROUPS[2], KPI_GROUPS[3], KPI_GROUPS[4]];

  protected readonly step     = signal(1);
  protected readonly todayStr = new Date().toISOString().split('T')[0];

  // ============ Form state ============
  protected readonly selectedContractId = signal<number | undefined>(undefined);
  protected readonly pmName             = signal('');
  protected readonly meetingDate        = signal(new Date().toISOString().slice(0, 10));
  protected readonly meetingType        = signal('Monthly 1:1');

  protected readonly sentiment      = signal<string | null>(null);
  protected readonly valueDelivered = signal('');
  protected readonly concern        = signal('');
  protected readonly customerAction = signal('');
  protected readonly next90Risk     = signal<string | null>(null);

  protected readonly kpiSelections  = signal<KpiSelections>({});
  protected readonly groupComments  = signal<GroupComments>({ ...EMPTY_COMMENTS });

  protected readonly pfmAction    = signal('');
  protected readonly mgmtSupport  = signal('');
  protected readonly owner        = signal('');
  protected readonly due          = signal<string | null>(null);
  protected readonly action       = signal('');

  // ============ UI state ============
  protected readonly customerMenuOpen = signal(false);
  protected readonly touched          = signal<Set<string>>(new Set());

  // ============ Per-group comment requirement ============
  protected readonly groupsRequiringComments = computed<ReadonlySet<string>>(() => {
    const sels = this.kpiSelections();
    const required = new Set<string>();
    for (const g of KPI_GROUPS) {
      if (g.defs.some(d => {
        const v = sels[d.key as string];
        return v === 'Orange' || v === 'Red';
      })) {
        required.add(g.id);
      }
    }
    return required;
  });

  protected isGroupCommentRequired(groupId: string): boolean {
    return this.groupsRequiringComments().has(groupId);
  }

  // ============ Whole-form validation ============
  protected readonly allMissingFields = computed(() => {
    const missing: string[] = [];

    if (!this.selectedContractId()) missing.push('Customer');
    if (this.sentiment() === null)  missing.push('Customer Sentiment');
    if (this.next90Risk() === null) missing.push('90-Day Risk');

    if (!this.due()) {
      missing.push('Due Date');
    } else if (this.due()! < this.todayStr) {
      missing.push('Valid Due Date (cannot be past)');
    }

    if (!this.action().trim()) missing.push('Action / Follow-up');

    for (const g of KPI_GROUPS) {
      if (this.isGroupCommentRequired(g.id)) {
        const comment = this.groupComments()[g.commentKey];
        if (!comment || !comment.trim()) {
          missing.push(`${g.title} Comment`);
        }
      }
    }
    return missing;
  });

  protected hasError(field: string): string | null {
    if (!this.touched().has(field)) return null;

    if (field === 'customer'  && !this.selectedContractId()) return 'Customer is required.';
    if (field === 'sentiment' && this.sentiment() === null)  return 'Please select Sentiment or "Not assessed".';
    if (field === 'risk'      && this.next90Risk() === null) return '90-Day Risk is required.';

    if (field === 'due') {
      if (!this.due()) return 'Due Date is required.';
      if (this.due()! < this.todayStr) return 'Due Date cannot be in the past.';
    }

    if (field === 'action' && !this.action().trim()) return 'Action / Follow-up is required.';

    if (field.startsWith('comment_')) {
      const key   = field.replace('comment_', '') as GroupCommentKey;
      const group = KPI_GROUPS.find(g => g.commentKey === key);
      if (group && this.isGroupCommentRequired(group.id)) {
        const val = this.groupComments()[key];
        if (!val || !val.trim()) {
          return 'Comment is required because a KPI in this group is Orange/Red.';
        }
      }
    }

    return null;
  }

  protected markTouched(fields: string[]): void {
    this.touched.update(s => new Set([...s, ...fields]));
  }

  // ============ Derived state ============
  protected readonly activeContract = computed<Contract | undefined>(() =>
    this.state.contracts().find(c => c.id === this.selectedContractId())
  );

  protected readonly selectionPreview = computed(() => {
    const vals = Object.values(this.kpiSelections());
    return {
      total:  vals.length,
      green:  vals.filter(v => v === 'Green').length,
      yellow: vals.filter(v => v === 'Yellow').length,
      orange: vals.filter(v => v === 'Orange').length,
      red:    vals.filter(v => v === 'Red').length,
    };
  });

  protected readonly reviewValue          = computed(() => this.valueDelivered().trim() || 'Not entered');
  protected readonly reviewConcern        = computed(() => this.concern().trim()       || 'Not entered');
  protected readonly reviewCustomerAction = computed(() => this.customerAction().trim()|| 'Not entered');
  protected readonly review90Risk         = computed(() => this.next90Risk()           || 'Not assessed');

  // ============ Lifecycle ============
  constructor() {
    effect(() => {
      if (!this.wizardSvc.isOpen()) return;
      this.customerMenuOpen.set(false);

      this.resetForm();

      const id = this.wizardSvc.contractId();
      if (id) {
        this.loadContract(id);
      }
    });
  }

  private resetForm(): void {
    this.selectedContractId.set(undefined);
    this.pmName.set('');
    this.meetingDate.set(new Date().toISOString().slice(0, 10));
    this.meetingType.set('Monthly 1:1');
    this.sentiment.set(null);
    this.valueDelivered.set('');
    this.concern.set('');
    this.customerAction.set('');
    this.next90Risk.set(null);
    this.kpiSelections.set({});
    this.groupComments.set({ ...EMPTY_COMMENTS });
    this.pfmAction.set('');
    this.mgmtSupport.set('');
    this.owner.set('');
    this.due.set(null);
    this.action.set('');
    this.step.set(1);
    this.touched.set(new Set());
  }

  protected loadContract(id: number): void {
    const c = this.state.contracts().find(x => x.id === id);
    if (!c) return;

    this.selectedContractId.set(id);
    this.pmName.set(c.pmName);

    this.sentiment.set(c.sentiment === 'Blank' ? '' : c.sentiment);
    this.valueDelivered.set(c.valueDelivered || '');
    this.concern.set(c.concern || '');
    this.customerAction.set(c.customerAction || '');
    this.next90Risk.set(c.next90DayRisk === 'Blank' ? '' : c.next90DayRisk);
    this.pfmAction.set(c.pfmActionText || '');
    this.mgmtSupport.set(c.managementSupportText || '');

    this.groupComments.set({
      customer:  c.commentCustomer  || '',
      financial: c.commentFinancial || '',
      growth:    c.commentGrowth    || '',
      people:    c.commentPeople    || '',
      internal:  c.commentInternal  || '',
    });

    const selections: KpiSelections = {};
    for (const k of ALL_KPIS) {
      const v = c[k.key] as HealthStatus;
      if (v && v !== 'Blank') selections[k.key as string] = v;
    }
    this.kpiSelections.set(selections);

    const pastMeetings = this.state.meetings()
      .filter(m => m.contractId === id)
      .sort((a, b) => new Date(b.meetingDate).getTime() - new Date(a.meetingDate).getTime());

    if (pastMeetings.length > 0 && pastMeetings[0].meetingType) {
      this.meetingType.set(pastMeetings[0].meetingType);
    }
  }

  // ============ Customer dropdown ============
  protected onCustomerChange(id: number): void {
    this.loadContract(id);
    this.markTouched(['customer']);
  }

  protected selectCustomer(id: number): void {
    this.customerMenuOpen.set(false);
    this.onCustomerChange(id);
  }

  // ============ KPI selection ============
  protected getKpi(key: KpiDefinition['key']): string {
    return this.kpiSelections()[key as string] ?? '';
  }

  protected setKpi(key: KpiDefinition['key'], value: HealthStatus): void {
    this.kpiSelections.update(s => ({ ...s, [key as string]: value }));
    this.markCommentsTouchedIfNeeded();
  }

  protected setGroup(groupId: string, status: HealthStatus): void {
    const defs = KPI_GROUPS.find(g => g.id === groupId)?.defs ?? [];
    this.kpiSelections.update(s => {
      const next = { ...s };
      for (const d of defs) next[d.key as string] = status;
      return next;
    });
    this.markCommentsTouchedIfNeeded();
  }

  protected clearGroup(groupId: string): void {
    const defs = KPI_GROUPS.find(g => g.id === groupId)?.defs ?? [];
    this.kpiSelections.update(s => {
      const next = { ...s };
      for (const d of defs) delete next[d.key as string];
      return next;
    });
  }

  private markCommentsTouchedIfNeeded(): void {
    const fields: string[] = [];
    for (const g of KPI_GROUPS) {
      if (this.isGroupCommentRequired(g.id)) {
        fields.push(`comment_${g.commentKey}`);
      }
    }
    if (fields.length > 0) this.markTouched(fields);
  }

  // ============ Comments & signals ============
  protected getGroupComment(key: GroupCommentKey): string {
    return this.groupComments()[key] ?? '';
  }

  protected setGroupComment(key: GroupCommentKey, value: string): void {
    this.groupComments.update(c => ({ ...c, [key]: value }));
    this.markTouched([`comment_${key}`]);
  }

  protected setSentiment(v: string): void {
    this.sentiment.set(v);
    this.markTouched(['sentiment']);
  }

  protected setRisk90(v: string): void {
    this.next90Risk.set(v);
    this.markTouched(['risk']);
  }

  // ============ Steps ============
  protected next(): void {
    if (this.step() === 1) {
      this.markTouched(['customer', 'sentiment']);
      if (!this.selectedContractId() || this.sentiment() === null) {
        this.flash.show('Please select a Customer and Customer Sentiment.');
        return;
      }
    }

    const groups = this.step() === 2 ? this.step2Groups : this.step() === 3 ? this.step3Groups : [];
    const missing = groups
      .filter(g => this.isGroupCommentRequired(g.id) && !this.groupComments()[g.commentKey]?.trim())
      .map(g => g.title);
    if (missing.length > 0) {
      this.markTouched(groups.map(g => `comment_${g.commentKey}`));
      this.flash.show(`Comment required for: ${missing.join(', ')}.`);
      return;
    }

    this.step.update(s => Math.min(4, s + 1));
  }

  protected prev():  void { this.step.update(s => Math.max(1, s - 1)); }
  protected close(): void { this.wizardSvc.close(); }

  // ============ Styling helpers ============
  protected sentimentActiveCls(v: string): string {
    if (this.sentiment() !== v) return 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100';
    switch (v) {
      case 'Positive': return 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-2 ring-emerald-500/20';
      case 'Negative': return 'bg-red-50 text-[#e20100] border-[#e20100] ring-2 ring-[#e20100]/20';
      case 'Neutral':  return 'bg-slate-100 text-slate-800 border-slate-300 ring-2 ring-slate-300';
      default:         return 'bg-[#e20100] text-white border-[#e20100] shadow-md shadow-[#e20100]/30';
    }
  }

  protected riskCls(v: string): string {
    if (this.next90Risk() !== v) return 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100';
    switch (v) {
      case 'Green':  return 'bg-emerald-50 text-emerald-800 border-emerald-300';
      case 'Yellow': return 'bg-yellow-50 text-yellow-800 border-yellow-300';
      case 'Orange': return 'bg-orange-50 text-orange-800 border-orange-300';
      case 'Red':    return 'bg-red-50 text-[#e20100] border-[#e20100]';
      default:       return 'bg-[#e20100] text-white border-[#e20100]';
    }
  }

  protected kpiCls(st: HealthStatus, current: string): string {
    const active = st === current;
    if (!active) return 'bg-slate-50 text-slate-500 border-slate-200 hover:bg-slate-100';
    switch (st) {
      case 'Green':  return 'bg-emerald-50 text-emerald-800 border-emerald-300 ring-2 ring-emerald-500/20';
      case 'Yellow': return 'bg-yellow-50 text-yellow-800 border-yellow-300 ring-2 ring-yellow-500/20';
      case 'Orange': return 'bg-orange-50 text-orange-800 border-orange-300 ring-2 ring-orange-500/20';
      case 'Red':    return 'bg-red-50 text-[#e20100] border-[#e20100] ring-2 ring-[#e20100]/20';
    }
    return 'bg-slate-50 text-slate-500 border-slate-200';
  }

  // ============ Save ============
  protected async save(): Promise<void> {
    const fieldsToTouch = ['customer', 'sentiment', 'risk', 'due', 'action'];
    for (const g of KPI_GROUPS) fieldsToTouch.push(`comment_${g.commentKey}`);
    this.markTouched(fieldsToTouch);

    const missing = this.allMissingFields();
    if (missing.length > 0) {
      this.flash.show(`Cannot save. Missing: ${missing.join(', ')}.`);
      return;
    }

    const cid = this.selectedContractId();
    if (!cid || !this.due()) return;

    const body = {
      contractId: cid,
      pmName: this.pmName(),
      meetingDate: this.meetingDate(),
      meetingType: this.meetingType(),
      sentiment: this.sentiment() || 'Blank',
      valueDelivered: this.valueDelivered(),
      concern: this.concern(),
      customerAction: this.customerAction(),
      pfmAction: this.pfmAction(),
      managementSupport: this.mgmtSupport(),
      next90DayRisk: this.next90Risk() || 'Blank',
      owner: this.owner(),
      due: this.due(),
      action: this.action(),
      healthSnapshot: this.kpiSelections(),
      groupComments: this.groupComments() as unknown as Record<string, string>,
    };

    try {
      await firstValueFrom(this.api.createMeeting(body));
      this.flash.show('Meeting saved successfully');
      this.wizardSvc.close();
      this.state.reload();
    } catch (err: any) {
      console.error('Save Error:', err); 
      let msg = 'An unknown error occurred.';
      if (err.error?.errors) {
        msg = Object.values(err.error.errors).flat().join(', ');
      } else if (err.error?.error) {
        msg = err.error.error;
      } else if (err.error?.title) {
        msg = err.error.title;
      } else if (err.message) {
        msg = err.message;
      }
      this.flash.show(`Error: ${msg}`);
    }
  }
}