import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { StateService } from '../../core/services/state';
import { Contract, HealthStatus, statusScore } from '../../core/models/a360.models';

interface ServiceSection { readonly score: number; readonly coverage: number; readonly health: number; }
interface DetailsSection { readonly avgKpi: number; readonly missing: number; readonly proposal: number; readonly overdue: number; readonly csat: number; readonly nps: number; }
interface FinancialSection { readonly assurance: number; readonly requested: number | null; readonly pm: number; readonly cyber: number; readonly training: number; readonly bgp: number; readonly pipeline: number; readonly bookedMargin: number; readonly grossMargin: number; }
interface Dims { readonly customer: number; readonly outcome: number; readonly delivery: number; readonly financial: number; readonly risk: number; }
interface A360Section { readonly score: number; readonly state: string; readonly dims: Dims; }
interface PerfView { readonly service: ServiceSection; readonly details: DetailsSection; readonly financial: FinancialSection; readonly a360: A360Section; }

@Component({
  selector: 'app-performance-analytics',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './performance-analytics.html',
})
export class PerformanceAnalytics {
  private readonly state = inject(StateService);
  protected readonly Math = Math; 
  protected readonly view = computed<PerfView>(() => this.compute(this.state.contracts()));

  protected min100(v: number): number { return Math.max(0, Math.min(100, v)); }
  
  protected barCls(v: number, good: number, warn: number): 'good' | 'warn' | 'bad' {
    if (v >= good) return 'good';
    if (v >= warn) return 'warn';
    return 'bad';
  }
  
  protected overdueCls(v: number): 'good' | 'warn' | 'bad' {
    if (v <= 5) return 'good';
    if (v <= 30) return 'warn';
    return 'bad';
  }

  private compute(contracts: readonly Contract[]): PerfView {
    const d = contracts;
    const avg = (arr: number[], def = 0) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : def);
    const score = this.computeScore(d);

    // DYNAMIC SERVICE METRICS
    const validServiceScore = d.map(c => Number(c.serviceScore)).filter(v => v > 0);
    const serviceScore = Math.round(avg(validServiceScore, 0));

    const validCoverage = d.map(c => Number(c.serviceCoverage)).filter(v => v > 0);
    const coverage = Math.round(avg(validCoverage, 0));

    const validServiceHealth = d.map(c => Number(c.serviceHealth)).filter(v => v > 0);
    const serviceHealth = Math.round(avg(validServiceHealth, 0));

    // DETAILS
    const avgKpi = score;
    const missing = d.filter(c => c.id % 7 === 0).length; // Example logic, can be changed later
    const proposal = Math.round(avg(d.map(c => (c.id * 2) % 3)));
    
    const overdue = Math.round(
      avg(d.map(c => {
        if (c.overallHealth === 'Red') return 45;
        if (c.overallHealth === 'Orange') return 15;
        return 0;
      }))
    );

    // DYNAMIC CSAT / NPS
    const validCsat = d.map(c => Number(c.csatScore)).filter(v => v > 0);
    const csat = Math.round(avg(validCsat, 0));

    const validNps = d.map(c => Number(c.npsScore)).filter(v => v !== 0);
    const nps = Math.round(avg(validNps, 0));

    // DYNAMIC FINANCIALS
    const pipeline = d.reduce((s, c) => s + Number(c.pipelineValue || 0), 0);
    
    const validBooked = d.map(c => Number(c.bookedMarginPct)).filter(v => v > 0);
    const bookedMargin = Math.round(avg(validBooked, 0));

    const validGross = d.map(c => Number(c.grossMarginPct)).filter(v => v > 0);
    const grossMargin = Math.round(avg(validGross, 0));

    const pm = d.reduce((s, c) => s + Number(c.preventiveHrs || 0), 0);
    const cyber = d.reduce((s, c) => s + Number(c.cyberHrs || 0), 0);
    const training = d.reduce((s, c) => s + Number(c.trainingHrs || 0), 0);
    const bgp = d.reduce((s, c) => s + Number(c.bgpPlusHrs || 0), 0);

    const dims: Dims = {
      customer: Math.round(avg(d.map(c => c.sentiment === 'Positive' ? 85 : c.sentiment === 'Negative' ? 42 : 68))),
      outcome: Math.round(avg(d.map(c => statusScore(c.outcomeKpi)))),
      delivery: Math.round(avg(d.map(c => statusScore(c.deliveryHealth)))),
      financial: Math.round(avg(d.map(c => statusScore(c.financialHealth)))),
      risk: Math.round(avg(d.map(c => statusScore(c.riskHealth)))),
    };

    return {
      service: { score: serviceScore, coverage, health: serviceHealth },
      details: { avgKpi, missing, proposal, overdue, csat, nps },
      financial: {
        assurance: 0, requested: null, 
        pm, cyber, training, bgp, pipeline, bookedMargin, grossMargin,
      },
      a360: {
        score,
        state: score >= 80 ? 'HEALTHY' : score >= 65 ? 'WATCH' : score >= 45 ? 'ATTENTION' : 'CRITICAL',
        dims,
      },
    };
  }

  private computeScore(d: readonly Contract[]): number {
    if (!d.length) return 0;
    let sum = 0, cnt = 0;
    for (const c of d) {
      const vals: HealthStatus[] = [
        c.outcomeKpi, c.topCustomerPriority, c.next90DayRisk, c.pfmAction, c.managementSupport,
        c.marginChecked, c.billingForecastUpdated, c.pastDues, c.sespBgpCostsChecked,
        c.renewalOnTime, c.tracker2026, c.tracker2027,
        c.idpCompleted, c.hpdResultsUpdated, c.siopCompleted,
        c.sfdcTasksClosed, c.reportingStandard, c.customerMeetingsPlanned,
        c.digitalPrimeDashboard, c.contractSetupCorrect, c.a360OpsDashboard,
        c.npsShared, c.mosCompleted, c.deliveryHealth, c.financialHealth, c.riskHealth, c.renewalHealth,
      ].filter(v => v && v !== 'Blank');

      if (!vals.length) continue;
      sum += vals.reduce((s, v) => s + statusScore(v), 0) / vals.length;
      cnt++;
    }
    return cnt ? Math.round(sum / cnt) : 0;
  }
}