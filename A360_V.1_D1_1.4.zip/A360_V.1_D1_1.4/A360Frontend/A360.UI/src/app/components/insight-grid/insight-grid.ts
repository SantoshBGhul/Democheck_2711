import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { Router } from '@angular/router';
import { StateService } from '../../core/services/state';
import {
  Contract, Meeting, statusScore, statusRank, OverallState,
} from '../../core/models/a360.models';

interface CustomerInsight {
  readonly score: number;
  readonly state: OverallState;
  readonly positivePct: number;
  readonly concerns: number;
  readonly outcomeScore: number;
  readonly note: string;
}

interface FinancialInsight {
  readonly value: number;
  readonly risk: number;
  readonly riskPct: number;
  readonly grossMargin: number;
  readonly pipeline: number;
  readonly pastDue: number;
  readonly bookedMargin: number;
}

interface RenewalInsight {
  readonly score: number;
  readonly watch: number;
  readonly red: number;
  readonly readyPct: number;
  readonly trackerReady: number;
}

interface MeetingInsight {
  readonly count: number;
  readonly open: number;
  readonly inprog: number;
  readonly done: number;
  readonly dueSoon: number;
  readonly closure: number;
  readonly latest: string;
}

interface InsightsView {
  readonly customer: CustomerInsight;
  readonly financial: FinancialInsight;
  readonly renewal: RenewalInsight;
  readonly meetings: MeetingInsight;
}

@Component({
  selector: 'app-insight-grid',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './insight-grid.html',
})
export class InsightGrid {
  private readonly state = inject(StateService);
  private readonly router = inject(Router);

  protected readonly view = computed<InsightsView>(() =>
    this.computeInsights(this.state.contracts(), this.state.meetings())
  );

  protected openActions(): void {
    void this.router.navigate(['/actions']);
  }

  protected readonly summary = computed(() => this.state.summary());
  protected readonly ringColor = computed(() => {
    const s = this.state.summary();
    if (!s) return '#f59e0b';
    if (s.score >= 80) return '#0ea472';
    if (s.score >= 45) return '#f97316';
    return '#ef4444';
  });

  protected min100(v: number): number {
    return Math.min(100, v);
  }

  private computeInsights(contracts: readonly Contract[], meetings: readonly Meeting[]): InsightsView {
    const d = contracts;
    const n = Math.max(1, d.length);
    const avg = (vals: number[], def = 0) => (vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : def);

    // ========= Customer =========
    const customerScore = Math.round(avg(d.map(c => statusScore(c.outcomeKpi))));
    const positivePct = Math.round((d.filter(c => c.sentiment === 'Positive').length / n) * 100);
    const concerns = d.filter(c => (c.concern || '').trim()).length;
    const outcomeScore = Math.round(avg(d.map(c => statusScore(c.outcomeKpi)).filter(v => v > 0)));
    const customerState: OverallState =
      customerScore >= 80 ? 'Healthy' :
      customerScore >= 65 ? 'Watch' :
      customerScore >= 45 ? 'Attention' : 'Critical';

    // ========= Financial =========
    const value = d.reduce((s, c) => s + Number(c.value || 0), 0);
    const risk = d.reduce((s, c) => s + Number(c.riskValue || 0), 0);
    const riskPct = value ? (risk / value) * 100 : 0;
    
    // DYNAMIC FINANCIAL CALCULATIONS
    const validGross = d.map(c => Number(c.grossMarginPct)).filter(v => v > 0);
    const grossMargin = Math.round(avg(validGross, 0));

    const pipeline = d.reduce((s, c) => s + Number(c.pipelineValue || 0), 0);
    const pastDue = d.reduce((s, c) => s + Math.min(statusRank(c.pastDues), 2), 0);
    
    const validBooked = d.map(c => Number(c.bookedMarginPct)).filter(v => v > 0);
    const bookedMargin = Math.round(avg(validBooked, 0));

    // ========= Renewal =========
    const renewalScore = Math.round(avg(d.map(c => statusScore(c.renewalHealth)).filter(v => v > 0)));
    const watch = d.filter(c => c.renewalHealth === 'Yellow' || c.renewalHealth === 'Orange').length;
    const red = d.filter(c => c.renewalHealth === 'Red').length;
    const readyPct = Math.round((d.filter(c => c.renewalHealth === 'Green').length / n) * 100);
    const trackerReady = Math.round(
      (d.filter(c => c.tracker2026 === 'Green' && c.tracker2027 === 'Green').length / n) * 100
    );

    // ========= Meetings =========
    const visible = new Set(d.map(c => c.customer));
    const scoped = meetings.filter(m => visible.size === 0 || visible.has(m.customer));
    const actions = scoped.filter(m => m.action);
    const open = actions.filter(m => m.actionStatus === 'Open').length;
    const inprog = actions.filter(m => m.actionStatus === 'InProgress').length;
    const done = actions.filter(m => m.actionStatus === 'Completed').length;
    const today = new Date().toISOString().slice(0, 10);
    const dueSoon = actions.filter(m => {
      if (!m.due || m.actionStatus === 'Completed') return false;
      const diff = Math.round((new Date(m.due).getTime() - new Date(today).getTime()) / 86400000);
      return diff >= 0 && diff <= 14;
    }).length;
    const closure = actions.length ? Math.round((done / actions.length) * 100) : 0;
    const latest = [...scoped].sort((a, b) =>
      String(b.meetingDate).localeCompare(String(a.meetingDate))
    )[0];

    return {
      customer: {
        score: customerScore, state: customerState, positivePct, concerns, outcomeScore,
        note: this.buildNote(d),
      },
      financial: { value, risk, riskPct, grossMargin, pipeline, pastDue, bookedMargin },
      renewal: { score: renewalScore, watch, red, readyPct, trackerReady },
      meetings: {
        count: scoped.length, open, inprog, done, dueSoon, closure,
        latest: latest ? `${latest.customer} · ${latest.meetingDate?.slice(0, 10)}` : 'No meeting yet',
      },
    };
  }

  private buildNote(d: readonly Contract[]): string {
    const neg = d.filter(c => c.sentiment === 'Negative').length;
    const risk = d.filter(c => c.overallHealth === 'Red' || c.overallHealth === 'Orange').length;
    if (neg > 0 && risk > 0) return `${neg} account(s) negative sentiment while ${risk} are Orange/Red — review both signals.`;
    if (neg > 0) return `${neg} account(s) show negative sentiment — validate service gaps and commitments.`;
    if (risk > 0) return `${risk} account(s) are Orange/Red operationally — check delivery and renewal readiness.`;
    return 'Customer sentiment and KPI health are aligned in the current view.';
  }
}