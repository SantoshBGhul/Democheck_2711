import { ChangeDetectionStrategy, Component, computed, inject, signal, linkedSignal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StateService, Filters } from '../../core/services/state';
import { FlashService } from '../../core/services/flash.service';
import { KpiStrip } from '../../components/kpi-strip/kpi-strip';
import { InsightGrid } from '../../components/insight-grid/insight-grid';
import { PerformanceAnalytics } from '../../components/performance-analytics/performance-analytics';
import { A360Summary } from '../../components/a360-summary/a360-summary';
import { MeetingWizardService } from '../../components/meeting-wizard/meeting-wizard.service';
import { Contract } from '../../core/models/a360.models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [FormsModule, KpiStrip, InsightGrid, PerformanceAnalytics, A360Summary],
  templateUrl: './dashboard.html',
})
export class Dashboard {
  protected readonly state = inject(StateService);
  protected readonly Math = Math;
  private readonly flash = inject(FlashService);
  private readonly wizard = inject(MeetingWizardService);

  protected readonly months = ['All', '2026-09', '2026-10', '2026-11', '2026-12'];
  protected readonly regions = [
    'All', 'EMEA', 'AMER', 'APJ', 'Asia-Pacific', 
    'Europe', 'Greater China', 'India', 'LAR', 'META', 'NAR'
  ];
  protected readonly healths = ['All', 'Green', 'Yellow', 'Orange', 'Red', 'Blank'];
  protected readonly sentiments = ['All', 'Positive', 'Neutral', 'Negative'];

  protected readonly pageSize = 10;

  
  protected readonly currentPage = linkedSignal<Filters, number>({
    source: () => this.state.filters(),
    computation: () => 1, 
  });

  protected readonly sortedContracts = computed<readonly Contract[]>(() =>
    [...this.state.contracts()].sort((a, b) => {
      const dateA = a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
      const dateB = b.updatedAt ? new Date(b.updatedAt).getTime() : 0;
      
      if (dateB !== dateA) {
        return dateB - dateA; 
      }
      return a.customer.localeCompare(b.customer); 
    })
  );

  protected readonly totalPages = computed(() => 
    Math.max(1, Math.ceil(this.sortedContracts().length / this.pageSize))
  );

  protected readonly paginatedPortfolio = computed<readonly Contract[]>(() => {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.sortedContracts().slice(start, start + this.pageSize);
  });

  protected nextPage(): void {
    if (this.currentPage() < this.totalPages()) this.currentPage.update(p => p + 1);
  }
  protected prevPage(): void {
    if (this.currentPage() > 1) this.currentPage.update(p => p - 1);
  }

  protected onFilter<K extends keyof Filters>(key: K, event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.state.setFilter(key, value as Filters[K]);
  }

  protected resetFilters(): void {
    this.state.resetFilters();
  }

  protected openMeeting(contractId?: number): void {
    this.wizard.open(contractId ?? this.state.contracts()[0]?.id);
  }

  protected async exportCSV(): Promise<void> {
    const data = this.sortedContracts();
    if (!data.length) { this.flash.show('Nothing to export'); return; }
    const headers = ['Customer', 'PM', 'Region', 'Value', 'Sentiment', 'Overall Health'];
    const rows = data.map(c => [c.customer, c.pmName, c.region, c.value, c.sentiment, c.overallHealth]);
    const csv = [headers, ...rows]
      .map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','))
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'A360_Contract_Health_Register.csv';
    a.click();
    URL.revokeObjectURL(a.href);
    this.flash.show('CSV exported');
  }
}