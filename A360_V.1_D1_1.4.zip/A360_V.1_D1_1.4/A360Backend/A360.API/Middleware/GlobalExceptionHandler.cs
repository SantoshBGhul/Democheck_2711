﻿using A360.Application.Common;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace A360.API.Middleware;

public sealed class GlobalExceptionHandler(ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext ctx, Exception ex, CancellationToken ct)
    {
        // 1. Handle Client Disconnects (Angular navigation/unsubscribing)
        // TaskCanceledException inherits from OperationCanceledException, so checking the base class is enough.
        if (ex is OperationCanceledException && ctx.RequestAborted.IsCancellationRequested)
        {
            // Log as Information, not Error, to avoid cluttering your logs.
            logger.LogInformation("Request was canceled by the client for {Path}", ctx.Request.Path);

            // 499 is the standard HTTP status code for "Client Closed Request"
            ctx.Response.StatusCode = 499;
            return true; // Exception handled, stop pipeline
        }

        // If the request is already aborted, don't try to write a response
        if (ctx.RequestAborted.IsCancellationRequested)
        {
            logger.LogInformation("Request was aborted before response could be sent for {Path}", ctx.Request.Path);
            return true; // Exception handled, request already aborted
        }

        // 2. Log actual unhandled server errors
        logger.LogError(ex, "Server Error occurred for {Path}", ctx.Request.Path);

        // 3. Map known exceptions to HTTP status codes
        var (status, code) = ex switch
        {
            NotFoundException => (StatusCodes.Status404NotFound, "NOT_FOUND"),
            ConflictException => (StatusCodes.Status409Conflict, "CONFLICT"),
            ValidationAppException => (StatusCodes.Status400BadRequest, "VALIDATION_ERROR"),
            ArgumentException => (StatusCodes.Status400BadRequest, "INVALID_ARGUMENT"),
            BadHttpRequestException => (StatusCodes.Status400BadRequest, "BAD_REQUEST"),
            InvalidOperationException => (StatusCodes.Status409Conflict, "INVALID_OPERATION"),
            KeyNotFoundException => (StatusCodes.Status404NotFound, "NOT_FOUND"),
            _ => (StatusCodes.Status500InternalServerError, "INTERNAL_ERROR")
        };

        var problem = new ProblemDetails
        {
            Status = status,
            Title = code,
            Detail = ex.Message,
            Instance = ctx.Request.Path
        };
        problem.Extensions["traceId"] = ctx.TraceIdentifier;

        ctx.Response.StatusCode = status;

        try
        {
            await ctx.Response.WriteAsJsonAsync(problem, ct).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // If the response write is cancelled, the client has already disconnected
            logger.LogDebug("Response write was cancelled for {Path}", ctx.Request.Path);
        }

        return true;
    }
}