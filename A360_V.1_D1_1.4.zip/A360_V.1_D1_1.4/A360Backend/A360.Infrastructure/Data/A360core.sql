/* =====================================================================
   A360 – QA Database Objects
   Target DB   : GESExternal
   Prefix      : A360_   (all tables, PKs and FKs)
   Re-runnable : Yes (IF NOT EXISTS guards)
   Run order   : PerformanceManagers -> Contracts -> ContractHistories
                 -> Meetings -> Foreign Keys
   ===================================================================== */

USE [GESExternal];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

/* ---------------------------------------------------------------------
   1) A360_PerformanceManagers   (no dependencies)
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.A360_PerformanceManagers', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[A360_PerformanceManagers](
        [Id]        [uniqueidentifier] NOT NULL,
        [Name]      [nvarchar](200)    NOT NULL,
        [Region]    [nvarchar](20)     NOT NULL,
        [Email]     [nvarchar](320)    NULL,
        [CreatedAt] [datetime2](7)     NOT NULL,
     CONSTRAINT [PK_A360_PerformanceManagers] PRIMARY KEY CLUSTERED
    (
        [Id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
           ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON,
           OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY];
END
GO

/* ---------------------------------------------------------------------
   2) A360_Contracts   (depends on A360_PerformanceManagers)
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.A360_Contracts', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[A360_Contracts](
        [Id]                        [int] IDENTITY(1,1) NOT NULL,
        [Customer]                  [nvarchar](200)     NOT NULL,
        [PmName]                    [nvarchar](200)     NOT NULL,
        [PerformanceManagerId]      [uniqueidentifier]  NULL,
        [Region]                    [nvarchar](20)      NOT NULL,
        [Value]                     [decimal](18, 2)    NOT NULL,
        [RiskValue]                 [decimal](18, 2)    NOT NULL,
        [Sentiment]                 [tinyint]           NOT NULL,
        [LastMeetingDate]           [datetime2](7)      NOT NULL,
        [CreatedAt]                 [datetime2](7)      NOT NULL,
        [UpdatedAt]                 [datetime2](7)      NOT NULL,
        [OutcomeKpi]                [tinyint]           NOT NULL,
        [TopCustomerPriority]       [tinyint]           NOT NULL,
        [Next90DayRisk]             [tinyint]           NOT NULL,
        [PfmAction]                 [tinyint]           NOT NULL,
        [ManagementSupport]         [tinyint]           NOT NULL,
        [MarginChecked]             [tinyint]           NOT NULL,
        [BillingForecastUpdated]    [tinyint]           NOT NULL,
        [PastDues]                  [tinyint]           NOT NULL,
        [SespBgpCostsChecked]       [tinyint]           NOT NULL,
        [RenewalOnTime]             [tinyint]           NOT NULL,
        [Tracker2026]               [tinyint]           NOT NULL,
        [Tracker2027]               [tinyint]           NOT NULL,
        [IdpCompleted]              [tinyint]           NOT NULL,
        [HpdResultsUpdated]         [tinyint]           NOT NULL,
        [SiopCompleted]             [tinyint]           NOT NULL,
        [SfdcTasksClosed]           [tinyint]           NOT NULL,
        [ReportingStandard]         [tinyint]           NOT NULL,
        [CustomerMeetingsPlanned]   [tinyint]           NOT NULL,
        [DigitalPrimeDashboard]     [tinyint]           NOT NULL,
        [ContractSetupCorrect]      [tinyint]           NOT NULL,
        [A360OpsDashboard]          [tinyint]           NOT NULL,
        [NpsShared]                 [tinyint]           NOT NULL,
        [MosCompleted]              [tinyint]           NOT NULL,
        [DeliveryHealth]            [tinyint]           NOT NULL,
        [FinancialHealth]           [tinyint]           NOT NULL,
        [RiskHealth]                [tinyint]           NOT NULL,
        [RenewalHealth]             [tinyint]           NOT NULL,
        [ValueDelivered]            [nvarchar](max)     NULL,
        [Concern]                   [nvarchar](max)     NULL,
        [CustomerAction]            [nvarchar](max)     NULL,
        [PfmActionText]             [nvarchar](max)     NULL,
        [ManagementSupportText]     [nvarchar](max)     NULL,
        [CommentCustomer]           [nvarchar](max)     NULL,
        [CommentFinancial]          [nvarchar](max)     NULL,
        [CommentGrowth]             [nvarchar](max)     NULL,
        [CommentPeople]             [nvarchar](max)     NULL,
        [CommentInternal]           [nvarchar](max)     NULL,
     CONSTRAINT [PK_A360_Contracts] PRIMARY KEY CLUSTERED
    (
        [Id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
           ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON,
           OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
END
GO

/* ---------------------------------------------------------------------
   3) A360_ContractHistories   (depends on A360_Contracts)
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.A360_ContractHistories', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[A360_ContractHistories](
        [Id]         [int] IDENTITY(1,1) NOT NULL,
        [ContractId] [int]               NOT NULL,
        [Month]      [nvarchar](20)      NOT NULL,
        [Overall]    [tinyint]           NOT NULL,
        [CreatedAt]  [datetime2](7)      NOT NULL,
     CONSTRAINT [PK_A360_ContractHistories] PRIMARY KEY CLUSTERED
    (
        [Id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
           ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON,
           OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY];
END
GO

/* ---------------------------------------------------------------------
   4) A360_Meetings   (depends on A360_Contracts)
   --------------------------------------------------------------------- */
IF OBJECT_ID(N'dbo.A360_Meetings', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[A360_Meetings](
        [Id]                  [int] IDENTITY(1,1) NOT NULL,
        [ContractId]          [int]               NOT NULL,
        [Customer]            [nvarchar](200)     NOT NULL,
        [PmName]              [nvarchar](200)     NOT NULL,
        [MeetingDate]         [datetime2](7)      NOT NULL,
        [MeetingType]         [nvarchar](max)     NOT NULL,
        [Sentiment]           [tinyint]           NOT NULL,
        [ValueDelivered]      [nvarchar](max)     NULL,
        [Concern]             [nvarchar](max)     NULL,
        [CustomerAction]      [nvarchar](max)     NULL,
        [PfmAction]           [nvarchar](max)     NULL,
        [ManagementSupport]   [nvarchar](max)     NULL,
        [Next90DayRisk]       [tinyint]           NOT NULL,
        [Action]              [nvarchar](max)     NULL,
        [Owner]               [nvarchar](max)     NULL,
        [Due]                 [datetime2](7)      NULL,
        [ActionStatus]        [tinyint]           NOT NULL,
        [Source]              [nvarchar](max)     NOT NULL,
        [HealthSnapshotJson]  [nvarchar](max)     NULL,
        [GroupCommentsJson]   [nvarchar](max)     NULL,
        [CreatedAt]           [datetime2](7)      NOT NULL,
        [UpdatedAt]           [datetime2](7)      NOT NULL,
     CONSTRAINT [PK_A360_Meetings] PRIMARY KEY CLUSTERED
    (
        [Id] ASC
    )WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF,
           ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON,
           OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
    ) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY];
END
GO

/* ---------------------------------------------------------------------
   5) Foreign Keys (prefixed names, re-runnable)
   --------------------------------------------------------------------- */

/* 5a) A360_ContractHistories -> A360_Contracts (CASCADE) */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE name = N'FK_A360_ContractHistories_A360_Contracts_ContractId')
BEGIN
    ALTER TABLE [dbo].[A360_ContractHistories] WITH CHECK
        ADD CONSTRAINT [FK_A360_ContractHistories_A360_Contracts_ContractId]
        FOREIGN KEY([ContractId])
        REFERENCES [dbo].[A360_Contracts] ([Id])
        ON DELETE CASCADE;
END
GO
ALTER TABLE [dbo].[A360_ContractHistories] CHECK CONSTRAINT [FK_A360_ContractHistories_A360_Contracts_ContractId];
GO

/* 5b) A360_Contracts -> A360_PerformanceManagers (SET NULL) */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE name = N'FK_A360_Contracts_A360_PerformanceManagers_PerformanceManagerId')
BEGIN
    ALTER TABLE [dbo].[A360_Contracts] WITH CHECK
        ADD CONSTRAINT [FK_A360_Contracts_A360_PerformanceManagers_PerformanceManagerId]
        FOREIGN KEY([PerformanceManagerId])
        REFERENCES [dbo].[A360_PerformanceManagers] ([Id])
        ON DELETE SET NULL;
END
GO
ALTER TABLE [dbo].[A360_Contracts] CHECK CONSTRAINT [FK_A360_Contracts_A360_PerformanceManagers_PerformanceManagerId];
GO

/* 5c) A360_Meetings -> A360_Contracts (CASCADE) */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys
               WHERE name = N'FK_A360_Meetings_A360_Contracts_ContractId')
BEGIN
    ALTER TABLE [dbo].[A360_Meetings] WITH CHECK
        ADD CONSTRAINT [FK_A360_Meetings_A360_Contracts_ContractId]
        FOREIGN KEY([ContractId])
        REFERENCES [dbo].[A360_Contracts] ([Id])
        ON DELETE CASCADE;
END
GO
ALTER TABLE [dbo].[A360_Meetings] CHECK CONSTRAINT [FK_A360_Meetings_A360_Contracts_ContractId];
GO


/* dbo.A360_Contracts table altered for dynamic values */
ALTER TABLE dbo.A360_Contracts ADD 
    ServiceScore INT NULL,
    ServiceCoverage INT NULL,
    ServiceHealth INT NULL,
    CsatScore INT NULL,
    NpsScore INT NULL,
    PipelineValue DECIMAL(18,2) NULL,
    BookedMarginPct DECIMAL(18,2) NULL,
    GrossMarginPct DECIMAL(18,2) NULL,
    PreventiveHrs INT NULL,
    CyberHrs INT NULL,
    TrainingHrs INT NULL,
    BgpPlusHrs INT NULL;