using System.Linq.Expressions;
using A360.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace A360.Infrastructure.Data;

public class Repository<T>(A360DbContext db) : IRepository<T> where T : class
{
    protected readonly A360DbContext Db = db;
    protected readonly DbSet<T> Set = db.Set<T>();

    public async Task<T?> GetByIdAsync(object id, CancellationToken ct = default)
    {
        try
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id), "Entity ID cannot be null.");
            }

            ct.ThrowIfCancellationRequested();

            return await Set.FindAsync(new object[] { id }, cancellationToken: ct).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Re-throw cancellation exceptions to allow proper handling at the caller level
            throw;
        }
        catch (ArgumentNullException)
        {
            // Re-throw argument validation exceptions
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An error occurred while retrieving {typeof(T).Name} with ID '{id}'. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }

    public async Task<IReadOnlyList<T>> ListAsync(Expression<Func<T, bool>>? predicate = null, CancellationToken ct = default)
    {
        try
        {
            ct.ThrowIfCancellationRequested();

            IQueryable<T> q = Set.AsNoTracking();
            if (predicate is not null)
            {
                q = q.Where(predicate);
            }

            return await q.ToListAsync(ct).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Re-throw cancellation exceptions to allow proper handling at the caller level
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An error occurred while listing {typeof(T).Name}. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }

    public async Task<PagedResult<T>> PagedAsync(int page, int pageSize,
        Expression<Func<T, bool>>? predicate = null,
        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
        CancellationToken ct = default)
    {
        try
        {
            if (pageSize < 0)
            {
                throw new ArgumentException("Page size cannot be negative.", nameof(pageSize));
            }

            if (page < 1)
            {
                throw new ArgumentException("Page must be at least 1.", nameof(page));
            }

            IQueryable<T> q = Set.AsNoTracking();
            if (predicate is not null)
            {
                q = q.Where(predicate);
            }

            // Check cancellation before executing queries
            ct.ThrowIfCancellationRequested();

            var total = await q.CountAsync(ct).ConfigureAwait(false);

            // Check cancellation after first query
            ct.ThrowIfCancellationRequested();

            if (orderBy is not null)
            {
                q = orderBy(q);
            }

            if (pageSize > 0)
            {
                page = Math.Max(1, page);
                q = q.Skip((page - 1) * pageSize).Take(pageSize);
            }

            // Check cancellation before executing final query
            ct.ThrowIfCancellationRequested();

            var items = await q.ToListAsync(ct).ConfigureAwait(false);

            var actualPageSize = pageSize > 0 ? pageSize : total;

            return new PagedResult<T>(items, total, page, actualPageSize);
        }
        catch (OperationCanceledException)
        {
            // Re-throw cancellation exceptions to allow proper handling at the caller level
            throw;
        }
        catch (DbUpdateException ex)
        {
            // Database update errors
            throw new InvalidOperationException(
                $"Database error occurred while paging {typeof(T).Name}. " +
                $"Page: {page}, PageSize: {pageSize}. " +
                $"See inner exception for details.", ex);
        }
      
        catch (TimeoutException ex)
        {
            // Query timeout
            throw new InvalidOperationException(
                $"Query timeout while paging {typeof(T).Name}. " +
                $"Page: {page}, PageSize: {pageSize}. " +
                $"The database operation took too long.", ex);
        }
        catch (ArgumentException)
        {
            // Re-throw argument exceptions (page validation, etc.)
            throw;
        }
        catch (Exception ex)
        {
            // Catch any other unexpected exceptions and wrap them
            throw new InvalidOperationException(
                $"An unexpected error occurred while paging {typeof(T).Name}. " +
                $"Page: {page}, PageSize: {pageSize}. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }

    public async Task<T> AddAsync(T entity, CancellationToken ct = default)
    {
        try
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), "Entity cannot be null.");
            }

            ct.ThrowIfCancellationRequested();

            await Set.AddAsync(entity, ct).ConfigureAwait(false);
            return entity;
        }
        catch (OperationCanceledException)
        {
            // Re-throw cancellation exceptions to allow proper handling at the caller level
            throw;
        }
        catch (ArgumentNullException)
        {
            // Re-throw argument validation exceptions
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An error occurred while adding {typeof(T).Name}. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }

    public void Update(T entity)
    {
        try
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), "Entity cannot be null.");
            }

            Set.Update(entity);
        }
        catch (ArgumentNullException)
        {
            // Re-throw argument validation exceptions
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An error occurred while updating {typeof(T).Name}. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }

    public void Remove(T entity)
    {
        try
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), "Entity cannot be null.");
            }

            Set.Remove(entity);
        }
        catch (ArgumentNullException)
        {
            // Re-throw argument validation exceptions
            throw;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An error occurred while removing {typeof(T).Name}. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }

    public async Task<int> SaveChangesAsync(CancellationToken ct = default)
    {
        try
        {
            ct.ThrowIfCancellationRequested();

            return await Db.SaveChangesAsync(ct).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            // Re-throw cancellation exceptions to allow proper handling at the caller level
            throw;
        }
        catch (DbUpdateException ex)
        {
            // Database constraint/foreign key violations
            throw new InvalidOperationException(
                $"Database save operation failed for {typeof(T).Name}. " +
                $"A database constraint or foreign key constraint was violated. " +
                $"See inner exception for details.", ex);
        }
      
        catch (TimeoutException ex)
        {
            // Timeout during save
            throw new InvalidOperationException(
                $"Timeout occurred while saving {typeof(T).Name}. " +
                $"The database operation took too long.", ex);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"An unexpected error occurred while saving {typeof(T).Name}. " +
                $"Exception: {ex.GetType().Name} - {ex.Message}", ex);
        }
    }
}
