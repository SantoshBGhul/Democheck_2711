﻿//using A360.Domain.Enums;

//namespace A360.Domain.Entities;

//public sealed class Contract
//{
//    public int Id { get; set; }
//    public string Customer { get; set; } = string.Empty;
//    public string PmName { get; set; } = string.Empty;
//    public Guid? PerformanceManagerId { get; set; }
//    public PerformanceManager? PerformanceManager { get; set; }
//    public string Region { get; set; } = "EMEA";
//    public decimal Value { get; set; }
//    public decimal RiskValue { get; set; }
//    public Sentiment Sentiment { get; set; }
//    public DateTime LastMeetingDate { get; set; } = DateTime.UtcNow;
//    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
//    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

//    // ============ CUSTOMER & OUTCOMES ============
//    public HealthStatus OutcomeKpi { get; set; }
//    public HealthStatus TopCustomerPriority { get; set; }
//    public HealthStatus Next90DayRisk { get; set; }
//    public HealthStatus PfmAction { get; set; }
//    public HealthStatus ManagementSupport { get; set; }

//    // ============ FINANCIAL ============
//    public HealthStatus MarginChecked { get; set; }
//    public HealthStatus BillingForecastUpdated { get; set; }
//    public HealthStatus PastDues { get; set; }
//    public HealthStatus SespBgpCostsChecked { get; set; }

//    // ============ GROWTH ============
//    public HealthStatus RenewalOnTime { get; set; }
//    public HealthStatus Tracker2026 { get; set; }
//    public HealthStatus Tracker2027 { get; set; }

//    // ============ PEOPLE ============
//    public HealthStatus IdpCompleted { get; set; }
//    public HealthStatus HpdResultsUpdated { get; set; }
//    public HealthStatus SiopCompleted { get; set; }

//    // ============ INTERNAL ============
//    public HealthStatus SfdcTasksClosed { get; set; }
//    public HealthStatus ReportingStandard { get; set; }
//    public HealthStatus CustomerMeetingsPlanned { get; set; }
//    public HealthStatus DigitalPrimeDashboard { get; set; }
//    public HealthStatus ContractSetupCorrect { get; set; }
//    public HealthStatus A360OpsDashboard { get; set; }
//    public HealthStatus NpsShared { get; set; }
//    public HealthStatus MosCompleted { get; set; }

//    // ============ DIMENSIONS ============
//    public HealthStatus DeliveryHealth { get; set; }
//    public HealthStatus FinancialHealth { get; set; }
//    public HealthStatus RiskHealth { get; set; }
//    public HealthStatus RenewalHealth { get; set; }

//    // ============ NOTES ============
//    public string? ValueDelivered { get; set; }
//    public string? Concern { get; set; }
//    public string? CustomerAction { get; set; }
//    public string? PfmActionText { get; set; }
//    public string? ManagementSupportText { get; set; }
//    public string? CommentCustomer { get; set; }
//    public string? CommentFinancial { get; set; }
//    public string? CommentGrowth { get; set; }
//    public string? CommentPeople { get; set; }
//    public string? CommentInternal { get; set; }

//    public ICollection<Meeting> Meetings { get; set; } = [];
//    public ICollection<ContractHistory> History { get; set; } = [];

//    /// <summary>Worst-status rollup across all populated KPIs.</summary>
//    public HealthStatus OverallHealth()
//    {
//        ReadOnlySpan<HealthStatus> all =
//        [
//            OutcomeKpi, TopCustomerPriority, Next90DayRisk, PfmAction, ManagementSupport,
//            MarginChecked, BillingForecastUpdated, PastDues, SespBgpCostsChecked,
//            RenewalOnTime, Tracker2026, Tracker2027,
//            IdpCompleted, HpdResultsUpdated, SiopCompleted,
//            SfdcTasksClosed, ReportingStandard, CustomerMeetingsPlanned,
//            DigitalPrimeDashboard, ContractSetupCorrect, A360OpsDashboard,
//            NpsShared, MosCompleted,
//            DeliveryHealth, FinancialHealth, RiskHealth, RenewalHealth
//        ];

//        var worst = HealthStatus.Blank;
//        foreach (var s in all)
//            if (s != HealthStatus.Blank && s > worst) worst = s;
//        return worst;
//    }
//}

using A360.Domain.Enums;

namespace A360.Domain.Entities;

public sealed class Contract
{
    public int Id { get; set; }
    public string Customer { get; set; } = string.Empty;
    public string PmName { get; set; } = string.Empty;
    public Guid? PerformanceManagerId { get; set; }
    public PerformanceManager? PerformanceManager { get; set; }
    public string Region { get; set; } = "EMEA";
    public decimal Value { get; set; }
    public decimal RiskValue { get; set; }
    public Sentiment Sentiment { get; set; }
    public DateTime LastMeetingDate { get; set; } = DateTime.UtcNow;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    // ============ NEW DYNAMIC DASHBOARD METRICS ============
    public int? ServiceScore { get; set; }
    public int? ServiceCoverage { get; set; }
    public int? ServiceHealth { get; set; }
    public int? CsatScore { get; set; }
    public int? NpsScore { get; set; }
    public decimal? PipelineValue { get; set; }
    public decimal? BookedMarginPct { get; set; }
    public decimal? GrossMarginPct { get; set; }
    public int? PreventiveHrs { get; set; }
    public int? CyberHrs { get; set; }
    public int? TrainingHrs { get; set; }
    public int? BgpPlusHrs { get; set; }

    // ============ CUSTOMER & OUTCOMES ============
    public HealthStatus OutcomeKpi { get; set; }
    public HealthStatus TopCustomerPriority { get; set; }
    public HealthStatus Next90DayRisk { get; set; }
    public HealthStatus PfmAction { get; set; }
    public HealthStatus ManagementSupport { get; set; }

    // ============ FINANCIAL ============
    public HealthStatus MarginChecked { get; set; }
    public HealthStatus BillingForecastUpdated { get; set; }
    public HealthStatus PastDues { get; set; }
    public HealthStatus SespBgpCostsChecked { get; set; }

    // ============ GROWTH ============
    public HealthStatus RenewalOnTime { get; set; }
    public HealthStatus Tracker2026 { get; set; }
    public HealthStatus Tracker2027 { get; set; }

    // ============ PEOPLE ============
    public HealthStatus IdpCompleted { get; set; }
    public HealthStatus HpdResultsUpdated { get; set; }
    public HealthStatus SiopCompleted { get; set; }

    // ============ INTERNAL ============
    public HealthStatus SfdcTasksClosed { get; set; }
    public HealthStatus ReportingStandard { get; set; }
    public HealthStatus CustomerMeetingsPlanned { get; set; }
    public HealthStatus DigitalPrimeDashboard { get; set; }
    public HealthStatus ContractSetupCorrect { get; set; }
    public HealthStatus A360OpsDashboard { get; set; }
    public HealthStatus NpsShared { get; set; }
    public HealthStatus MosCompleted { get; set; }

    // ============ DIMENSIONS ============
    public HealthStatus DeliveryHealth { get; set; }
    public HealthStatus FinancialHealth { get; set; }
    public HealthStatus RiskHealth { get; set; }
    public HealthStatus RenewalHealth { get; set; }

    // ============ NOTES ============
    public string? ValueDelivered { get; set; }
    public string? Concern { get; set; }
    public string? CustomerAction { get; set; }
    public string? PfmActionText { get; set; }
    public string? ManagementSupportText { get; set; }
    public string? CommentCustomer { get; set; }
    public string? CommentFinancial { get; set; }
    public string? CommentGrowth { get; set; }
    public string? CommentPeople { get; set; }
    public string? CommentInternal { get; set; }

    public ICollection<Meeting> Meetings { get; set; } = [];
    public ICollection<ContractHistory> History { get; set; } = [];

    public HealthStatus OverallHealth()
    {
        ReadOnlySpan<HealthStatus> all =
        [
            OutcomeKpi, TopCustomerPriority, Next90DayRisk, PfmAction, ManagementSupport,
            MarginChecked, BillingForecastUpdated, PastDues, SespBgpCostsChecked,
            RenewalOnTime, Tracker2026, Tracker2027,
            IdpCompleted, HpdResultsUpdated, SiopCompleted,
            SfdcTasksClosed, ReportingStandard, CustomerMeetingsPlanned,
            DigitalPrimeDashboard, ContractSetupCorrect, A360OpsDashboard,
            NpsShared, MosCompleted,
            DeliveryHealth, FinancialHealth, RiskHealth, RenewalHealth
        ];

        var worst = HealthStatus.Blank;
        foreach (var s in all)
            if (s != HealthStatus.Blank && s > worst) worst = s;
        return worst;
    }
}