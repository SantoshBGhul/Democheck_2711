import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { StateService } from '../../core/services/state';
import { ApiService } from '../../core/services/api';
import { FlashService } from '../../core/services/flash.service';
import { Meeting } from '../../core/models/a360.models';

@Component({
  selector: 'app-actions',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [DatePipe],
  templateUrl: './actions.html',
})
export class Actions {
  protected readonly state = inject(StateService);
  private readonly api = inject(ApiService);
  private readonly flash = inject(FlashService);

  // Pagination State
  protected readonly pageSize = 10;
  protected readonly currentPage = signal(1);

  // Modal State
  protected readonly actionToDelete = signal<Meeting | null>(null);
  protected readonly isDeleting = signal(false);

  // Only get meetings that have an action
  protected readonly allActions = computed<readonly Meeting[]>(() =>
    this.state.meetings().filter(m => m.action)
  );

  protected readonly totalPages = computed(() =>
    Math.max(1, Math.ceil(this.allActions().length / this.pageSize))
  );

  protected readonly paginatedActions = computed<readonly Meeting[]>(() => {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.allActions().slice(start, start + this.pageSize);
  });

  protected nextPage(): void {
    if (this.currentPage() < this.totalPages()) this.currentPage.update(p => p + 1);
  }

  protected prevPage(): void {
    if (this.currentPage() > 1) this.currentPage.update(p => p - 1);
  }

  protected async updateStatus(id: number, status: string): Promise<void> {
    try {
      await firstValueFrom(this.api.updateActionStatus(id, status));
      this.flash.show('Action status updated');
      this.state.reload();
    } catch { /* interceptor handles */ }
  }

  // --- Delete Flow ---
  protected requestRemove(m: Meeting): void {
    this.actionToDelete.set(m);
  }

  protected cancelRemove(): void {
    this.actionToDelete.set(null);
  }

  protected async confirmRemove(): Promise<void> {
    const m = this.actionToDelete();
    if (!m) return;

    this.isDeleting.set(true);
    try {
      await firstValueFrom(this.api.deleteAction(m.id));
      this.flash.show('Action removed');
      this.actionToDelete.set(null);
      this.state.reload();
    } catch {
      // handled by interceptor
    } finally {
      this.isDeleting.set(false);
    }
  }

  protected readonly Math = Math;
}