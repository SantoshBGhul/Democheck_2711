import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { FlashService } from '../services/flash.service';
import { ErrorLogService } from '../services/error-log';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const flash = inject(FlashService);
  const errorLog = inject(ErrorLogService);

  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      // 1. Show user-friendly message
      const detail = (err.error as { detail?: string; title?: string } | null)?.detail
        ?? (err.error as { title?: string } | null)?.title
        ?? err.message;
      flash.show(`${err.status} · ${detail}`);

      // 2. Log HTTP errors to backend (but prevent infinite loop if logging fails)
      if (!req.url.includes('/logs/client-error')) {
        errorLog.logError({
          message: `HTTP Error ${err.status}: ${detail}`,
          stack: `URL: ${req.urlWithParams}\nMethod: ${req.method}`,
        });
      }

      return throwError(() => err);
    })
  );
};