import { ErrorHandler, Injectable, inject } from '@angular/core';
import { ErrorLogService } from '../services/error-log';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  private errorLogService = inject(ErrorLogService);

  handleError(error: any): void {
    // Log to browser console
    console.error('Global Error Caught:', error);
    
    // Send to backend
    this.errorLogService.logError(error);
  }
}