import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class ErrorLogService {
  private http = inject(HttpClient);
  // Replace with your actual API URL
  private readonly apiUrl = 'https://localhost:7155/api/a360/logs/client-error';

  logError(error: any): void {
    const payload = {
      message: error?.message || String(error),
      stack: error?.stack || 'No stack trace available',
      url: window.location.href,
      timestamp: new Date().toISOString()
    };

    // Fire and forget (do not await, we don't want logging to block the UI)
    this.http.post(this.apiUrl, payload).subscribe({
      error: (err) => console.error('Failed to send error to backend', err)
    });
  }
}